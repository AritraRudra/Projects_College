*******************************
*     JNSGA2: Version 1.1     *
*******************************

11 September 2007

(C)opyright 2006-2007, by Joachim Melcher, Institut AIFB, Universitaet Karlsruhe (TH), Germany

e-mail: melcher@users.sourceforge.net

-----------------
1.  INTRODUCTION
-----------------
JNSGA2 is a free library for the Java platform with an abstract implementation
of the NSGA-II multi-objective genetic algorithm published in (Deb et al. 2002).
It runs on the Java 5 Platform (JDK 1.5 or later).

JNSGA2 is licensed under the terms of the GNU Lesser General
Public Licence (LGPL) version 2.1 (or any later version). A copy of the licence is
included in the distribution.

For using the JNSGA2 library in your project, you just need the runtime JAR
file (jnsga2-1.1.jar) from this ZIP file.

Please note that JNSGA2 is distributed WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. Please refer to the licence for details.

(Deb et al. 2002)
DEB, Kalyanmoy ; PRATAP, Amrit ; AGARWAL, Sameer A. ; MEYARIVAN, T.: "A Fast and Elitist
Multiobjective Genetic Algorithm: NSGA-II". In: IEEE Transactions on Evolutionary Computation,
vol. 6, no. 2, April 2002, pp. 182-197.

-------------------
2.  LATEST VERSION
-------------------
The latest version of this class library can be obtained from

    http://sourceforge.net/projects/jnsga2/

If you have any comments, suggestions or bugs to report, please post a
message on this site.

------------------------------
3.  FURTHER PROJECT RESOURCES
------------------------------
You can download the library's source code, its Javadoc API documentation, further
documentation and a small demo application using the JNSGA2 library from the 
project page on SourceForge.

-----------------
4.  DEPENDENCIES
-----------------
JNSGA2 has the following dependencies:

(a)  JDK 1.5 or higher - JNSGA2 uses generics which is offered by Java starting
with this version.

---------------
5.  HISTORY
---------------
A list of changes in recent versions:

1.0 : (27-Nov-2006)
      - first version released
1.1 : (11-Sep-2007)
      - Individual: method 'dominates': special cases for individuals with fitness value
        'NaN' (not a number)
      - NSGA2: method 'crowdingDistanceAssignment': special case for equal minimal and
        maximal fitness values
