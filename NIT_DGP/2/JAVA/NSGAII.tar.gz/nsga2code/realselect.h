/*This is the file to get the different individuals selected*/

void rselect(population *old_pop_ptr,population *mate_pop_ptr);

void rselect(population *old_pop_ptr,population *mate_pop_ptr)
{
  int *fit_ptr1,*fit_ptr2;
  
  float rnd2,*f1_ptr,*f2_ptr;
  
  float *s1_ptr,*s2_ptr;
  
  float *select_ptr;
  
  void *j,*j1;
  
  int c,i,rnd,rnd1,k,n,j2,r,s,r1;
  
  old_pop_ptr->ind_ptr = &(old_pop_ptr->ind[0]);
  mate_pop_ptr->ind_ptr= &(mate_pop_ptr->ind[0]); 
  j =  &(old_pop_ptr->ind[popsize-1]);
  
  old_pop_ptr->ind_ptr = &(old_pop_ptr->ind[0]); 
  j2 = 0;
  r = popsize;
  s = chrom;

  for(n = 0;n < popsize;n++)
    {
      mate_pop_ptr->ind_ptr = &(mate_pop_ptr->ind[n]);
      select_ptr = &(mate_pop_ptr->ind_ptr->gener[0]);
      
      rnd2 = randomperc(); 
      
      rnd2 = popsize * rnd2; 
      
      rnd = floor(rnd2);
      if(rnd == 0)
	rnd = popsize - n; // -2;
      
      if(rnd >=  popsize)
	rnd  = (popsize - 2)/2; // 4)/2;
      
      /*Select first individual randomly*/	
      j = &(old_pop_ptr->ind[rnd-1]);
      
      rnd2 = randomperc(); 
      rnd2 = popsize * rnd2; 
      rnd1 = floor(rnd2);
      
      if (rnd1 == 0)
	rnd1 = popsize - n;
      
      if(rnd1 >= popsize)
	rnd1 = (popsize - 4)/2; // 2)/2;
      
      /*Select second parent randomly */
      j1 = &(old_pop_ptr->ind[rnd1-1]); 
      
      old_pop_ptr->ind_ptr = j; 
      
      /*Assigning Pointers to the genes and dummyfitness */
      s1_ptr = &(old_pop_ptr->ind_ptr->gener[0]); 
      fit_ptr1 = &(old_pop_ptr->ind_ptr->rank); 
      f1_ptr = &(old_pop_ptr->ind_ptr->cub_len); 
       
      old_pop_ptr->ind_ptr = j1; 
      s2_ptr = &(old_pop_ptr->ind_ptr->gener[0]); 
      fit_ptr2 = &(old_pop_ptr->ind_ptr->rank); 
      f2_ptr = &(old_pop_ptr->ind_ptr->cub_len); 

/*--------------------------------------------------------------------------*/
      
/*------------------SELECTION PROCEDURE------------------------------------*/
      
      /*Selecting one parent on the basis of tournament selection*/
      
      if(*fit_ptr1 > *fit_ptr2)
	{
	  for(i = 0;i < chrom;i++)
	    *select_ptr++=*s2_ptr++;
	}
      else
	{
	  if(*fit_ptr1 < *fit_ptr2)
	    {
	      for(i = 0;i < chrom;i++)
		*select_ptr++=*s1_ptr++;
	    }
	  else
	    {
	      if(*f1_ptr < *f2_ptr)
		{
		  for(i = 0;i < chrom;i++)
		    *select_ptr++ = *s2_ptr++;
		}
	      else
		{
		  for(i = 0;i < chrom;i++)
		    *select_ptr++ = *s1_ptr++;
		}
	    }
	}
    }
  
  for(i = 0;i < popsize;i++)
    {
      // mate_pop_ptr->ind_ptr = &(mate_pop_ptr->ind[i]);
      for(j2 = 0;j2 < chrom ; j2++)
	mate_pop_ptr->ind[i].xreal[j2] = mate_pop_ptr->ind[i].gener[j2];
    }
  return;
}







