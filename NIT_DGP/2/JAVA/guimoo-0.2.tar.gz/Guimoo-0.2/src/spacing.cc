// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "spacing.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <math.h>
#include <values.h>

#include "table_window.h"
#include "po_set.h"
#include "normal.h"

static float spacing (const POSet & _pset) {
  
  POSet pset = _pset ;
  //prenormalize (pset) ;
  //normalize (pset) ;

  float min_d [pset.size ()] ;
  
  for (unsigned i = 0 ; i < pset.size () ; i ++)
    min_d [i] = MAXFLOAT ;

  for (unsigned i = 0 ; i < pset.size () ; i ++)
    for (unsigned j = 0 ; j < pset.size () ; j ++)
      if (i != j) {
	float d = pset [i].distance (pset [j], 1, false) ;
	if (d < min_d [i])
	  min_d [i] = d ;
      } 
  
  float mean_d = 0 ;
  for (unsigned i = 0 ; i < pset.size () ; i ++)
    mean_d += min_d [i] ;
  mean_d /= pset.size () ;
  
  float s = 0 ;
  for (unsigned i = 0 ; i < pset.size () ; i ++)
    s += (mean_d - min_d [i]) * (mean_d - min_d [i]) ;
  
  return sqrt (s / (pset.size () - 1)) ;
}

void open_spacing_window () {

  unsigned num_PO_sets = PO_sets.size () ;
  
  TableWindow * tab_win = new TableWindow ("Spacing", num_PO_sets, 2) ;
  
  // Setting titles ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++)
    tab_win -> set_text (i, 0, PO_sets [i].name ().c_str ()) ;
  
  // Filling the table ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) 
    tab_win -> set_float (i, 1, spacing (PO_sets [i])) ;
}
 
