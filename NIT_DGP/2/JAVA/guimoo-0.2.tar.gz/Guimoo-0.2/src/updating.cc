// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "updating.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtklabel.h>
#include <gtk/gtkspinbutton.h>
#include <gtk/gtkhbox.h>
#include <gtk/gtksignal.h>
#include <gtk/gtkmain.h>

#include <iostream>
#include <unistd.h>

#include "po_set.h"
#include "gnuplot.h"
#include "po_sets_contents.h"

static gint update_callback (gpointer _data) {
  
  // Updating Pareto Optimal sets ...
  for (unsigned i = 0 ; i < PO_sets.size () ; i ++)
    PO_sets [i].update () ;
      
  // Updating visualization ...
  update_visualization () ;
  
  // Updating Pareto Optimal sets contents ...
  update_PO_sets_contents () ;
  
  return true ; // To be re-called later ...
}

static void change_rate (GtkWidget * _spin_button) {

  static unsigned updating_rate = 0 ; // Def. No updating ... !
  static gint updater_tag ;

  if (updating_rate != 0) {
    gtk_timeout_remove (updater_tag) ;
    //   cout << "A virer " << updater_tag << endl ;
  }
 
  updating_rate = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (_spin_button)) ;
  if (updating_rate != 0) {
    updater_tag = gtk_timeout_add (updating_rate * 1000, update_callback, NULL) ;
    //cout << "On ajoute " << updater_tag << endl ; 
  }
}

GtkWidget * open_updating_area () {
  
  // Horizontal box.
  GtkWidget * hbox = gtk_hbox_new (FALSE, 10) ;
  gtk_widget_show (hbox) ;

  // Label
  GtkWidget * label = gtk_label_new ("Updating freq.") ;
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 2) ;
  gtk_widget_show (label) ;

  // Spin button
  GtkObject * adj = gtk_adjustment_new (0, 0, 1000, 1, 1, 0.0) ;
  GtkWidget * spin_butt_update = gtk_spin_button_new (GTK_ADJUSTMENT (adj), 0.5, 0) ;  
  gtk_box_pack_start (GTK_BOX (hbox), spin_butt_update, FALSE, FALSE, 2) ;
  gtk_widget_show (spin_butt_update) ;
  gtk_signal_connect (GTK_OBJECT (spin_butt_update), "changed",
		      GTK_SIGNAL_FUNC (change_rate), NULL) ;
  
  return hbox ;
}

/*
static void * update (void * _arg) {
  
  while (true) {
    
    if (updating_rate == 0)
      sleep (1) ;
    
    else {
      sleep (updating_rate) ;
      
      // Updating Pareto Optimal sets ...
      for (unsigned i = 0 ; i < PO_sets.size () ; i ++)
	PO_sets [i].update () ;
      
      // Updating visualization ...
      update_visualization () ;

      // Updating Pareto Optimal sets contents ...
      update_PO_sets_contents () ;
    }
  }
  return NULL ;
}
*/

/*
void init_updating () {
  
  pthread_t thr ;
  
  pthread_create (& thr, NULL, update, NULL) ;
}
*/
