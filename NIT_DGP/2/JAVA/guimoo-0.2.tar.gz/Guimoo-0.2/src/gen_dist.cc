// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "gen_dist.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <math.h>
#include <unistd.h>

#include "table_window.h"
#include "po_set.h"
#include "normal.h"
//#include "progress_bar_window.h"

static float generational_distance (const POSet & _pset1, const POSet & _pset2) {
  
  POSet pset1 = _pset1, pset2 = _pset2 ; // Working on copies ...
  
  unsigned p = 2 ;
  
  // A normalization is needed ...
  //prenormalize (pset1) ;
  //normalize (pset1) ;
  //normalize (pset2) ;

  float g = 0, min_dist ;
  for (unsigned i = 0 ; i < pset1.size () ; i ++) {
    min_dist = pset1 [i].distance (pset2 [0], 2, false) ;
    for (unsigned j = 1 ; j < pset2.size () ; j ++) {
      float dist = pset1 [i].distance (pset2 [j], 2, false) ;
      if (dist < min_dist)
	min_dist = dist ;
    }
    g += pow (min_dist, p) ;
  }
  return pow (g, 1.0 / p) / pset1.size () ;
}

void open_gen_dist_window () {

  unsigned num_PO_sets = PO_sets.size () ;
  
  TableWindow * tab_win = new TableWindow ("Generational distance",
					   num_PO_sets + 1,
					   num_PO_sets + 1) ;
  
  // Setting titles ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    tab_win -> set_text (0, i + 1, PO_sets [i].name ().c_str ()) ;
    tab_win -> set_text (i + 1, 0, PO_sets [i].name ().c_str ()) ;
  }
  
  // Filling the table ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    for (unsigned j = 0 ; j < num_PO_sets ; j ++) {
      if (i == j)
	tab_win -> set_float (i + 1, i + 1, 0) ;
      else {
	//if (PO_sets [j] > PO_sets [i]) {
	  float f = generational_distance (PO_sets [i], PO_sets [j]) ;
	  tab_win -> set_float (i + 1, j + 1, f) ;
	  //}
	  //else
	  //tab_win -> set_text (i + 1, j + 1, "#") ;
      }
    }
  }
}

