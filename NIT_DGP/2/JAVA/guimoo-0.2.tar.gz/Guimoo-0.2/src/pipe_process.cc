// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "pipe_process.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "pipe_process.h"

#include <unistd.h>
#include <iostream.h>

Pipe_Process :: Pipe_Process (char * _filename) {
  
  char * argv [2] ;

  argv [0] = _filename ;
  argv [1] = NULL ;
  
  pipe (to_son) ;
  pipe (to_father) ;
  
  if ((son_pid = vfork ()) == 0) {
    // Son
    dup2 (to_son [0], fileno (stdin)) ;
    dup2 (to_father [1], fileno (stdout)) ;
    // Some additional checks should be done :-) ...
    execvp (_filename, argv) ;
  }
  else {
    // Father
    file_write = (FILE *) fdopen (to_son [1], "w") ;
    file_read = (FILE *) fdopen (to_father [0], "r") ;
  }
}

Pipe_Process :: Pipe_Process (char * _filename, int _argc, char * _argv []) {
  
  char * argv [_argc + 2] ;

  argv [0] = _filename ;
  for (int i = 0 ; i < _argc ; i ++)
    argv [i + 1] = _argv [i] ;
  argv [_argc + 1] = NULL ;

  pipe (to_son) ;
  pipe (to_father) ;
  
  if ((son_pid = vfork ()) == 0) {
    // Son
    dup2 (to_son [0], fileno (stdin)) ;
    dup2 (to_father [1], fileno (stdout)) ;
    // Some additional checks should be done :-) ...
    execvp (_filename, argv) ;
  }
  else {
    // Father
    file_write = (FILE *) fdopen (to_son [1], "w") ;
    file_read = (FILE *) fdopen (to_father [0], "r") ;
  }
}  

void Pipe_Process :: send (const char * _buff, int _len) {
    
  fwrite (_buff, 1, _len, file_write) ;
  fflush (file_write) ;
}
