// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "po_sets_list.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkscrolledwindow.h>
#include <gtk/gtkclist.h>
#include <gtk/gtkvbox.h>
#include <gtk/gtkhseparator.h>

#include "gnuplot.h"
#include "quit.h"
#include "updating.h"

static GtkWidget * PO_sets_list, * window ;

void show_PO_sets_list (bool _b = true) {
  
  if (_b)
    gtk_widget_show (window) ;
  else
    gtk_widget_hide (window) ;
}

GtkWidget * open_PO_sets_list () {

  // Window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_window_set_title (GTK_WINDOW (window), "PO* files") ;
  gtk_widget_set_uposition (window, 390, 40) ;
  gtk_signal_connect (GTK_OBJECT (window), "destroy", GTK_SIGNAL_FUNC (quit), NULL) ;
  
  // Vertical box.
  GtkWidget * vbox = gtk_vbox_new (FALSE, 10) ;
  gtk_widget_show (vbox) ;
  gtk_container_add (GTK_CONTAINER (window), vbox) ;

  // Updating area
  gtk_box_pack_start (GTK_BOX (vbox), open_updating_area (), FALSE, FALSE, 2) ;

  // Hor. separator
  GtkWidget * sep = gtk_hseparator_new () ;
  gtk_widget_show (sep) ;
  gtk_box_pack_start (GTK_BOX (vbox), sep, FALSE, FALSE, 2) ;

  // Scrolling
  GtkWidget * scroll_win = gtk_scrolled_window_new (0, 0) ;
  gtk_widget_set_usize (scroll_win, 80, 200) ;
  gtk_widget_show (scroll_win) ;
  gtk_box_pack_start (GTK_BOX (vbox), scroll_win, FALSE, FALSE, 2) ;
  
  // List 
  PO_sets_list = gtk_clist_new (1) ;
  gtk_widget_show (PO_sets_list) ;
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (scroll_win), PO_sets_list) ;
  gtk_clist_set_selection_mode (GTK_CLIST (PO_sets_list), GTK_SELECTION_EXTENDED) ;
  gtk_clist_set_shadow_type (GTK_CLIST (PO_sets_list), GTK_SHADOW_ETCHED_IN) ;
  
  //  gtk_widget_show (window) ;
  
  return window ;
}

void add_PO_set_file (char * _filename) {
  
  gchar * turlututu [1] ;
  turlututu [0] = _filename ;
  gtk_clist_append (GTK_CLIST (PO_sets_list), turlututu) ;
  //  show_PO_sets_list () ;
}

static vector <POSet *> selected_files () {
  // Returns a set of POSets that are selected in the list ...

    vector <POSet *> v ;

    GList * sel = GTK_CLIST (PO_sets_list) -> selection ;

    while (sel) {
      //cout << "truc : " << (int) sel -> data << endl ;
      v.push_back (& PO_sets [ (unsigned) sel-> data]) ;
      sel = sel -> next ;
    }
    return v ;
}

void visual_add_selected_PO_sets () {
  
  plot (selected_files ()) ;
}

void clear_PO_sets_list () {
  
  gtk_clist_clear (GTK_CLIST (PO_sets_list)) ;
}
