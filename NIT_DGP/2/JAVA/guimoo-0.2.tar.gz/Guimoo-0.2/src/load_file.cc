// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "load_file.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkfilesel.h>
#include <gtk/gtkclist.h>
#include <gtk/gtksignal.h>

#include <fstream>
#include <strstream>

#include "po_set.h"
#include "po_sets_list.h"
#include "po_sets_contents.h"
#include "warning_window.h"
#include "mess_window.h"

static char * extract_dirname (char * _dirname) {  
  // From the string "Selection: 'dirname'"

  unsigned i ;
  for (i = 0 ; i < strlen (_dirname) ; i ++)
    if (_dirname [i] == ' ')
      break ;
  return _dirname + i + 1 ;
}

static char * extract_short_file_name (char * _file_name) {
  
  for (unsigned i = strlen (_file_name) - 1 ; i >= 0 ; i --)
    if (_file_name [i] == '/')
      return _file_name + i + 1 ;
}

void load_file (const char * _file_name) {
  
  ifstream f (_file_name) ;
  
  display_message (" # Loading ") ;
  display_message (_file_name, BLUE) ;
  display_message (" ... ") ;
  skip_line () ;

  if (f) {   
    char * short_file_name = extract_short_file_name ((char *) _file_name) ;
    POSet pset (short_file_name, _file_name) ;
    f >> pset ;
    
    // To the file list ...
    add_PO_set_file (short_file_name) ;  
    
    // To the PO contents ...
    PO_sets.push_back (pset) ;
    add_PO_set_contents (PO_sets.back ()) ;
    
    display_message (" # Processing ") ;
    ostrstream o ;
    o << pset.size () << '\0';
    display_message (o.str ()) ;
    display_message (" MO solutions ...") ;
    skip_line () ;
    display_message (" [ OK ]", GREEN) ;
    skip_line (2) ;
  }
  else {
    display_message (" [ File not found ]", RED) ;
    skip_line (2) ;
  }
  f.close () ;
}

static void ok_pushed (GtkWidget * widget, GtkFileSelection * file_sel) {

  GtkCList *file_sel_list = GTK_CLIST (GTK_FILE_SELECTION (file_sel) -> file_list) ;
  
  // Extracting the current folder ...
  char * dirname ;
  
  gtk_label_get (GTK_LABEL (GTK_FILE_SELECTION (file_sel) -> selection_text), & dirname) ;
  dirname = extract_dirname (dirname) ;

  // Getting the list of selected files ...
  GList * sel = file_sel_list -> selection ;

  while (sel) {
    // For each file
    
    char * file_name;
    
    // Text item
    gtk_clist_get_text(file_sel_list, (int) sel -> data, 0, & file_name) ;
    // Builds the full name (path + file)
    
    char full_file_name [255] ;
    strcpy (full_file_name, dirname) ;
    strcat (full_file_name, "/") ;
    strcat (full_file_name, file_name) ;
    
    // Store in a PO_set
    load_file (full_file_name) ;
    
    // To next file ...
    sel = sel -> next;
  }
  
  // Destroying the window
  gtk_object_destroy(GTK_OBJECT(file_sel));
}


void load_file () {
  
  GtkWidget * file_sel = gtk_file_selection_new ("Load file") ;
    
  gtk_file_selection_hide_fileop_buttons (GTK_FILE_SELECTION (file_sel)) ;
  
  gtk_clist_set_selection_mode(GTK_CLIST (GTK_FILE_SELECTION(file_sel) -> file_list),
			       GTK_SELECTION_EXTENDED) ;
  
  // Ok
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> ok_button),
		      "clicked", (GtkSignalFunc) ok_pushed, file_sel) ;
  // Cancel
  gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> cancel_button),
			     "clicked", (GtkSignalFunc) gtk_widget_destroy,
			     GTK_OBJECT (file_sel)) ;
  
  gtk_widget_show (file_sel) ;  
}
