// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "set_objectives.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtktable.h>
#include <gtk/gtklabel.h>
#include <gtk/gtkoptionmenu.h>
#include <gtk/gtkmenu.h>
#include <gtk/gtkmenuitem.h>
#include <gtk/gtkentry.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtksignal.h>

#include "objectives.h"
#include "main_window.h"

static GtkWidget * * crit_entry, * * max_item, * * min_item ;

static GtkMenu * * obj_menu ;

static void ok_pushed (GtkWidget * widget, GtkWindow * old_win) {
   
  for (unsigned i = 0 ; i < obj_labels.size () ; i ++) {
    // Labels
    obj_labels [i].assign (gtk_entry_get_text (GTK_ENTRY (crit_entry [i]))) ;
    // Aims
    obj_aims [i] = (gtk_menu_get_active (GTK_MENU (obj_menu [i])) == max_item [i]) ? MAX_OBJ : MIN_OBJ ;
  }
  
  update_main_window () ;

  // Destroying the window
  gtk_object_destroy (GTK_OBJECT (old_win)) ;
}

void set_objectives () {

  unsigned num_obj = obj_labels.size () ;
  
  // Window
  GtkWidget * window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_title (GTK_WINDOW (window), "New problem") ;
  gtk_window_set_position ((GtkWindow *) window, GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_widget_show (window) ;

  // Table
  GtkWidget * table = gtk_table_new (num_obj + 2, 2, FALSE) ;
  gtk_container_add (GTK_CONTAINER (window), table) ;
  gtk_table_set_row_spacings (GTK_TABLE (table), 5) ;
  gtk_table_set_col_spacings (GTK_TABLE (table), 5) ;

  // -> 'Label' & 'Aim'
  GtkWidget * label_label = gtk_label_new ("Label") ;
  gtk_table_attach_defaults (GTK_TABLE (table), label_label, 0, 1, 0, 1) ;
  gtk_widget_show (label_label) ;
  GtkWidget * aim_label = gtk_label_new ("Aim") ;
  gtk_table_attach_defaults (GTK_TABLE (table), aim_label, 1, 2, 0, 1) ;
  gtk_widget_show (aim_label) ;
  
  // Entries & Option Menus
  crit_entry = new GtkWidget * [num_obj] ;
  GtkWidget * * aim_option_menu = new GtkWidget * [num_obj] ;
  
  obj_menu = new GtkMenu * [num_obj] ;
  max_item = new GtkWidget * [num_obj] ;
  min_item = new GtkWidget * [num_obj] ;

  for (unsigned i = 0 ; i < num_obj ; i ++) {
    
    // Entry for title
    crit_entry [i] = gtk_entry_new () ;
    gtk_table_attach_defaults (GTK_TABLE (table), crit_entry [i], 0, 1, i + 1, i + 2) ;
    gtk_widget_show (crit_entry [i]) ;

    obj_menu [i] = (GtkMenu *) gtk_menu_new () ;
    
    // Max.
    max_item [i] = gtk_menu_item_new_with_label ("Max.") ;
    gtk_menu_append (obj_menu [i], max_item [i]);
    gtk_widget_show (max_item [i]) ;

    // Min.
    min_item [i] = gtk_menu_item_new_with_label ("Min.") ;
    gtk_menu_append (obj_menu [i], min_item [i]) ;
    gtk_widget_show (min_item [i]) ;
    
    // Option menu
    aim_option_menu [i] = gtk_option_menu_new () ;
    gtk_option_menu_set_menu (GTK_OPTION_MENU (aim_option_menu [i]), GTK_WIDGET (obj_menu [i])) ;
    gtk_table_attach_defaults (GTK_TABLE (table), aim_option_menu [i], 1, 2, i + 1, i + 2) ;
    gtk_widget_show (aim_option_menu [i]) ;
  }
  
  gtk_widget_show (table) ;
  
  // Button 'Ok'
  GtkWidget * button = gtk_button_new_with_label ("  Ok  ") ;
  gtk_table_attach_defaults (GTK_TABLE (table), button, 1, 2, num_obj + 1, num_obj + 2) ;
  gtk_widget_show (button) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (ok_pushed), window);
}
