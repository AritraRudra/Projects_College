// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "main_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkcompat.h>
#include <gtk/gtkvbox.h>
#include <gtk/gtkclist.h>
#include <gtk/gtkframe.h>
#include <gtk/gtksignal.h>
#include <gtk/gtkstatusbar.h>

//#include <tool_bar.h>

#include "full_menu.h"
#include "tool_bar.h"
#include "objectives.h"
#include "quit.h"

static GtkWidget * problem_label, * obj_clist ;

static GtkWidget * window ;

GtkWidget * open_main_window () {
  
  // Main window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_title (GTK_WINDOW (window), "Guimoo-0.2a") ;
  gtk_widget_set_usize (window, 350, 300) ;
  gtk_widget_set_uposition (window, 20, 40) ;
  gtk_widget_realize (window) ;

  // Vertical box
  GtkWidget * vbox = gtk_vbox_new (FALSE, 0) ;
  gtk_container_add (GTK_CONTAINER (window), vbox) ;
  gtk_widget_show (vbox) ;

  // Full menu
  gtk_box_pack_start (GTK_BOX (vbox), open_full_menu (), FALSE, FALSE, 2) ;

  // Tool bar
  gtk_box_pack_start (GTK_BOX (vbox), open_tool_bar (window), FALSE, FALSE, 2) ;

  // Title
  GtkWidget * problem_frame = gtk_frame_new ("Title") ;
  gtk_container_set_border_width (GTK_CONTAINER (problem_frame), 10) ;
  gtk_frame_set_shadow_type (GTK_FRAME (problem_frame), GTK_SHADOW_ETCHED_OUT) ;
  gtk_box_pack_start (GTK_BOX (vbox), problem_frame, FALSE, FALSE, 0) ;
  gtk_widget_show (problem_frame) ;
  
  problem_label = gtk_label_new ("?") ;
  gtk_container_add (GTK_CONTAINER (problem_frame), problem_label) ;
  gtk_widget_show (problem_label) ;
  
  // Objectives
  GtkWidget * obj_frame = gtk_frame_new ("Objectives") ;
  gtk_container_set_border_width (GTK_CONTAINER (obj_frame), 10) ;
  gtk_frame_set_shadow_type (GTK_FRAME (obj_frame), GTK_SHADOW_ETCHED_OUT) ;
  gtk_box_pack_start (GTK_BOX (vbox), obj_frame, FALSE, FALSE, 0) ;
  gtk_widget_show (obj_frame) ;
  
  gchar * labels [] = {"Label", "Aim"} ;
  obj_clist = gtk_clist_new_with_titles (2, labels) ;
  gtk_clist_column_titles_passive (GTK_CLIST (obj_clist)) ;
  gtk_clist_set_column_width (GTK_CLIST (obj_clist), 0, 230) ;
  gtk_clist_set_column_width (GTK_CLIST (obj_clist), 1, 40) ;
  gtk_container_add (GTK_CONTAINER (obj_frame), obj_clist) ;
  gtk_widget_set_usize (obj_clist, 330, 130) ;
  gtk_container_set_border_width (GTK_CONTAINER (obj_clist), 10) ;
  gtk_widget_show (obj_clist) ;

  // To quit (properly :-)
  gtk_signal_connect (GTK_OBJECT (window), "destroy", GTK_SIGNAL_FUNC (quit), NULL) ;
  
  //  gtk_widget_show (window) ;

  return window ;
}


/*
void open_main_window () {
  
  // Window
    
  // Full menu
  gtk_box_pack_start (GTK_BOX (vbox), full_menu (), FALSE, FALSE, 2) ;

  // Tool-bar
  gtk_box_pack_start (GTK_BOX (vbox), tool_bar (window), FALSE, FALSE, 2) ;
  
  // Status-bar
  GtkWidget * status_bar = gtk_statusbar_new () ;
  gtk_widget_show (status_bar) ;
  gtk_box_pack_start (GTK_BOX (vbox), status_bar, FALSE, FALSE, 2) ;


}
*/

void update_main_window () {
  
  // Title
  gtk_label_set_text (GTK_LABEL (problem_label), probl_label.c_str ()) ;
  gtk_clist_clear (GTK_CLIST (obj_clist)) ;

  // Labels of objectives
  for (unsigned i = 0 ; i < obj_labels.size () ; i ++) {
    gchar * obj [2] ;
    obj [0] = (gchar *) obj_labels [i].c_str () ;
    obj [1] = NULL ;
    gtk_clist_append (GTK_CLIST (obj_clist), obj) ;
  }
  
  // Aims of objectives
  GdkBitmap * mask ;
  GtkStyle * style = gtk_widget_get_style (window) ;
  for (unsigned i = 0 ; i < obj_aims.size () ; i ++)
    if (obj_aims [i] == MIN_OBJ) {
      GdkPixmap * pixmap = gdk_pixmap_create_from_xpm (window -> window,
						       & mask,
						       & style-> bg [GTK_STATE_NORMAL],
						       "../pixmaps/min_obj.xpm") ;
      gtk_clist_set_pixmap (GTK_CLIST (obj_clist), i, 1, pixmap, mask) ;
    }
    else {
      GdkPixmap * pixmap = gdk_pixmap_create_from_xpm (window -> window,
						       & mask,
						       & style-> bg [GTK_STATE_NORMAL],
						       "../pixmaps/max_obj.xpm") ;
      gtk_clist_set_pixmap (GTK_CLIST (obj_clist), i, 1, pixmap, mask) ;
    
    }
}

void show_main_window (bool _b = true) {
  
  if (_b)
    gtk_widget_show (window) ;
  else
    gtk_widget_hide (window) ;
}
