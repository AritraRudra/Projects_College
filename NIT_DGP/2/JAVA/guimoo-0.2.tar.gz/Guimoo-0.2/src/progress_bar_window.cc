// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "progress_bar_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkprogressbar.h>

#include "progress_bar_window.h"

ProgressBarWindow :: ProgressBarWindow (unsigned _max_value,
					unsigned * _count
					) : max_value (_max_value),
					    count (_count) {
  
  // Window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_window_set_title (GTK_WINDOW (window), "Processing") ;
  gtk_widget_show (window) ;

  // Progress-bar
  progress_bar = gtk_progress_bar_new () ;
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (progress_bar),
				  GTK_PROGRESS_CONTINUOUS) ;
  gtk_widget_set_usize(progress_bar, 400, 30);
  gtk_container_add (GTK_CONTAINER (window), progress_bar) ;
  gtk_widget_show (progress_bar) ;
  //  gtk_progress_configure(GTK_PROGRESS (progress_bar), 0, 0, _max_value) ;
}

gint ProgressBarWindow :: update (gpointer _data) {
  
  ProgressBarWindow * progress_bar_window = (ProgressBarWindow *) _data ;

  gtk_progress_bar_update (GTK_PROGRESS_BAR (progress_bar_window -> progress_bar),
			   * (progress_bar_window -> count) / progress_bar_window -> max_value
			   ) ;
  
  //gtk_progress_bar_update (GTK_PROGRESS_BAR (progress_bar), _perc) ;
  
  //if (p == 1)
  //  gtk_widget_destroy (window) ;
  
  return true ;
}

