// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "entropy.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <math.h>
#include <gtk/gtkmain.h>
#include <pthread.h>

#include "po_set.h"
#include "table_window.h"
//#include "progress_bar_window.h"
#include "normal.h"
#include "objectives.h"
 
static void compute_union (const POSet & _pset1, const POSet & _pset2, POSet & _pset) {
  
  _pset = _pset1 ;
  for (unsigned i = 0 ; i < _pset2.size () ; i ++) {
    bool b = false ;
    for (unsigned j = 0 ; j < _pset1.size () ; j ++)
      if (_pset1 [j] == _pset2 [i]) {
	b = true ;
	break ;
      }
    if (! b)
      _pset.push_back (_pset2 [i]) ;
  }
}

static void remove_dominated (POSet & _pset) {
  
  for (unsigned i = 0 ; i < _pset.size () ; i ++) {
    
    bool dom = false ; // Dominated ?

    for (unsigned j = 0 ; j < _pset.size () ; j ++)
      if (i != j && _pset [i] < _pset [j]) {	
	dom = true ;
	break ;
      }
    
    if (dom) {
      
      _pset [i] = _pset.back () ;
      _pset.pop_back () ;
      i -- ;
    }
  }
}

static unsigned how_many_in_niche_of (const POSet & _pset, const MOSolution & _sol, unsigned _size_pset_star) {
  
  unsigned n = 0, num_obj = obj_labels.size () ;
  
  for (unsigned i = 0 ; i < _pset.size () ; i ++) {
    if (_pset [i].distance (_sol, 2, false) < (float) num_obj / _size_pset_star)
      n ++ ;
  }
  return n ;
}

/*
static void validate (const POSet & _pset1, const POSet & _pset2) {
  
  for (unsigned i = 0 ; i < _pset1.size () ; i ++)
    if (_pset1 [i] != _pset2 [i]) {
      cout << "Arghhh !!!!" << endl ;
    }
}
*/
static float entropy (const POSet & _pset1, const POSet & _pset2) {
  
  // Normalization
  POSet pset1 = _pset1, pset2 = _pset2 ;
  
  prenormalize (pset1) ;
  normalize (pset1) ;
  normalize (pset2) ;

  // Making of PO*
  POSet pset_star ; // rotf :-)
  compute_union (pset1, pset2, pset_star) ;
  remove_dominated (pset_star) ;
  
  // Making of PO1 U PO*
  POSet un_pset1_pset_star ; // rotf again ...
  compute_union (pset1, pset_star, un_pset1_pset_star) ;
  
  unsigned C = un_pset1_pset_star.size () ;

  float omega = 0, entr = 0 ;
  
  for (unsigned i = 0 ; i < C ; i ++) {
    
    unsigned N_i = how_many_in_niche_of (un_pset1_pset_star, un_pset1_pset_star [i], pset_star.size ()) ;
    
    unsigned n_i = how_many_in_niche_of (pset1, un_pset1_pset_star [i], pset_star.size ()) ;
   
    if (n_i > 0) {
      omega += 1.0 / N_i ;
      entr += (float) n_i / (N_i * C) * log ((float) n_i / C) / log (2) ; 
    }  
  }
 
  entr /= - log (omega) ;
  entr *= log (2) ;

  return entr ;
}

void open_entropy_window () {

  unsigned num_PO_sets = PO_sets.size () ;
  
  TableWindow * tab_win = new TableWindow ("Entropy", num_PO_sets + 1, num_PO_sets + 1) ;
 
  // Setting titles ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    tab_win -> set_text (0, i + 1, PO_sets [i].name ().c_str ()) ;
    tab_win -> set_text (i + 1, 0, PO_sets [i].name ().c_str ()) ;
  }
  
  //  unsigned count = 0 ;

  //  ProgressBarWindow * progress_bar = new ProgressBarWindow (num_PO_sets * num_PO_sets, & count) ;
  
  /*  gtk_timeout_add(100,
		  ProgressBarWindow :: update,
		  progress_bar) ;
  */
  // Filling the table ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    tab_win -> set_float (i + 1, i + 1, 0) ;
    
    for (unsigned j = 0 ; j < num_PO_sets ; j ++) {
      //count ++ ;      
      
      if (i != j) {
	//cout << "Fronts pareto " << i << " et " << j << endl ;
	float f = entropy (PO_sets [i], PO_sets [j]) ;
	tab_win -> set_float (i + 1, j + 1, f) ;
      }
    }
  }
}
