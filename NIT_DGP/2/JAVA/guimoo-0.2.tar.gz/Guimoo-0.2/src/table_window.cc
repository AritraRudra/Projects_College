// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "table_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkdialog.h>
#include <gtk/gtktable.h>
#include <gtk/gtkvbox.h>
#include <gtk/gtkentry.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtkscrolledwindow.h>
#include <gtk/gtksignal.h>

#include <strstream>

#include "table_window.h"

TableWindow :: TableWindow (const char * _name_win,
			    unsigned _num_row,
			    unsigned _num_col
			    ) {
  
  // Entries
  entry = new GtkWidget * * [_num_row] ;
  for (unsigned i = 0 ; i < _num_row ; i ++)
    entry [i] = new GtkWidget * [_num_col] ;
  
  // Scrolled window
  /*
  GtkWidget * scroll_win = gtk_scrolled_window_new (0, 0) ;
  gtk_widget_set_usize (scroll_win, 350, 150) ;
  gtk_widget_show (scroll_win) ;
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scroll_win),
				  GTK_POLICY_AUTOMATIC,
				  GTK_POLICY_AUTOMATIC);
  */

  // Window
  GtkWidget * dialog = gtk_dialog_new () ;
  gtk_window_set_title (GTK_WINDOW (dialog), _name_win) ;
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (dialog), 10) ;

  // Table
  //GtkWidget * vbox = gtk_vbox_new (FALSE, 0) ;
  //gtk_widget_show (vbox) ;

  GtkWidget * table = gtk_table_new (_num_row, _num_col, FALSE) ;
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog) -> vbox), table, TRUE, TRUE, 0) ;  
  //gtk_box_pack_start (GTK_BOX (vbox), table, FALSE, FALSE, 2) ;
  //gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (scroll_win), vbox) ;
  gtk_table_set_row_spacings (GTK_TABLE (table), 5) ;
  gtk_table_set_col_spacings (GTK_TABLE (table), 5) ;

  // Setting entries ...
  for (unsigned i = 0 ; i < _num_row ; i ++)
    for (unsigned j = 0 ; j < _num_col ; j ++) {
	entry [i] [j] = gtk_entry_new () ;
	//if (i != 0 || j != 0)
	  gtk_widget_show (entry [i] [j]) ;
	gtk_entry_set_editable (GTK_ENTRY (entry [i] [j]), false) ;
	gtk_table_attach_defaults (GTK_TABLE (table), entry [i] [j], j, j + 1, i, i + 1) ;
    }

  // Button OK
  GtkWidget * button = gtk_button_new_with_label ("   Ok   ") ;
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog) -> action_area), button, FALSE, FALSE, 0) ;
  gtk_widget_show (button) ;
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
			     GTK_SIGNAL_FUNC (gtk_widget_destroy),
			     GTK_OBJECT (dialog)) ;
  
  gtk_widget_show (table) ;
  gtk_widget_show (dialog) ;  
}

void TableWindow :: set_text (unsigned _row, unsigned _col, const char * _txt) {
  
  gtk_entry_set_text (GTK_ENTRY (entry [_row] [_col]), _txt) ;
}

void TableWindow :: set_float (unsigned _row, unsigned _col, float _f) {
  
  ostrstream o ;

  o << _f << '\0' ;
  gtk_entry_set_text (GTK_ENTRY (entry [_row] [_col]), o.str ()) ;
}
