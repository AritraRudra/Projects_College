// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "correl.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <math.h>

#include "table_window.h"
#include "objectives.h"
#include "po_set.h"
#include "normal.h"
#include "center.h"

static float variance (POSet & _pset,
		       unsigned _num_obj
		       /*unsigned _num_PO_set*/) {
  
  float var = 0 ;
  
  //  POSet p = PO_sets [_num_PO_set] ;

  for (unsigned i = 0 ; i < _pset.size () ; i ++) {
    float f = _pset [i] [_num_obj] ;
    var += f * f ;
  }
  return var / _pset.size () ;
}

static float covariance (POSet & _pset,
			 unsigned _num_obj1,
			 unsigned _num_obj2
			 /*unsigned _num_PO_set*/) {
  
  float covar = 0 ;
  
  //  POSet p = PO_sets [_num_PO_set] ;
 
  for (unsigned i = 0 ; i < _pset.size () ; i ++)
    covar += _pset [i] [_num_obj1] * _pset [i] [_num_obj2] ;
  
  return covar / _pset.size () ;
}

void open_correl_window () {
  

  unsigned num_PO_sets = PO_sets.size () ;
  unsigned num_obj = obj_labels.size () ;
  
  vector <POSet> p = PO_sets ;
  prenormalize (p [0]) ;
  
  for (unsigned i = 0 ; i < p.size () ; i ++)
    normalize (p [i]) ;

  TableWindow * tab_win = new TableWindow ("Correlation",
					   num_PO_sets + 1,
					   (num_obj * (num_obj - 1)) / 2 + 1) ; 
  // PO_sets titles
  for (unsigned i = 0 ; i < p.size () ; i ++)
    tab_win -> set_text (i + 1, 0, p [i].name ().c_str ()) ;
  
  // Co-Objectives titles
  unsigned c = 1 ;
  for (unsigned i = 0 ; i < num_obj ; i ++)
    for (unsigned j = i + 1 ; j < num_obj ; j ++) {
      string s = obj_labels [i] + " / " + obj_labels [j] ;
      tab_win -> set_text (0, c ++ , s.c_str ()) ; // Lol 
    }
  
  // Filling the table ...
  c = 1 ;
  for (unsigned i = 0 ; i < num_obj ; i ++)
    for (unsigned j = i + 1 ; j < num_obj ; j ++) {
      for (unsigned k = 0 ; k < num_PO_sets ; k ++)
        tab_win -> set_float (k + 1, c, covariance (p [k], i, j) / (sqrt (variance (p [k], i)) * sqrt (variance (p [k], j)))) ; 
      c ++ ;
    }
}
