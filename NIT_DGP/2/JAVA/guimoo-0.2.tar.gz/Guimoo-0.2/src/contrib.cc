// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "contrib.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkmain.h>

#include "po_set.h"
#include "table_window.h"
//#include "progress_bar_window.h"

static unsigned card_C (const POSet & _pset1, const POSet & _pset2) {
  // Returns the number of solutions both in '_pset1' and '_pset2'
  
  unsigned c = 0 ;
  
  for (unsigned i = 0 ; i < _pset1.size () ; i ++)
    for (unsigned j = 0 ; j < _pset2.size () ; j ++)
      if (_pset1 [i] == _pset2 [j]) {
	c ++ ;
	break ;
      }
  return c ;
}

static unsigned card_W (const POSet & _pset1, const POSet & _pset2) {
  // Returns the number of solutions in '_pset1' dominating at least one of '_pset2'
  
  unsigned w = 0 ;
  
  for (unsigned i = 0 ; i < _pset1.size () ; i ++)
    for (unsigned j = 0 ; j < _pset2.size () ; j ++)
      if (_pset1 [i] > _pset2 [j]) {
	w ++ ;
	break ;
      }
  return w ;
}

static unsigned card_N (const POSet & _pset1, const POSet & _pset2) {
  /* Returns the number of solutions in '_pset1' having no relation of dominance
     with those from '_pset2' */
  
  unsigned n = 0 ;

  for (unsigned i = 0 ; i < _pset1.size () ; i ++) {
    bool domin_rel = false ;
    for (unsigned j = 0 ; j < _pset2.size () ; j ++)
      if (_pset1 [i] > _pset2 [j] || _pset1 [i] < _pset2 [j] || _pset1 [i] == _pset2 [j]) {
	domin_rel = true ;
	break ;
      }
    if (! domin_rel)
      n ++ ;
  }
  return n ;
}

static float contribution (const POSet & _pset1, const POSet & _pset2) {
  // To complete ...
  
  unsigned c = card_C (_pset1, _pset2), w1 = card_W (_pset1, _pset2), n1 = card_N (_pset1, _pset2),
    w2 = card_W (_pset2, _pset1), n2 = card_N (_pset2, _pset1) ;
  
  return (float) (c / 2.0 + w1 + n1) / (c + w1 + n1 + w2 + n2) ;
}


void open_contrib_window () {
   
  unsigned num_PO_sets = PO_sets.size () ;
  
  TableWindow * tab_win = new TableWindow ("Contribution", num_PO_sets + 1, num_PO_sets + 1) ;
  
  // Setting titles ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    tab_win -> set_text (0, i + 1, PO_sets [i].name ().c_str ()) ;
    tab_win -> set_text (i + 1, 0, PO_sets [i].name ().c_str ()) ;
  }
  
  //unsigned count = 0 ;

  //  ProgressBarWindow * progress_bar = new ProgressBarWindow ((num_PO_sets * (num_PO_sets - 1)) / 2,
  //				    & count) ;

//  gtk_timeout_add(100,
//	  ProgressBarWindow :: update,
//	  progress_bar) ;
     
  // Filling the table ...
  for (unsigned i = 0 ; i < num_PO_sets ; i ++) {
    tab_win -> set_float (i + 1, i + 1, 0) ;
    
    for (unsigned j = i + 1 ; j < num_PO_sets ; j ++) {
      
      //    count ++ ;
      
      float f = contribution (PO_sets [i], PO_sets [j]) ;
      tab_win -> set_float (i + 1, j + 1, f) ;
      tab_win -> set_float (j + 1, i + 1, 1 - f) ;
    }
  }
  //  gtk_timeout_remove( gint tag );
}
