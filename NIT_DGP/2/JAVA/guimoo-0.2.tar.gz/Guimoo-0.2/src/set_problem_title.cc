// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "set_problem_title.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtklabel.h>
#include <gtk/gtkentry.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtkhbox.h>
#include <gtk/gtksignal.h>

#include "objectives.h"
#include "set_number_of_objectives.h"

static GtkWidget * title_entry ;

static void ok_pushed (GtkWidget * widget, GtkWindow * old_win) {
  
  probl_label.assign (gtk_entry_get_text (GTK_ENTRY (title_entry))) ;
  // Destroying the window
  gtk_object_destroy (GTK_OBJECT (old_win)) ;
  // To Next step
  set_number_of_objectives () ;
}


void set_problem_title () {
  
  // Window
  GtkWidget * window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_title (GTK_WINDOW (window), "New problem") ;
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
   
  // Horizontal box
  GtkWidget * hbox = gtk_hbox_new (FALSE, 10) ;  
  gtk_container_add (GTK_CONTAINER (window), hbox) ;
  gtk_widget_show (hbox) ;  
  
  // Label
  GtkWidget * label = gtk_label_new ("Title of the new problem") ;
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 2) ;
  gtk_widget_show (label) ;

  // Text entry
  title_entry = gtk_entry_new () ;  
  gtk_box_pack_start (GTK_BOX (hbox), title_entry, FALSE, FALSE, 2) ;
  gtk_widget_show (title_entry) ;

  // Button 'OK'
  GtkWidget * button = gtk_button_new_with_label ("  Ok  ") ;
  gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 2) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (ok_pushed), window);
  gtk_widget_show (button) ;

  gtk_widget_show (window) ;
}
