// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "export_eps.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkfilesel.h>
#include <gtk/gtksignal.h>

#include "gnuplot.h"

static void ok_pushed (GtkWidget * widget, GtkFileSelection * file_sel) {
  
  export_eps (gtk_file_selection_get_filename (GTK_FILE_SELECTION (file_sel))) ;

  // Destroying the window
  gtk_object_destroy (GTK_OBJECT (file_sel)) ;
}

void export_eps () {
  
  GtkWidget * file_sel = gtk_file_selection_new ("Export as EPS") ;
  
  gtk_file_selection_hide_fileop_buttons (GTK_FILE_SELECTION (file_sel)) ;
  
  // Ok
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> ok_button),
		      "clicked", (GtkSignalFunc) ok_pushed, file_sel) ;
  // Cancel
  gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> cancel_button),
			     "clicked", (GtkSignalFunc) gtk_widget_destroy,
			     GTK_OBJECT (file_sel)) ;
  
  gtk_widget_show (file_sel) ;  
}
