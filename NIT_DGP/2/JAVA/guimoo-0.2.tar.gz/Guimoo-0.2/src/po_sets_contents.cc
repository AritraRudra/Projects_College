// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "po_sets_contents.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkscrolledwindow.h>
#include <gtk/gtknotebook.h>
#include <gtk/gtklabel.h>
#include <gtk/gtkclist.h>

#include <stdio.h>
#include <strstream.h>
#include <algorithm>
#include <function.h>

#include "po_set.h"
#include "objectives.h"
#include "gnuplot.h"
#include "quit.h"

static GtkWidget * notebook, * window ;
static vector <vector <MOSolution *> > psets ; // The displayed Pareto sets
static vector <GtkWidget *> clists ; // ... and the associated clists

struct comp : public binary_function <MOSolution *, MOSolution *, bool> {
  // To compare the two MO solutions within the considered objective
  
  unsigned num_obj ;
  
  bool operator() (const MOSolution * _sol1, const MOSolution * _sol2) const {
    
    if (obj_aims [num_obj] == MAX_OBJ)
      return (* _sol1) [num_obj] > (* _sol2) [num_obj] ;
    else
      return (* _sol1) [num_obj] < (* _sol2) [num_obj] ;
  }
} ;

void show_PO_sets_contents (bool _b = true) {
  
  if (_b)
    gtk_widget_show (window) ;
  else
    gtk_widget_hide (window) ;
}

void update_PO_sets_contents () {
  
  unsigned num_obj = obj_labels.size () ;
  psets.clear () ;
  
  // Pset
  for (unsigned i = 0 ; i < PO_sets.size () ; i ++) {
    
    vector <MOSolution *> v ;
    gtk_clist_freeze (GTK_CLIST (clists [i]));
    
    // Clear ...
    gtk_clist_clear (GTK_CLIST (clists [i])) ;

    // Preprocessing ...
    char * t [num_obj] ;
    for (unsigned j = 0 ; j < num_obj ; j ++)
      t [j] = (char *) obj_labels [j].c_str () ;

    for (unsigned j = 0 ; j < PO_sets [i].size () ; j ++)
      gtk_clist_append (GTK_CLIST (clists [i]), t) ;
     
    
    for (unsigned j = 0 ; j < PO_sets [i].size () ; j ++) {
      
      // Filling
      v.push_back (& (PO_sets [i] [j])) ;
      for (unsigned k = 0 ; k < num_obj ; k ++) {
	// Arghh !!!! That's ugly :-/
	ostrstream o ;
	o << PO_sets [i] [j] [k] << '\0' ;
	char * marcel = o.str () ;
	gtk_clist_set_text (GTK_CLIST (clists [i]), j, k, marcel) ;
	free (marcel) ;
      }
    }
   
    gtk_clist_thaw (GTK_CLIST (clists [i]));
    psets.push_back (v) ;
  }
}

static void column_clicked (GtkWidget * _widget, gint _column, gpointer * _p) {  
  
  unsigned n = (unsigned) _p ;
    
  vector <MOSolution *> & sorted_pset = psets [n] ;
 
  comp _comp ;
  _comp.num_obj = _column ;
  sort (sorted_pset.begin (), sorted_pset.end (), _comp) ;
  
  unsigned num_obj = obj_labels.size () ;
  gtk_clist_freeze (GTK_CLIST (clists [n]));
  
  // Filling the list ...
  for (unsigned i = 0 ; i < sorted_pset.size () ; i ++) { 
    for (unsigned j = 0 ; j < num_obj ; j ++) {
      // Arghh !!!! That's ugly :-/
      ostrstream o ;
      o << sorted_pset [i] -> operator [] (j) << '\0' ;
      gtk_clist_set_text (GTK_CLIST (clists [n]), i, j, o.str ()) ;
    }
  }
  gtk_clist_thaw (GTK_CLIST (clists [n]));
}

GtkWidget * open_PO_sets_contents_window () {
  
  // Scrolling
  GtkWidget *scroll_win = gtk_scrolled_window_new (0, 0) ;
  gtk_widget_set_usize (scroll_win, 430, 150) ;
  gtk_widget_show (scroll_win) ;  
  
  // Notebook
  notebook = gtk_notebook_new () ;
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (scroll_win), notebook) ;
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_LEFT) ;
  gtk_widget_show (notebook) ;
  
  // Window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_modal (GTK_WINDOW (window), false) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_window_set_title (GTK_WINDOW (window), "Contents of PO* files") ;
  gtk_widget_set_uposition (window, 570, 40) ;
  //  gtk_widget_show (window) ;
  gtk_container_add (GTK_CONTAINER (window), scroll_win) ;
  gtk_signal_connect (GTK_OBJECT (window), "destroy", GTK_SIGNAL_FUNC (quit), NULL) ;

  return window ;
}

static vector <MOSolution *> selected_solutions () {
  // Returns a set of Multi-Objective that are selected in the list ...

    vector <MOSolution *> v ;
    
    for (unsigned i = 0 ; i < clists.size () ; i ++) {
      
      GList * sel = GTK_CLIST (clists [i]) -> selection ;
      
      while (sel) {
	//cout << "truc : " << (int) sel -> data << endl ;
	v.push_back (psets [i] [(unsigned) sel-> data]) ;
	sel = sel -> next ;
      }
    }
    return v ;
}

void visual_add_selected_MO_solutions () {
  
  plot (selected_solutions ()) ;
}

void add_PO_set_contents (POSet & _pset) {
  
  GtkWidget * label = gtk_label_new (_pset.name ().c_str ());
  
  unsigned num_obj = obj_labels.size () ;
  
  // Setting objectives labels
  char * t [num_obj] ;
  for (unsigned i = 0 ; i < num_obj ; i ++)
    t [i] = (char *) obj_labels [i].c_str () ;
 
  GtkWidget * clist = gtk_clist_new_with_titles (num_obj, t) ;
  gtk_clist_set_selection_mode (GTK_CLIST (clist), GTK_SELECTION_EXTENDED) ;

  // Setting columns justif.
  for (unsigned i = 0 ; i < num_obj ; i ++) {
    gtk_clist_set_column_justification (GTK_CLIST (clist), i, GTK_JUSTIFY_CENTER) ;
    gtk_clist_set_column_width (GTK_CLIST (clist), i, 300 / num_obj) ; 
  }
  
  // Preprocessing ...
  for (unsigned i = 0 ; i < _pset.size () ; i ++)
    gtk_clist_append (GTK_CLIST (clist), t) ;

  // Filling the list ...
  for (unsigned i = 0 ; i < _pset.size () ; i ++) { 
    for (unsigned j = 0 ; j < num_obj ; j ++) {
      // Arghh !!!! That's ugly :-/
      ostrstream o ;
      o << _pset [i] [j] << '\0' ;
      gtk_clist_set_text (GTK_CLIST (clist), i, j, o.str ()) ;
    }
  }
  gtk_widget_show (clist) ;  
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), clist, label) ;
  
  // Bla bla bla ...
  vector <MOSolution *> v ;
  for (unsigned i = 0 ; i < _pset.size () ; i ++)
    v.push_back (& (_pset [i])) ;
  psets.push_back (v) ;

  clists.push_back (clist) ;
  unsigned cpt = psets.size () - 1 ;

  // Binding events ...  
  gtk_signal_connect (GTK_OBJECT (clist), "click_column",
		      GTK_SIGNAL_FUNC (column_clicked),
		      (void *) cpt /* Beurk :-) !!! */) ;
  //  show_PO_sets_contents () ;
}

void clear_PO_sets_contents () {
    
  for (unsigned i = 0 ; i < psets.size () ; i ++) {
    gtk_clist_clear (GTK_CLIST (clists [i])) ;  
    gtk_notebook_remove_page (GTK_NOTEBOOK (notebook), 0) ;
  }
  psets.clear () ;
  clists.clear () ;
}

