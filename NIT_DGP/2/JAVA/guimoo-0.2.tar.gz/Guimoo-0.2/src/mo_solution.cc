// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "mo_solution.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <math.h>

#include "mo_solution.h"
#include "objectives.h"

bool MOSolution :: operator > (const MOSolution & sol) const {
  
  unsigned num_obj = obj_labels.size () ;
  for (unsigned char i = 0 ; i < num_obj ; i ++)
    if ((obj_aims [i] == MAX_OBJ && operator [] (i) < sol [i]) ||
	(obj_aims [i] == MIN_OBJ && operator [] (i) > sol [i]))
      return false ;

  for (unsigned char i = 0 ; i < num_obj ; i ++)
    if ((obj_aims [i] == MAX_OBJ && operator [] (i) > sol [i]) ||
	(obj_aims [i] == MIN_OBJ && operator [] (i) < sol [i]))
      return true ;
  
  return false ;
  
}

bool MOSolution :: operator < (const MOSolution & sol) const {
  
  return sol > * this ;
}

bool MOSolution :: operator == (const MOSolution & sol) const {
  
  unsigned char num_obj = obj_labels.size () ;
  for (unsigned char i = 0 ; i < num_obj ; i ++)
    if (operator [] (i) != sol [i])
      return false ;
  return true ;
}

float MOSolution :: distance (const MOSolution & _sol, unsigned char _deg = 2, bool _with_norm = true) const {
  
  float d = 0 ;
  unsigned num_obj = obj_labels.size () ;

  for (unsigned char i = 0 ; i < num_obj ; i ++)
    d += pow (fabs (operator [] (i) - _sol [i]), _deg) ;
  
  if (_with_norm)
    return pow (d / num_obj, 1.0 / _deg) ;
  else
    return pow (d, 1.0 / _deg) ;
} 

ostream & operator << (ostream & out, const MOSolution & sol) {
  
  unsigned char num_obj = obj_labels.size () ;
  for (unsigned char i = 0 ; i < num_obj ; i ++) {
    out << sol [i] ;
    if (i < num_obj - 1)
      out << ", " ;
  }
  return out ;
}

istream & operator >> (istream & in, MOSolution & sol) {
  
  float f ;

  sol.clear () ;
  unsigned char num_obj = obj_labels.size () ;
  for (unsigned char i = 0 ; i < num_obj ; i ++) {
    in >> f ;
    sol.push_back (f) ;
  }  
  return in ;
}

