// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "warning_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkdialog.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtkhbox.h>
#include <gtk/gtkvbox.h>
#include <gtk/gtkpixmap.h>
#include <gtk/gtklabel.h>
#include <gtk/gtksignal.h>

void open_warning_window (const char * _mess) {
  
  // Dialog
  GtkWidget * dialog = gtk_dialog_new () ;
  gtk_window_set_title (GTK_WINDOW (dialog), "Warning") ;
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (dialog), 10) ;
  gtk_widget_show (dialog) ;

  // Horizontal box
  GtkWidget * hbox = gtk_hbox_new (FALSE, 0) ;
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog) -> vbox),
  		      hbox, TRUE, TRUE, 2) ;
  gtk_widget_show (hbox) ;

  // Pixmap Warning !!!
  GdkBitmap * mask ;
  GtkStyle * style = gtk_widget_get_style (dialog) ;
  GdkPixmap * pixmap = gdk_pixmap_create_from_xpm (dialog -> window, & mask,
						   & style -> bg [GTK_STATE_NORMAL],
						   "../pixmaps/warning.xpm");
  GtkWidget * warning = gtk_pixmap_new (pixmap, mask) ;
  gtk_box_pack_start (GTK_BOX (hbox), warning, TRUE, TRUE, 2) ;
  gtk_widget_show (warning) ;
  
  // Label
  GtkWidget * label = gtk_label_new (_mess) ;
  gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 2) ;
  gtk_widget_show (label) ;

  // Button OK
  GtkWidget * button = gtk_button_new_with_label ("   Ok   ") ;
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog) -> action_area), button, FALSE, FALSE, 0) ;
  gtk_widget_show (button) ;
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
			     GTK_SIGNAL_FUNC (gtk_widget_destroy),
			     GTK_OBJECT (dialog)) ;
}
