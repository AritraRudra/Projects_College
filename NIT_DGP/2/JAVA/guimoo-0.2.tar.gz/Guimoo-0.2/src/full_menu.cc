// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "full_menu.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkmenu.h>
#include <gtk/gtkmenubar.h>
#include <gtk/gtkmenuitem.h>
#include <gtk/gtksignal.h>

#include "set_problem_title.h"
#include "about.h"
#include "gnuplot.h"
#include "quit.h"
#include "contrib.h"
#include "entropy.h"
#include "correl.h"
#include "gen_dist.h"
#include "spacing.h"
#include "po_sets_list.h"
#include "po_sets_contents.h"
#include "export_eps.h"
#include "export_png.h"
#include "load_problem.h"
#include "save_problem.h"
#include "load_file.h"
#include "clear.h"


static GtkWidget * file_menu () {

    GtkWidget * file_menu = gtk_menu_new () ;

    // New problem
    GtkWidget * new_problem_item = gtk_menu_item_new_with_label ("New problem") ;
    gtk_menu_append (GTK_MENU (file_menu), new_problem_item) ;
    gtk_widget_show (new_problem_item) ;
    gtk_signal_connect(GTK_OBJECT (new_problem_item), "activate",
		       GTK_SIGNAL_FUNC (set_problem_title), NULL);
    // Open problem
    GtkWidget * open_problem_item = gtk_menu_item_new_with_label ("Open problem") ;
    gtk_menu_append (GTK_MENU (file_menu), open_problem_item) ;
    gtk_signal_connect(GTK_OBJECT (open_problem_item), "activate",
		       GTK_SIGNAL_FUNC (load_problem), NULL);
    gtk_widget_show (open_problem_item) ;
   
    // Save problem
    GtkWidget * save_problem_item = gtk_menu_item_new_with_label ("Save problem") ;
    gtk_menu_append (GTK_MENU (file_menu), save_problem_item) ;
    gtk_widget_show (save_problem_item) ;
    gtk_signal_connect(GTK_OBJECT (save_problem_item), "activate",
		       GTK_SIGNAL_FUNC (save_problem), NULL);

    // --
    GtkWidget * sep_item = gtk_menu_item_new ();
    gtk_menu_append (GTK_MENU (file_menu), sep_item) ;
    gtk_widget_show (sep_item) ;

    // Open file
    GtkWidget * open_file_item = gtk_menu_item_new_with_label ("Open file") ;
    gtk_menu_append (GTK_MENU (file_menu), open_file_item) ;
    gtk_widget_show (open_file_item) ;
    gtk_signal_connect(GTK_OBJECT (open_file_item), "activate",
		       GTK_SIGNAL_FUNC (load_file), NULL) ;

    // Clear
    GtkWidget * clear_item = gtk_menu_item_new_with_label ("Clear") ;
    gtk_menu_append (GTK_MENU (file_menu), clear_item) ;
    gtk_widget_show (clear_item) ;
    gtk_signal_connect(GTK_OBJECT (clear_item), "activate",
		       GTK_SIGNAL_FUNC (clear_PO_sets), NULL) ;

    // --
    sep_item = gtk_menu_item_new () ;
    gtk_menu_append (GTK_MENU(file_menu), sep_item) ;
    gtk_widget_show (sep_item) ;

    // Quit
    GtkWidget * quit_item = gtk_menu_item_new_with_label ("Quit") ;
    gtk_menu_append (GTK_MENU (file_menu), quit_item) ;
    gtk_widget_show (quit_item) ;
    gtk_signal_connect (GTK_OBJECT (quit_item), "activate", GTK_SIGNAL_FUNC (quit), NULL) ;

    return file_menu;
}

static GtkWidget * metrics_menu () {

    GtkWidget * metrics_menu = gtk_menu_new () ;
    
    // Perf
    GtkWidget * perf_item = gtk_menu_item_new_with_label ("Perf.") ;
    gtk_menu_append (GTK_MENU (metrics_menu), perf_item) ;
    gtk_widget_show (perf_item) ;
    GtkWidget * perf_menu = gtk_menu_new () ;

    // Perf - Contribution
    GtkWidget * contrib_item = gtk_menu_item_new_with_label ("Contribution") ;
    gtk_menu_append (GTK_MENU (perf_menu), contrib_item) ;
    gtk_signal_connect (GTK_OBJECT (contrib_item), "activate", GTK_SIGNAL_FUNC (open_contrib_window), NULL) ;
    gtk_widget_show (contrib_item) ;

    // Perf - Entropy
    GtkWidget * entropy_item = gtk_menu_item_new_with_label ("Entropy") ;
    gtk_menu_append (GTK_MENU (perf_menu), entropy_item) ;
    gtk_signal_connect (GTK_OBJECT (entropy_item), "activate", GTK_SIGNAL_FUNC (open_entropy_window), NULL) ;
    gtk_widget_show (entropy_item) ;

    // Perf - --
    GtkWidget * sep_item = gtk_menu_item_new ();
    gtk_menu_append (GTK_MENU (perf_menu), sep_item) ;
    gtk_widget_show (sep_item) ;

    // Perf - Generational distance
    GtkWidget * gen_dist_item = gtk_menu_item_new_with_label ("Generational distance") ;
    gtk_menu_append (GTK_MENU (perf_menu), gen_dist_item) ;
    gtk_signal_connect (GTK_OBJECT (gen_dist_item), "activate", GTK_SIGNAL_FUNC (open_gen_dist_window), NULL) ;
    gtk_widget_show (gen_dist_item) ;
    
    // Perf - Spacing    
    GtkWidget * spacing_item = gtk_menu_item_new_with_label ("Spacing") ;
    gtk_menu_append (GTK_MENU (perf_menu), spacing_item) ;
    gtk_signal_connect (GTK_OBJECT (spacing_item), "activate", GTK_SIGNAL_FUNC (open_spacing_window), NULL) ;
    gtk_widget_show (spacing_item) ;

    gtk_menu_item_set_submenu (GTK_MENU_ITEM (perf_item), perf_menu) ;  

    // Info.
    GtkWidget * info_item = gtk_menu_item_new_with_label ("Info.") ;
    gtk_menu_append (GTK_MENU (metrics_menu), info_item) ;
    gtk_widget_show (info_item) ;
    GtkWidget * info_menu = gtk_menu_new () ;
        
    // Info - Correlation
    /*
    GtkWidget * correl_item = gtk_menu_item_new_with_label ("Correlation") ;
    gtk_menu_append (GTK_MENU (info_menu), correl_item) ;
    gtk_widget_show (correl_item) ;
    gtk_signal_connect (GTK_OBJECT (correl_item), "activate",
			GTK_SIGNAL_FUNC (open_correl_window), NULL);
    */  

    gtk_menu_item_set_submenu (GTK_MENU_ITEM (info_item), info_menu) ;      

    return metrics_menu ;
}

static GtkWidget * visual_menu () {
  
  GtkWidget * visual_menu = gtk_menu_new () ;
  
  // Show Pareto sets
  GtkWidget * show_sets_item = gtk_menu_item_new_with_label ("Add selected Pareto sets") ;
  gtk_menu_append (GTK_MENU (visual_menu), show_sets_item) ;
  gtk_signal_connect(GTK_OBJECT (show_sets_item), "activate",
		     GTK_SIGNAL_FUNC (visual_add_selected_PO_sets), NULL);
  gtk_widget_show (show_sets_item) ;

  // Show Solutions
  GtkWidget * show_sol_item = gtk_menu_item_new_with_label ("Add selected solutions") ;
  gtk_menu_append (GTK_MENU (visual_menu), show_sol_item) ;
  gtk_signal_connect(GTK_OBJECT (show_sol_item), "activate",
		     GTK_SIGNAL_FUNC (visual_add_selected_MO_solutions), NULL);
  gtk_widget_show (show_sol_item) ;
    
  // Clear
  GtkWidget * clear_item = gtk_menu_item_new_with_label ("Clear") ;
  gtk_menu_append (GTK_MENU (visual_menu), clear_item) ;
  gtk_widget_show (clear_item) ;
  gtk_signal_connect(GTK_OBJECT (clear_item), "activate",
		     GTK_SIGNAL_FUNC (clear_visualization), NULL) ;
  
  // --
  GtkWidget * sep_item = gtk_menu_item_new ();
  gtk_menu_append (GTK_MENU (visual_menu), sep_item) ;
  gtk_widget_show (sep_item) ;

  // Print
  GtkWidget * print_item = gtk_menu_item_new_with_label ("Print") ;
  gtk_menu_append (GTK_MENU (visual_menu), print_item) ;
  gtk_widget_show (print_item) ;
  gtk_signal_connect(GTK_OBJECT (print_item), "activate",
		     GTK_SIGNAL_FUNC (print), NULL) ;

  // --
  sep_item = gtk_menu_item_new ();
  gtk_menu_append (GTK_MENU (visual_menu), sep_item) ;
  gtk_widget_show (sep_item) ;

  // Export
  GtkWidget * export_item = gtk_menu_item_new_with_label ("Export") ;
  gtk_menu_append (GTK_MENU (visual_menu), export_item) ;
  gtk_widget_show (export_item) ;
  GtkWidget * export_menu = gtk_menu_new () ;

  // Export - png
  GtkWidget * export_png_item = gtk_menu_item_new_with_label ("(P)ortable (N)etwork (G)raphic") ;
  gtk_menu_append (GTK_MENU (export_menu), export_png_item) ;
  gtk_signal_connect (GTK_OBJECT(export_png_item), "activate",
  		      GTK_SIGNAL_FUNC(export_png), NULL) ;
  gtk_widget_show (export_png_item) ;
  
  // Export - eps
  GtkWidget * export_eps_item = gtk_menu_item_new_with_label("(E)ncapsulated (P)ost(S)cript") ;
  gtk_menu_append (GTK_MENU (export_menu), export_eps_item) ;
  gtk_signal_connect(GTK_OBJECT(export_eps_item), "activate",
		     GTK_SIGNAL_FUNC (export_eps), NULL) ;
  gtk_widget_show (export_eps_item) ;
  
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (export_item), export_menu) ;

  return visual_menu;
}

static GtkWidget * misc_menu () {

    GtkWidget * misc_menu = gtk_menu_new () ;

    // About ...
    GtkWidget * about_item = gtk_menu_item_new_with_label ("About") ;
    gtk_menu_append (GTK_MENU (misc_menu), about_item) ;
    gtk_signal_connect(GTK_OBJECT (about_item), "activate",
		       GTK_SIGNAL_FUNC (open_about_window), NULL);
    gtk_widget_show (about_item) ;
    
    return misc_menu ;
}

GtkWidget * open_full_menu () {
  
  // Menu-bar
  GtkWidget * menu_bar = gtk_menu_bar_new () ;
  
  // Menus
  
  // * File
  GtkWidget * file_item = gtk_menu_item_new_with_label ("File") ;
  gtk_widget_show (file_item) ;
  gtk_menu_bar_append (GTK_MENU_BAR (menu_bar), file_item) ;
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (file_item), file_menu ()) ;
  
  // * Visualization
  GtkWidget * visual_item = gtk_menu_item_new_with_label ("Visual.") ;
  gtk_widget_show (visual_item) ;
  gtk_menu_bar_append (GTK_MENU_BAR (menu_bar), visual_item) ;
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (visual_item), visual_menu ()) ;

  // * Metrics
  GtkWidget * metrics_item = gtk_menu_item_new_with_label ("Metrics") ;
  gtk_widget_show (metrics_item) ;
  gtk_menu_bar_append (GTK_MENU_BAR (menu_bar), metrics_item) ;
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (metrics_item), metrics_menu ()) ;

  // * Misc.
  GtkWidget * misc_item = gtk_menu_item_new_with_label ("Misc.") ;
  gtk_widget_show (misc_item) ;
  gtk_menu_bar_append (GTK_MENU_BAR (menu_bar), misc_item) ;
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (misc_item), misc_menu ()) ;
  
  gtk_widget_show (menu_bar) ;
  return menu_bar ;
}


