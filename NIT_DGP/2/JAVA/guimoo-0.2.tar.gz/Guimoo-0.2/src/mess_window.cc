// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "mess_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtksignal.h>
#include <gtk/gtktext.h>
#include <gtk/gtkadjustment.h>
#include <gtk/gtkscrolledwindow.h>
#include <gdk/gdktypes.h>

#include "quit.h"
#include "mess_window.h"

static GtkWidget * text ; // Shared text area

static GdkColormap * cmap ; // ???

static GdkColor color_red, color_blue, color_green ; // A few colors ...

static GdkFont * fixed_font ;

static GtkWidget * window ; // Window

void init_messages_window () {
  
  cmap = gdk_colormap_get_system () ;
  
  color_red.red = 0xffff ;
  color_red.green = 0 ;
  color_red.blue = 0 ;

  color_blue.red = 0 ;
  color_blue.green = 0 ;
  color_blue.blue = 0xffff ;

  color_green.red = 0 ;
  color_green.green = 0xffff ;
  color_green.blue = 0 ;

  fixed_font = gdk_font_load ("-misc-fixed-medium-r-*-*-*-120-*-*-*-*-*-*") ;
}

void show_messages_window (bool _b = true) {
  
  if (_b)
    gtk_widget_show (window) ;
  else
    gtk_widget_hide (window) ;
}

void open_messages_window () {
  
  // Window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_window_set_title (GTK_WINDOW (window), "Messages") ;
  gtk_widget_set_usize (window, 450, 220) ;
  gtk_widget_set_uposition (window, 20, 390) ;
  gtk_widget_realize (window) ;
  gtk_signal_connect (GTK_OBJECT (window), "destroy", GTK_SIGNAL_FUNC (quit), NULL) ;
  //gtk_widget_show (window) ;
  
  // Scrolling window
  GtkWidget * scroll_win = gtk_scrolled_window_new (0, 0) ;
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scroll_win),
				  GTK_POLICY_AUTOMATIC,
				  GTK_POLICY_AUTOMATIC) ;
  gtk_widget_show (scroll_win) ;
  gtk_container_add (GTK_CONTAINER (window), scroll_win) ;

  // Text
  text = gtk_text_new (0, 0) ;
  gtk_container_add (GTK_CONTAINER (scroll_win), text) ;
  gtk_widget_show (text) ;
}

void skip_line (unsigned _num_lines = 1) {
  
  for (unsigned i = 0 ; i < _num_lines ; i ++)
    gtk_text_insert (GTK_TEXT (text), 0, & color_blue, 0, "\n", -1) ;
}

void display_message (const char * _mess, TextColor _color = BLACK) {
  
  switch (_color) {
  
  case RED :
    gtk_text_insert (GTK_TEXT (text), 0, & color_red, 0,_mess, -1) ;
    break ;
  case BLUE :
    gtk_text_insert (GTK_TEXT (text), 0, & color_blue, 0,_mess, -1) ;
    break ;
  case GREEN :
    gtk_text_insert (GTK_TEXT (text), 0, & color_green, 0,_mess, -1) ;
    break ; 
  default : // Black
    gtk_text_insert (GTK_TEXT (text), 0, & text -> style -> black, 0, _mess, -1) ;
  }
}

void display_failed () {
  
  gtk_text_insert (GTK_TEXT (text), (GdkFont *) NULL, & color_red, (GdkColor *) NULL,
		   " [ Failed ]", -1) ;
  skip_line (2) ;
}

void display_OK () {
  
  gtk_text_insert (GTK_TEXT (text), (GdkFont *) NULL, & color_green, (GdkColor *) NULL,
		   "  [ OK ]", -1) ;
  skip_line (2) ;
}

/*
void display_separator () {
  
  gtk_text_insert (GTK_TEXT (text), 0, & text -> style -> black, 0, "------------------------------------------------------------\n", -1) ;
}
*/
