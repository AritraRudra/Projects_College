// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "defaults.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   license as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <stdlib.h>
#include <fstream>
#include <string>

#include "load_problem.h"
#include "load_file.h"
#include "po_set.h"
#include "mess_window.h"

#define MAX_LINE_LENGTH 200

void load_defaults () {
  
  const char * defaults_file = (string (getenv ("HOME")) + "/.guimoo").c_str () ;

  ifstream f (defaults_file) ;
  
  display_message (" # Loading ") ;
  display_message (defaults_file, BLUE) ;
  display_message (" ...\n") ;

  if (f) {
    
    display_message (" [ OK ]\n", GREEN) ;

    char buff [MAX_LINE_LENGTH] ;

    // # Generated automatically using guimoo version 0.2
    // # You shouldn't edit this file ! 
    // End of line
    // # Problem
    
    for (unsigned i = 0 ; i < 4 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    // Scaning the path of the current problem to load ...
    f.getline (buff, MAX_LINE_LENGTH) ; 
    //cout << "Loading " << buff << " ..." << endl ;
    
    load_problem (buff) ;
    
    // End of line
    // # PO* sets
    for (unsigned i = 0 ; i < 2 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    // Scaning the path of the stored PO* files to load ...
    while (! f.eof ()) {
      f.getline (buff, MAX_LINE_LENGTH) ;
      if (strlen (buff) > 0) {
	load_file (buff) ;
      }
    }
  }
  else
    display_failed () ;
}

void save_defaults () {
  
  cout << problem_file_name << endl ;
  if (problem_file_name != "") {
    ofstream f ((string (getenv ("HOME")) + "/.guimoo").c_str ()) ;
    
    f << "# Generated automatically using guimoo version 0.2" << endl ;
    f << "# You shouldn't edit this file !" << endl ;
    f << endl ;
    
    // Problem
    f << "# Problem" << endl ;
    f << problem_file_name << endl ;
    f << endl ;
  
    // Pareto Optimal sets
    f << "# PO* files" << endl ;
    for (unsigned i = 0 ; i < PO_sets.size () ; i ++)
      f << PO_sets [i].source () << endl ;
    
    f.close () ;
  }
}

