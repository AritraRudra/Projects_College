// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "mo_solution.h"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef mo_solution_h
#define mo_solution_h

#include <vector>
#include <iostream.h>

class MOSolution : public vector <float> {
  
public:
  
  bool operator > (const MOSolution & sol) const ;
  
  bool operator < (const MOSolution & sol) const ;
  
  bool operator == (const MOSolution & sol) const ;

  float distance (const MOSolution & _sol, unsigned char _deg = 2, bool _with_norm = true) const ;
  // Manhatanian ? :-0, when _deg = 1, euclidian when _deg = 2, ... 

private:
  
  // To an output stream
  friend ostream & operator << (ostream & out, const MOSolution & sol) ;
  
  // From an input stream
  friend istream & operator >> (istream & in, MOSolution & sol) ;  
} ;

ostream & operator << (ostream & out, const MOSolution & sol) ;

istream & operator >> (istream & in, MOSolution & sol) ;

#endif
