// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "tool_bar.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkhandlebox.h>
#include <gtk/gtkhbox.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtkpixmap.h>
#include <gtk/gtksignal.h>

#include "load_file.h"
#include "clear.h"
#include "po_sets_list.h"
#include "gnuplot.h"


static GtkWidget * open_file_button (GtkWidget * _win, GtkStyle * _style) {
    
  // Pixmap
  GdkPixmap * mask, * pixmap = gdk_pixmap_create_from_xpm (_win -> window,
							   & mask,
							   & _style-> bg [GTK_STATE_NORMAL],
							   "../pixmaps/open_file.xpm");
  GtkWidget * pixmap_wid = gtk_pixmap_new (pixmap, mask) ;
  gtk_widget_show (pixmap_wid) ;
  
  // Button
  GtkWidget * button = gtk_button_new () ;
  gtk_container_add (GTK_CONTAINER (button), pixmap_wid) ;
  gtk_widget_show (button) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (load_file), NULL) ;
  
  return button ;
}

static GtkWidget * clear_files_button (GtkWidget * _win, GtkStyle * _style) {
  
  // Pixmap
  GdkPixmap * mask, * pixmap = gdk_pixmap_create_from_xpm (_win -> window,
							   & mask,
							   & _style-> bg [GTK_STATE_NORMAL],
							   "../pixmaps/clear_files.xpm");
  GtkWidget * pixmap_wid = gtk_pixmap_new (pixmap, mask) ;
  gtk_widget_show (pixmap_wid) ;
  
  // Button
  GtkWidget * button = gtk_button_new () ;
  gtk_container_add (GTK_CONTAINER (button), pixmap_wid) ;
  gtk_widget_show (button) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (clear_PO_sets), NULL) ;
  
  return button ;
}

static GtkWidget * update_visual_button (GtkWidget * _win, GtkStyle * _style) {
  
  // Pixmap
  GdkPixmap * mask, * pixmap = gdk_pixmap_create_from_xpm (_win -> window,
							   & mask,
							   & _style-> bg [GTK_STATE_NORMAL],
							   "../pixmaps/add_visual.xpm");
  GtkWidget * pixmap_wid = gtk_pixmap_new (pixmap, mask) ;
  gtk_widget_show (pixmap_wid) ;
  
  // Button
  GtkWidget * button = gtk_button_new () ;
  gtk_container_add (GTK_CONTAINER (button), pixmap_wid) ;
  gtk_widget_show (button) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (visual_add_selected_PO_sets), NULL) ;
  
  return button ;
}

static GtkWidget * clear_visual_button (GtkWidget * _win, GtkStyle * _style) {
 
  // Pixmap
  GdkPixmap * mask, * pixmap = gdk_pixmap_create_from_xpm (_win -> window,
							   & mask,
							   & _style-> bg [GTK_STATE_NORMAL],
							   "../pixmaps/clear_visual.xpm");
  GtkWidget * pixmap_wid = gtk_pixmap_new (pixmap, mask) ;
  gtk_widget_show (pixmap_wid) ;
  
  // Button
  GtkWidget * button = gtk_button_new () ;
  gtk_container_add (GTK_CONTAINER (button), pixmap_wid) ;
  gtk_widget_show (button) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (clear_visualization), NULL) ;
  
  return button ;
}

GtkWidget * open_tool_bar (GtkWidget * _win) {
  
  // Handle Box
  GtkWidget * handle_box = gtk_handle_box_new () ;
  gtk_widget_show (handle_box) ;
  
  // Horizontal box
  GtkWidget * hbox = gtk_hbox_new (FALSE, 0) ;
  gtk_widget_show (hbox) ;
  gtk_container_add (GTK_CONTAINER (handle_box), hbox) ;
  
  // Style
  GtkStyle * style = gtk_widget_get_style (_win) ;
  
  // Buttons
  gtk_box_pack_start (GTK_BOX (hbox), open_file_button (_win, style), FALSE, FALSE, 0) ;
  gtk_box_pack_start (GTK_BOX (hbox), clear_files_button (_win, style), FALSE, FALSE, 0) ;
  gtk_box_pack_start (GTK_BOX (hbox), update_visual_button (_win, style), FALSE, FALSE, 0) ;
  gtk_box_pack_start (GTK_BOX (hbox), clear_visual_button (_win, style), FALSE, FALSE, 0) ;
  
  return handle_box ;
} 
