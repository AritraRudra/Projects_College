// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "load_problem.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkfilesel.h>
#include <gtk/gtksignal.h>

#include <fstream>
#include <strstream>

#include "objectives.h"
#include "main_window.h"
#include "warning_window.h"
#include "gnuplot.h"
#include "mess_window.h"
#include "clear.h"

#define MAX_LINE_LENGTH 200

string problem_file_name ;

void load_problem (const char * _file_name) {  
  
  char buff [MAX_LINE_LENGTH] ;
  
  problem_file_name = _file_name ;
  
  display_message (" # Loading ") ;
  display_message (_file_name, BLUE) ;
  display_message (" ...\n") ;

  ifstream f (_file_name) ;
  
  if (f) {
    // # Generated automatically using guimoo version 0.2
    // # You shouldn't edit this file ! 
    // End of line
    // # Title
    for (unsigned i = 0 ; i < 4 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    // Scaning title of the problem
    f.getline (buff, MAX_LINE_LENGTH) ; 
    probl_label.assign (buff) ;
    
    // End of line
    // # Objectives
    for (unsigned i = 0 ; i < 2 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    obj_labels.clear () ;
    obj_aims.clear () ;
    while (! f.eof ()) {
      // Aim of the objective
      f.scan ("%s", buff, MAX_LINE_LENGTH) ;
      if (! strcmp (buff, "Max."))
	obj_aims.push_back (MAX_OBJ) ;
      else
	obj_aims.push_back (MIN_OBJ) ;
    
      // Label of the objective
      f.getline (buff, MAX_LINE_LENGTH) ;
      obj_labels.push_back (buff) ;    
    }
    
    // Due to eof.
    obj_labels.pop_back () ;
    obj_aims.pop_back () ;
    
    f.close () ;
  
    update_main_window () ;  
    clear_PO_sets () ;
    reset_gnuplot () ;
    
    display_message (" [ OK ]", GREEN) ;
    skip_line (2) ;
  }
  else {
    display_message (" [ Failed ]", RED) ;
    skip_line (2) ;
  }
}

static void ok_pushed (GtkWidget * _widget, GtkFileSelection * _file_sel) {
  
  load_problem (gtk_file_selection_get_filename (GTK_FILE_SELECTION (_file_sel))) ;
  // Destroying the window
  gtk_object_destroy (GTK_OBJECT (_file_sel)) ;
}

void load_problem () {
  
  GtkWidget * file_sel = gtk_file_selection_new ("Load problem") ;
    
  gtk_file_selection_hide_fileop_buttons (GTK_FILE_SELECTION (file_sel)) ;
  
  // Ok
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> ok_button),
		      "clicked", (GtkSignalFunc) ok_pushed, file_sel) ;
  // Cancel
  gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_SELECTION (file_sel) -> cancel_button),
			     "clicked", (GtkSignalFunc) gtk_widget_destroy,
			     GTK_OBJECT (file_sel)) ;
  
  gtk_widget_show (file_sel) ;  
}

void taratata () {

char buff [MAX_LINE_LENGTH] ;

  ifstream f ("../examples/telecom") ;
  

    // # Generated automatically using guimoo version 0.2
    // # You shouldn't edit this file ! 
    // End of line
    // # Title
    for (unsigned i = 0 ; i < 4 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    // Scaning title of the problem
    f.getline (buff, MAX_LINE_LENGTH) ; 
    probl_label.assign (buff) ;
    
    // End of line
    // # Objectives
    for (unsigned i = 0 ; i < 2 ; i ++)
      f.getline (buff, MAX_LINE_LENGTH) ; 
    
    obj_labels.clear () ;
    obj_aims.clear () ;
    while (! f.eof ()) {
      // Aim of the objective
      f.scan ("%s", buff, MAX_LINE_LENGTH) ;
      if (! strcmp (buff, "Max."))
	obj_aims.push_back (MAX_OBJ) ;
      else
	obj_aims.push_back (MIN_OBJ) ;
      
      // Label of the objective
      f.getline (buff, MAX_LINE_LENGTH) ;
      obj_labels.push_back (buff) ;    
    }
    
    // Due to eof.
    obj_labels.pop_back () ;
    obj_aims.pop_back () ;
    
    f.close () ;

    update_main_window () ;
}
