// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "problem_file.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <fstream>
#include <stdio.h>

#include "objectives.h"
#include "main_window.h"

#define MAX_LINE_LENGTH 200

void load_problem (const char * _filename) {
  
  char buff [MAX_LINE_LENGTH] ;

  ifstream f (_filename) ;
  
  // # Generated automatically using guimoo version 0.2
  // # You shouldn't edit this file ! 
  // End of line
  // # Title
  for (unsigned i = 0 ; i < 4 ; i ++)
    f.getline (buff, MAX_LINE_LENGTH) ; 
  
  // Scaning title of the problem
  f.getline (buff, MAX_LINE_LENGTH) ; 
  probl_label.assign (buff) ;
  
  // End of line
  // # Objectives
  for (unsigned i = 0 ; i < 2 ; i ++)
    f.getline (buff, MAX_LINE_LENGTH) ; 
  
  obj_labels.clear () ;
  obj_aims.clear () ;
  while (! f.eof ()) {
    // Aim of the objective
    f.scan ("%s", buff, MAX_LINE_LENGTH) ;
    if (! strcmp (buff, "Max."))
      obj_aims.push_back (MAX_OBJ) ;
    else
      obj_aims.push_back (MIN_OBJ) ;
    
    // Label of the objective
    f.getline (buff, MAX_LINE_LENGTH) ;
    obj_labels.push_back (buff) ;    
  }
  
  // Due to eof.
  obj_labels.pop_back () ;
  obj_aims.pop_back () ;
  
  f.close () ;

  update_main_window () ;
}

void save_problem (const char * _filename) {
  
  ofstream f (_filename) ;
  
  f << "# Generated automatically using guimoo version 0.2" << endl ;
  f << "# You shouldn't edit this file !" << endl ;
  f << endl ;
  f << "# Title" << endl ;
  f << probl_label << endl ;
  f << endl ;
  f << "# Objectives" << endl ;
  for (unsigned i = 0 ; i < obj_labels.size () ; i ++) {
    f << obj_labels [i] << " : " ;
    if (obj_aims [i] == MAX_OBJ)
      f << "Max." << endl ;
    else
      f << "Min." << endl ;
  }
  f.close () ;
}

