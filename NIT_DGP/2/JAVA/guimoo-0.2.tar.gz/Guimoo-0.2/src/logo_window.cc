// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "logo_window.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkpixmap.h>
#include <gtk/gtkmain.h>

#include <unistd.h>

#include "main_window.h"
#include "po_sets_list.h"
#include "po_sets_contents.h"
#include "mess_window.h"

#define LOGO_SPAN 1000

static gint tag ; // For the destroying callback ...

static gint destroy_callback (gpointer data) {
  
  gtk_object_destroy (GTK_OBJECT (data)) ;  
  
  show_main_window () ;
  show_PO_sets_list () ;
  show_PO_sets_contents () ;
  show_messages_window () ;

  gtk_timeout_remove (tag) ;
  
  return 0 ;
}

void open_logo_window () {
  
  // Window
  GtkWidget * window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;  
  gtk_window_set_title (GTK_WINDOW (window), "Guimoo-0.2a") ;
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_widget_realize (window) ;

  // Pixmap
  GdkBitmap * mask ;
  GtkStyle * style = gtk_widget_get_style (window) ;
  GdkPixmap * pixmap = gdk_pixmap_create_from_xpm (window -> window,
						   & mask,
						   & style -> bg [GTK_STATE_NORMAL],
						   "../pixmaps/guimoo.xpm") ;
  
  GtkWidget * logo = gtk_pixmap_new (pixmap, mask) ;
  gtk_widget_show (logo) ;
  gtk_container_add (GTK_CONTAINER (window), logo) ;
  
  gtk_widget_show (window) ;

  tag = gtk_timeout_add (LOGO_SPAN, destroy_callback, window) ;
}


