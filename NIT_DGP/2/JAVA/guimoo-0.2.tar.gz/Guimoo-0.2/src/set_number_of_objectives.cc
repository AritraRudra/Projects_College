// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "set_number_of_objectives.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <gtk/gtkwindow.h>
#include <gtk/gtkhbox.h>
#include <gtk/gtklabel.h>
#include <gtk/gtkspinbutton.h>
#include <gtk/gtkbutton.h>
#include <gtk/gtksignal.h>

#include "objectives.h"
#include "set_objectives.h"

static GtkWidget * spin_butt_num_crit ;

static void ok_pushed (GtkWidget * widget, GtkWindow * old_win) {
  
  // Destroying the window
  obj_labels.resize (gtk_spin_button_get_value_as_int ((GtkSpinButton *) spin_butt_num_crit)) ;
  obj_aims.resize (obj_labels.size ()) ;
  gtk_object_destroy (GTK_OBJECT (old_win)) ;
  // To the next step ...
  set_objectives () ;
}

void set_number_of_objectives () {
  
  // Window
  GtkWidget * window = gtk_window_new (GTK_WINDOW_TOPLEVEL) ;
  gtk_window_set_title (GTK_WINDOW (window), "New problem") ;
  gtk_window_set_position ((GtkWindow *) window, GTK_WIN_POS_CENTER_ALWAYS) ;
  gtk_container_set_border_width (GTK_CONTAINER (window), 10) ;
  gtk_widget_show (window) ;  
  
  // Horizontal box
  GtkWidget * hbox = gtk_hbox_new (FALSE, 10) ;
  gtk_container_add (GTK_CONTAINER (window), hbox) ;
  gtk_widget_show (hbox) ;

  // Label
  GtkWidget * label = gtk_label_new ("Number of objectives") ;
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 2) ;
  gtk_widget_show (label) ;

  // Spin button
  GtkObject * adj = gtk_adjustment_new (2, 1, 5, 1, 1, 0.0) ;
  spin_butt_num_crit = gtk_spin_button_new (GTK_ADJUSTMENT (adj), 0.5, 0) ;  
  gtk_box_pack_start (GTK_BOX (hbox), spin_butt_num_crit, FALSE, FALSE, 2) ;
  gtk_widget_show (spin_butt_num_crit) ;

  // Button 'Ok'
  GtkWidget * button = gtk_button_new_with_label ("  Ok  ") ;
  gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 2) ;
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (ok_pushed), window);
  gtk_widget_show (button) ;
}
