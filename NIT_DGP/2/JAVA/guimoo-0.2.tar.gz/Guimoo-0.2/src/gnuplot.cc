// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "gnuplot.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <strstream>

#include "pipe_process.h"
#include "objectives.h"
#include "po_set.h"

//static char * _args [] = {"-geometry", "550x350+420+40"} ;
                           
static Pipe_Process gnuplot_proc ("gnuplot") ;//, 2, _args) ;

static vector <POSet *> hist_psets ;

static vector <MOSolution *> hist_sol ;

void reset_gnuplot () {
  
  ostrstream out ;
  out << "set nolabel" << endl ;
  out << "set grid" << endl ;
  // To draw a complete box, around a (s)plot
  out << "set border 4095" << endl ;
  
  out << "set xtics mirror" << endl ;
  out << "set ytics mirror" << endl ;
  out << "set ztics mirror" << endl ;
  
  // Setting the x, y and z (?) axis labels ...
  for (unsigned i = 0 ; i < obj_labels.size () ; i ++)
    out << "set " << (char) ('x' + i) << "label \"" << obj_labels [i] << "\"" << endl ;
  
  // Plotting a single point ...
  /*
  if (obj_labels.size () == 2)
    out << "plot  0 0" << endl ;
  else if (obj_labels.size () == 3)
    out << "splot  0 0 0" << endl ;
  */
  gnuplot_proc.send (out.str (), out.pcount ()) ;
}

void stop_gnuplot () {
  
  ostrstream out ;
  out << "quit" << endl ;
  gnuplot_proc.send (out.str (), out.pcount ()) ;
}

void clear_visualization () {
  
  reset_gnuplot () ;
  hist_psets.clear () ;
}

void update_visualization () {
  
  ostrstream out ;
  unsigned num_obj = obj_labels.size () ;
 
  // Showing Pareto Sets ...
  
  if (! hist_psets.empty ()) {
    // 2-3D ???
    if (num_obj == 2) 
      out << "plot \'-\' title \'" << hist_psets [0] -> name () << "\'" ;
    else if (num_obj == 3) 
      out << "splot \'-\' title \'" << hist_psets [0] -> name () << "\'" ;
    
    // Coordinates
    for (unsigned i = 0 ; i < hist_psets.size () - 1 ; i ++)
      out << ", \'-\' title \'" << hist_psets [i + 1] -> name () << "\'" ;
    out << endl ;
    
    for (unsigned i = 0 ; i < hist_psets.size () ; i ++) {
      for (unsigned j = 0 ; j < hist_psets [i] -> size () ; j ++) {
	for (unsigned k = 0 ; k < num_obj ; k ++)
	  out << hist_psets [i] -> operator [] (j) [k] << " " ;
	out << endl ;
      }
      out << "e" << endl ;
    }
  }
  
  // Showing Multi Objective solutions ...
  for (unsigned i = 0 ; i < hist_sol.size () ; i ++)
    out << "set label \"" << * (hist_sol [i]) << "\" at " << * (hist_sol [i]) << " center" << endl ;
  //  cout << "avant" << endl ;
  char * marcel = out.str () ;
  gnuplot_proc.send (marcel, out.pcount ()) ;
  free (marcel) ;
  //cout << "apres" << endl ;
}

void plot (const POSet & _pset) {
  
  hist_psets.push_back (& (POSet &) _pset) ;
  update_visualization () ;  
}

void plot (const vector <POSet *> & _psets) {
  
  for (unsigned i = 0 ; i < _psets.size () ; i ++)
    hist_psets.push_back (_psets [i]) ;
  update_visualization () ;
}

void plot (const MOSolution & _sol) {
  
  hist_sol.push_back (& (MOSolution &) _sol) ;
  update_visualization () ;
}

void plot (const vector <MOSolution *> & _sols) {
  
  for (unsigned i = 0 ; i < _sols.size () ; i ++)
    hist_sol.push_back (_sols [i]) ;
  update_visualization () ;
}

static void reset_terminal () {
  
  ostrstream out ;
  
  out << "set term x11" << endl ;
  gnuplot_proc.send (out.str (), out.pcount ()) ;
}

void print () {

  ostrstream out ;
  
  out << "set term postscript" << endl ;
  out << "set output " << "\"|lpr\"" << endl ;
  gnuplot_proc.send (out.str (), out.pcount ()) ;
  update_visualization () ;  
  reset_terminal () ;
}

void export_eps (const char * _filename) {
  
  ostrstream out ;
  
  out << "set term postscript eps" << endl ;
  out << "set output " << '\"' << _filename << '\"' << endl ;
  gnuplot_proc.send (out.str (), out.pcount ()) ;
  update_visualization () ;
  reset_terminal () ;
}

void export_png (const char * _filename) {

  ostrstream out ;
  
  out << "set term png color" << endl ;
  out << "set output " << '\"' << _filename << '\"' << endl ;
  gnuplot_proc.send (out.str (), out.pcount ()) ;
  update_visualization () ;
  reset_terminal () ;
}
