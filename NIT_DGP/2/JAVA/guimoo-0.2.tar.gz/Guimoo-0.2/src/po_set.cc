// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "po_set.cc"

// (c) OPAC Team, LIFL, 2002

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <fstream.h>
#include <strstream.h>
#include <math.h>

#include "po_set.h"
#include "objectives.h"
#include "po_sets_list.h"
#include "warning_window.h"

vector <POSet> PO_sets ;

POSet :: POSet () {

} 

POSet :: POSet (string _id,
		string _file_name
		) :
  id (_id),
  file_name (_file_name) {
}

bool POSet :: operator > (const POSet & _pset) const {
  
  for (unsigned i = 0 ; i < _pset.size () ; i ++) {
    bool b = true ;
    for (unsigned j = 0 ; j < size () ; j ++)
      if (operator [] (j) > _pset [i])
	b = false ;
    if (b)
      return false ;
  }
  return true ;
}

istream & operator >> (istream & _is, POSet & _pset) {
  
  //unsigned dom = 0 ;
  
  ostrstream rem_sol ; 

  while (! _is.eof ()) {
    
    MOSolution sol ;
    _is >> sol ;
    
    //    cout << sol << endl ;

    if (_is.eof ())
      break ;


    /* Removing previously solutions that are dominated
       by the new current one ... */
    
    /*
    for (unsigned i = 0 ; i < _pset.size () ; i ++)
      if (_pset [i] < sol) {
	rem_sol << "[" << _pset [i] << "]\n" ;
	_pset [i] = _pset.back () ;
	_pset.pop_back () ;
	dom ++ ;
	i -- ;
      }

    bool ok = true ;
    for (unsigned i = 0 ; i < _pset.size () ; i ++)
      if (_pset [i] > sol)
	ok = false ;
    */  

    //if (ok)
      _pset.push_back (sol) ;
      /*
    else {
      rem_sol << "[" << sol << "]\n" ;
      dom ++ ;
    }
    */
  }

  /*
  if (dom > 0) {
    ostrstream o ;
    o <<  "The following solutions aren't Pareto Optimal\n and have so been removed\n" ; 
    rem_sol << '\0' ;
    o << rem_sol.str () ;
    o << '\0' ;
    open_warning_window (o.str ()) ;
  }
  */
    
  return _is ;
}

void POSet :: update () {
  
  ifstream f (file_name.c_str ()) ;
  
  clear () ;
  f >> * this ;
  f.close () ;
}


