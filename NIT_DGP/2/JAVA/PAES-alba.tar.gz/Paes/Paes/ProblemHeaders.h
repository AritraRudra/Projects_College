/**
 * @file        ProblemHeaders.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        23 July 2003
 * @brief       Contains the headers of the multiobjetive problem classes
 */
 
#ifndef __PROBLEM_HEADERS__
#define __PROBLEM_HEADERS__

#include <Schaffer.h>
#include <Fonseca.h>
#include <Poloni.h>
#include <Kursawe.h>
#include <Viennet3.h>
#include <Deb.h>
#include <Viennet2.h>

#include <Binh2.h>
#include <Osyczka2.h>
#include <Viennet4.h>
#include <Tanaka.h>

#include <Golinski.h>

//#include <Kita.h>
//#include <Quagliarella.h>

#include <Zdt1.h>
#include <Zdt2.h>
#include <Constr_Ex.h>

#include <OneMax.h>

#endif


