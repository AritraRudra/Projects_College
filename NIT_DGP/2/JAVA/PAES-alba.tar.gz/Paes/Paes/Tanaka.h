/**
 * @file        Tanaka.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Tanaka.cpp
 */  

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __TANAKA__
#define __TANAKA__

/**
 * @class Tanaka
 * @brief Class representing Tanaka's problem
 */
class Tanaka : public MultiobjectiveProblem {
public:
  // Constructor
  Tanaka(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
  bool constraintsAreSatisfied(Individual * individual) ;
  int numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Tanaka

#endif
