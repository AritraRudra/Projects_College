/*
 * @file    Chromosome.cpp
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Class representing a chromosome
 */

#include <Chromosome.h>

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Chromosome::Chromosome(MultiobjectiveProblem * problem,Random * random) {
  problem_ = problem ;
  length_  = problem->numberOfVariables_ ;
  gene_     = new Gene*[length_] ;
  
  if (gene_ == NULL) {
    cerr << "Chromosome::Chromosome->Error when asking for memory" << endl ;
    exit(-1) ;
  } // if
  
  int i ;
  for (i = 0; i < length_ ; i++) {
    switch (problem_->variable_[i]) {
    case BINARY:
      gene_[i] = new BinaryGene(problem->numberOfBits_, random) ;
      break ;
    case REAL:
      gene_[i] = new RealGene(problem_->lowerLimit_[i], 
                              problem_->upperLimit_[i],
                              random) ;
      break ;
    case BINARY_REAL:
      gene_[i] = new BinaryRealGene(problem->bitsPerVariable_[i],
                                    problem_->lowerLimit_[i], 
                                    problem_->upperLimit_[i],
                                    random) ;
      break ;
    case BINARY_GRAY_REAL:
      gene_[i] = new BinaryGrayRealGene(problem->bitsPerVariable_[i], 
                                        problem_->lowerLimit_[i], 
                                        problem_->upperLimit_[i],
                                        random) ;
      break ;
    default: 
      cerr << "Chromosome::Chromosome->variable type " 
           << problem_->variable_[i] << " unknown" << endl ;
      exit(-1) ;
    } // switch
  } // for
} // Chromosome::Chromosome

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Chromosome::Chromosome(Chromosome & chromosome) {
  problem_ = chromosome.problem_ ;
  length_  = chromosome.length_  ;
  gene_    = new Gene*[length_]  ;

  if (gene_ == NULL) {
    cerr << "Chromosome::Chromosome->Error when asking for memory" << endl ;
    exit(-1) ;
  } // if

  int i ;
  for (i = 0; i < length_ ; i++) {
    switch (problem_->variable_[i]) {
    case BINARY:
      gene_[i] = new BinaryGene((BinaryGene*)chromosome.gene_[i]) ;
      break ;
    case REAL:
      gene_[i] = new RealGene((RealGene*)chromosome.gene_[i]) ;
      break ;
    case BINARY_REAL:
      gene_[i] = new BinaryRealGene((BinaryRealGene*)chromosome.gene_[i]) ;
      break ;
    case BINARY_GRAY_REAL:
      gene_[i] =new BinaryGrayRealGene((BinaryGrayRealGene*)chromosome.gene_[i]);
      break ;
    default: 
      cerr << "Chromosome::Chromosome->variable type " 
           << problem_->variable_[i] << " unknown" << endl ;
      exit(-1) ;
    } // switch
  } // for

} // Chromosome::Chromosome

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Chromosome::Chromosome(Chromosome * chromosome) {
  problem_ = chromosome->problem_ ;
  length_  = chromosome->length_  ;
  gene_    = new Gene*[length_]   ;

  if (gene_ == NULL) {
    cerr << "Chromosome::Chromosome->Error when asking for memory" << endl ;
    exit(-1) ;
  } // if

  int i ;
  for (i = 0; i < length_ ; i++) {
    switch (problem_->variable_[i]) {
    case BINARY:
      gene_[i] = new BinaryGene((BinaryGene*)chromosome->gene_[i]) ;
      break ;
    case REAL:
      gene_[i] = new RealGene((RealGene*)chromosome->gene_[i]) ;
      break ;
    case BINARY_REAL:
      gene_[i] = new BinaryRealGene((BinaryRealGene*)chromosome->gene_[i]) ;
      break ;
    case BINARY_GRAY_REAL:
      gene_[i]=new BinaryGrayRealGene((BinaryGrayRealGene*)chromosome->gene_[i]);
      break ;
    default: 
      cerr << "Chromosome::Chromosome->variable type " 
           << problem_->variable_[i] << " unknown" << endl ;
      exit(-1) ;
    } // switch
  } // for
} // Chromosome::Chromosome

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
Chromosome::~Chromosome() {
  int i ;
  for (i = 0; i < length_; i++)
//    delete gene_[i] ;  
    switch (problem_->variable_[i]) {
    case BINARY:
      delete (BinaryGene *)gene_[i] ;
      break ;
    case REAL:
      delete (RealGene *)gene_[i] ;
      break ;
    case BINARY_REAL:
      delete (BinaryRealGene *)gene_[i] ;
      break ;
    case BINARY_GRAY_REAL:
      delete (BinaryGrayRealGene *)gene_[i] ;
      break ;
    default: 
      cerr << "Chromosome::~Chromosome->variable type " 
           << problem_->variable_[i] << " unknown" << endl ;
      exit(-1) ;
    } // switch
    
  delete [] gene_ ;  
} // Chromosome::~Chromosome


Chromosome & Chromosome::operator=(Chromosome & chromosome) {
  problem_ = chromosome.problem_ ;
  length_  = chromosome.length_  ;
  int i ;
  for (i = 0; i < length_ ; i++) {
    switch (problem_->variable_[i]) {
    case BINARY:
      *((BinaryGene *)gene_[i]) = *((BinaryGene*)chromosome.gene_[i]) ;
      break ;
    case REAL:
      *((RealGene *)gene_[i]) = *((RealGene*)chromosome.gene_[i]) ;
      break ;
    case BINARY_REAL:
      *((BinaryRealGene *)gene_[i]) = *((BinaryRealGene*)chromosome.gene_[i]);
      break ;
    case BINARY_GRAY_REAL:
      *((BinaryGrayRealGene *)gene_[i])=*((BinaryGrayRealGene*)chromosome.gene_[i]);
      break ;
    default: 
      cerr << "Chromosome->operator= -> variable type " 
           << problem_->variable_[i] << " unknown" << endl ;
      exit(-1) ;
    } // switch
  } // for  
} // Chromosome::operator=


ostream& operator<< (ostream& outputStream, Chromosome& chromosome) {
  int i ;
  
  outputStream << "Length: " << chromosome.length_ << endl ;
  for (i = 0; i < chromosome.length_; i++)
    if (chromosome.gene_[i]->geneType_ == BINARY)
      outputStream << *(BinaryGene*)(chromosome.gene_[i]) ;
    else if (chromosome.gene_[i]->geneType_ == REAL)
      outputStream << *(RealGene*)(chromosome.gene_[i]) ;
    else if (chromosome.gene_[i]->geneType_ == BINARY_REAL)
      outputStream << *(BinaryRealGene*)(chromosome.gene_[i]) ;
    else if (chromosome.gene_[i]->geneType_ == BINARY_GRAY_REAL)
      outputStream << *(BinaryGrayRealGene*)(chromosome.gene_[i]) ;
    else { 
      cerr << "Chromosome: operator<< -> variable type "
           << chromosome.gene_[i]->geneType_ << " unknown" << endl ;
      exit(-1) ;
    } // else
  outputStream << endl ;
} // operator<< 


