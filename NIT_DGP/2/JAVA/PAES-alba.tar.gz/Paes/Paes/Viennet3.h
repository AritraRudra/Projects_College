/**
 * @file        Viennet3.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Viennet.cpp
 */ 
 
#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __VIENNET3__
#define __VIENNET3__

/**
 * @class Viennet3
 * @brief Class representing Viennet(3)'s problem
 */
class Viennet3 : public MultiobjectiveProblem {
public:
  // Constructor
  Viennet3(VariableType variableType) ;
  
  // Methods
  void evaluate(Individual * individual) ;
} ; // class Viennet3

#endif

