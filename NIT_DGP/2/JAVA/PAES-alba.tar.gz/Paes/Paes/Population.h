/**
 * @file     Population.h
 * @author   Antonio Jesus Nebro Urbaneja
 * @version  2.0
 * @date     22 January 2004
 * @brief    Header file of Population.cpp
 */
 
#ifndef __POPULATION_H__
#define __POPULATION_H__

#include <Configuration.h>
#include <Individual.h>
#include <MultiobjectiveProblem.h>

/**
 * @class Population
 * @brief This class represents a population of individuals
 *
 * The population size can be dynamic: individuals can be deleted, and new 
 * individuals can be added. The number of elements is bounded.
 */
class Population {
protected:
  int           populationSize_     ; //!< The number of individuals
  int           maximumPopulationSize_ ; //!< The maximun number of individuals
  Individual ** population_         ; //!< The vector of individuals
  Random      * random_             ; //!< Random number management
  
  MultiobjectiveProblem * problem_  ; //!< Problem to solve

public:
  // Constructor
  Population(int populationSize       , 
             int maximumPopulationSize, 
             Random * random          ,
             MultiobjectiveProblem * problem);
             
  // Destructor
  ~Population(void);

  // Methods
  int          getPopulationSize() const               ;
  int          getMaximumPopulationSize() const        ;
  Individual * getIth(int index) const                 ;
  void         setIth(int index, Individual * ind)     ;
  void         deleteIth(int index)                    ;
  void         addIndividual(Individual * individual)  ;
  void         setFitness(int index, double * fitness) ;
  
  void         printFitness(char  * fileName)          ;
  void         printGenotype(char * fileName)          ;
} ; // Population

#endif
