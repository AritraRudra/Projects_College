/**
 * @file        Deb.h 
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Deb.cpp
 */ 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __DEB__
#define __DEB__

/**
 * @class Deb
 * @brief Class representing Deb's problem
 */
class Deb : public MultiobjectiveProblem {
public:
  // Constructor
  Deb(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
} ; // class Deb

#endif


