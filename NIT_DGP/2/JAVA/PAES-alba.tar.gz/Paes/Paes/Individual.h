/*
 * @file    Individual.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of Individual.cpp
 */

#include <Configuration.h>
#include <MultiobjectiveProblem.h>
#include <Chromosome.h>
#include <Random.h> 

#ifndef __INDIVIDUAL__
#define __INDIVIDUAL__

/**
 * @class Chromosome
 * @brief Class representing an individual
 */
class Individual {
public:
  MultiobjectiveProblem * problem_    ; //!< Problem to be solved
  Random                * random_     ; //!< Random number generator
  Chromosome            * chromosome_ ; //!< Chromosome of the individual
  double                * fitness_    ; //!< Array of fitness values
  
  int gridLocation_ ; //!< Necessary if an adaptive grid is used
  
  // Constructors
  Individual(MultiobjectiveProblem * problem, Random * random) ;
  Individual(Individual & individual) ;
  Individual(Individual * individual) ;
  
  // Destructor
  ~Individual() ;
  
  // Methods
  void    setFitness(double * fitness) ;
  double *getFitness() const ;  
  
  int  dominanceTest(Individual * individual) ;
  int  constraintComparison(Individual * individual) ;
  bool identicalFitness(Individual * individual) ;
    
  // Binary mutation operators
  int bitFlipMutation(double mutationProbability) ;
  
  // Real mutation operators
  int randomMutation(double mutationProbability) ;
  int polynomialMutation(double mutationProbability,
                         double distributionIndex) ;
  int uniformMutation(double mutationProbability,
                      double perturbation) ;  
  // Operators
  Individual & operator=(Individual &individual) ;
  friend ostream& operator<< (ostream& outputStream, Individual& individual) ; 
  
  void printFitness() ;

} ; // Individual


#endif
