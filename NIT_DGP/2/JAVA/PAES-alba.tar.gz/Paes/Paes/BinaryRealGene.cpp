/*
 * @file    BinaryRealGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Class representing a binary-coded real gene
 */

#include <BinaryRealGene.h>

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryRealGene::BinaryRealGene(int      numberOfBits,
                               double   lowerBound  , 
                               double   upperBound,
                               Random * random) : 
                    Gene(BINARY_REAL, random) {
  int i ;                    
                    
  upperBound_   = upperBound   ;
  lowerBound_   = lowerBound   ;                    
  numberOfBits_ = numberOfBits ;
  
  binaryAllele_ = new char[numberOfBits] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryRealGene::BinaryRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits; i++)
    if (random_->rnd(0,1) == 1)
      binaryAllele_[i] = '1' ;
    else
      binaryAllele_[i] = '0' ;

  realAllele_ = decodeToReal() ;      
} // BinaryRealGene::BinaryRealGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryRealGene::BinaryRealGene(BinaryRealGene & gene) : 
                    Gene(gene) {
  int i ;                    

  upperBound_   = gene.upperBound_        ;
  lowerBound_   = gene.lowerBound_        ;                                                      
  numberOfBits_ = gene.numberOfBits_      ;
  binaryAllele_ = new char[numberOfBits_] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryRealGene::BinaryRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene.binaryAllele_[i] ;
    
  realAllele_ = gene.realAllele_ ;
} // BinaryRealGene::BinaryRealGene


/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */

BinaryRealGene::BinaryRealGene(BinaryRealGene * gene) :  Gene(gene) {
  int i ;                    
                    
  upperBound_   = gene->upperBound_       ;
  lowerBound_   = gene->lowerBound_       ;                                                      
  numberOfBits_ = gene->numberOfBits_     ;
  binaryAllele_ = new char[numberOfBits_] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryRealGene::BinaryRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene->binaryAllele_[i] ;
    
  realAllele_ = gene->realAllele_ ;
} // BinaryRealGene::BinaryRealGene

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
BinaryRealGene::~BinaryRealGene() {
  delete [] binaryAllele_ ;
} // BinaryRealGene::~BinaryRealGene

BinaryRealGene & BinaryRealGene::operator=(const BinaryRealGene&  gene) {
  int i ;                    

  upperBound_   = gene.upperBound_   ;
  lowerBound_   = gene.lowerBound_   ;                          
  numberOfBits_ = gene.numberOfBits_ ;
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene.binaryAllele_[i] ;
  realAllele_ = gene.realAllele_ ;        
  
  return *this ;                                             
} // BinaryRealGene::operator=                                                    

int BinaryRealGene::bitFlipMutation(double mutationProbability) {
  int mutations ;
  int i         ;
  mutations = 0 ;

  for (i = 0; i < numberOfBits_ ; i++)
    if (random_->flip(mutationProbability) == 1) {
      mutations ++ ;
      if (binaryAllele_[i] == '1')
        binaryAllele_[i] = '0' ;
      else
        binaryAllele_[i] = '1' ;
    } //if
    
  realAllele_ = decodeToReal() ;      
  return mutations ;
} // BinaryRealGene::bitFlipMutation

double BinaryRealGene::getRealAllele() {
  return realAllele_ ;
} // BinaryRealGene::getRealAllele

void BinaryRealGene::writeGenotype(ofstream& outputFile) {
  outputFile << realAllele_ ;
} // BinaryRealGene::writeGenotype


ostream& operator<< (ostream& outputStream, BinaryRealGene& gene) {
  int i ;

  outputStream << (Gene&)gene << " Real allele: " << gene.realAllele_ ;
  
  outputStream << " Bits: " << gene.numberOfBits_ << " Binary allele: " ;
  for (i = 0 ; i < gene.numberOfBits_; i++)
    if (gene.binaryAllele_[i] == '1')
      outputStream << "1" ;
    else
      outputStream << "0" ;
  outputStream << endl ;
} // operator<< 

double BinaryRealGene::decodeToReal() {
  int    i         ;
  double realValue ;
  
  realValue = 0.0 ;
  for (i = 0; i < numberOfBits_ ;i++) {
    if (binaryAllele_[i] == '1')
      realValue += pow((double)2.0, i) ;
  } // for
    
  return (lowerBound_ + realValue*(upperBound_ - lowerBound_) /
                                   (pow(2.0, numberOfBits_) - 1)) ;
} // BinaryRealGene::decodeGene


