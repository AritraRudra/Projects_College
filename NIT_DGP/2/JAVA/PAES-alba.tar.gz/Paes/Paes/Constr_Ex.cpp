/**
 * @file        Constr_Ex.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Specificacion of the problem Constr_Ex.  The problem is defined 
 *              in  Deb (2001), pag 290
 */ 
 
#include <Constr_Ex.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Constr_Ex::Constr_Ex(VariableType variableType) {

  problemName_ = "Constr_Ex" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 2 ;

  const double upperLimit[] = {1, 5} ;
  const double lowerLimit[] = {0.1, 0} ;
  const int partitions[]    = {100, 100, 100} ;
  const int precision[]     = {5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Constr_Ex::Constr_Ex


void Constr_Ex::evaluate(Individual * individual) {
  double x[2] ;
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  // First function
  individual->fitness_[0] = x[0] ;

  // Second function
  individual->fitness_[1] = (1.0 + x[1]) / x[0] ;

} // Constr_Ex::evaluate

bool Constr_Ex::constraintsAreSafisfied(Individual * individual) {
  double x[2]   ;
  bool   result ; 
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
    
  if ( ((x[1]  + 9*x[0]) >= 6) &&
       ((-x[1] + 9*x[0]) >= 1) )
        return true ;
  else
    return false ;
} // Constr_Ex::constraintsAreSafisfied

int Constr_Ex::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter ;
  double x[2]    ;
 
  counter = 0 ;
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  
  if ((x[1]  + 9*x[0]) < 6)
    counter ++ ;
  if ((-x[1] + 9*x[0]) < 1) 
    counter ++ ;

  return counter ;  
} // Constr_Ex::numberOfNonSatisfiedConstraints
