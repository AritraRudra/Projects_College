/**
 * @file    AdaptiveGrid.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    12 December 2003
 * @brief   Header file of AdaptiveGrid.cpp
 */
 

#ifndef __ADAPTIVE_GRID__
#define __ADAPTIVE_GRID__

#include <Configuration.h>
#include <Population.h>
#include <Individual.h>

/**
 * @class AdaptiveGrid
 * @brief 
 */
class AdaptiveGrid {

public:
  int    * hypercube_       ; //!< Hypercube division for keeping diversity
  double * divisionSize_    ; //!< Division sizes of the adaptive grid
  double * gridLimits_      ; //!< Limits of the adaptive grid
  long     currentGridSize_ ; //!< Current size of the adaptive grid
  int      mostCrowdedHypercube_ ;

  int numberOfFunctions_  ; //!< 
  int depth_              ; //!< 
    
  double * upperBestFitness_ ;
  double * lowerBestFitness_ ;
  
  // Constructor
  AdaptiveGrid() ;
  AdaptiveGrid(int depth, int numberOfFunctions) ;
  
  // Destructor
  ~AdaptiveGrid();
  
  // Methods
  void updateGridLocations(Population * population, Individual * individual) ;
  int  findLocation(Individual * individual) ;
  
private:
  // These variables are used in findLocation(). They are defined here for 
  // efficiency purposes
  int    * increment_       ;
  double * tmpDivisionSize_ ;
}; // class AdaptiveGrid

#endif
