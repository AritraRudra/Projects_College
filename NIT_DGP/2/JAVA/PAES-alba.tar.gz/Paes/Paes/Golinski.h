/**
 * @file        Golinski.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Golinski.cpp
 */
 
#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __GOLINSKI__
#define __GOLINSKI__

/**
 * @class Golinski
 * @brief Class representing Golinski's problem
 */
class Golinski : public MultiobjectiveProblem {
public:
  // Constructor
  Golinski(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
  
  bool constraintsAreSatisfied(Individual * individual) ;
  int  numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Golinski

#endif

