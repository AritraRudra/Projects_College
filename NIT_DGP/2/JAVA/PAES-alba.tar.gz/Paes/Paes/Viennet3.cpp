/**
 * @file        Viennet3.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Viennet3's problem. This problem is renamed
 *              MOP4 in Coello et al.
 */ 
 
#include <Viennet3.h>

// STEP 3. Define the constructor of the class

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Viennet3::Viennet3(VariableType variableType) {

  problemName_ = "Viennet3-MOP5" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 3 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {3.0, 3.0} ;
  const double lowerLimit[] = {-3.0, -3.0} ;
  const int    partitions[] = {100, 100} ;
  const int precision[]     = {5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Viennet3::Viennet3

void Viennet3::evaluate(Individual * individual) {
  double x[2] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  // First function
  individual->fitness_[0] = 0.5 * (x[0]*x[0] + x[1]*x[1]) + 
                                   sin(x[0]*x[0] + x[1]*x[1]) ;

  // Second function
  double value1 = 3 * x[0] - 2 * x[1] + 4 ;
  double value2 = x[0] - x[1] + 1 ;
  individual->fitness_[1] = (value1 * value1)/8 + (value2 * value2)/27 + 15 ;

  // Third function
  individual->fitness_[2] = 1 / (x[0]*x[0] + x[1]*x[1]+1) - 
                             1.1 * exp(-(x[0]*x[0])-(x[1]*x[1])) ;
} // Viennet3::evaluate

