/*
 * @file    Individual.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Class representing an individual
 */
 
#include <Individual.h>

/**
 * @brief Constructor
 * @param 
 *
 * Constructor of the class
 */
Individual::Individual(MultiobjectiveProblem * problem, Random * random) {
  int i ;
  
  problem_    = problem ; 
  random_     = random  ;
  chromosome_ = new Chromosome(problem_, random_) ;
  fitness_    = new double[problem_->numberOfFunctions_] ;
  
  if ((fitness_ == NULL) || (chromosome_ == NULL)) {
    cerr << "Individual::Individual-> error when asking for memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i <problem_->numberOfFunctions_; i++)
    fitness_[i] = 0.0 ;

#ifdef __MPI__
this->calculateSize() ;
#endif        
} // Individual::Individual

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Individual::Individual(Individual & individual) {
  int i ;
  
  problem_    = individual.problem_ ;
  chromosome_ = new Chromosome(individual.chromosome_) ;
  fitness_    = new double[individual.problem_->numberOfFunctions_] ;
  
  if ((fitness_ == NULL) || (chromosome_ == NULL)) {
    cerr << "Individual::Individual-> error when asking for memory" << endl ;
    exit(-1) ;
  } // if  

  for (i = 0; i <problem_->numberOfFunctions_; i++)
    fitness_[i] = individual.fitness_[i] ;

#ifdef __MPI__
this->calculateSize() ;
#endif        
} // Individual::Individual

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Individual::Individual(Individual * individual) {
  int i ;
  
  problem_    = individual->problem_ ;
  chromosome_ = new Chromosome(individual->chromosome_) ;
  fitness_    = new double[individual->problem_->numberOfFunctions_] ;
  
  if ((fitness_ == NULL) || (chromosome_ == NULL)) {
    cerr << "Individual::Individual-> error when asking for memory" << endl ;
    exit(-1) ;
  } // if  

  for (i = 0; i <problem_->numberOfFunctions_; i++)
    fitness_[i] = individual->fitness_[i] ;

#ifdef __MPI__
this->calculateSize() ;
#endif        
} // Individual::Individual

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
Individual::~Individual() {
  delete chromosome_ ;  
  delete [] fitness_ ;
#ifdef __MPI__
  delete [] messageBuffer_ ;
#endif
} // Individual::~Individual

/**
 * @brief Sets the fitness of the individual
 * @param fitness An array of doubles with the fitness of the individual
 */
void Individual::setFitness(double * fitness) {
  int i ;
  for (i = 0; i < problem_->numberOfFunctions_; i++) {
    fitness_[i] = fitness[i] ;
//cout << fitness_[i] << " ";
  } //for
} // Individual::setFitness

/**
 * @brief Gets the fitness of the individual
 * @return An array of doubles with the fitness of the individual
 */
double * Individual::getFitness() const {
  return fitness_;
} // getFitness

int Individual::bitFlipMutation(double mutationProbability) {
  int i         ;
  int mutations ; 
  
  mutations = 0 ;
  for (i = 0; i < chromosome_->length_; i++) {
    mutations += chromosome_->gene_[i]->bitFlipMutation(mutationProbability) ;
  } // for
  
  return mutations ;
} // Individual::bitFlipMutationn

int Individual::uniformMutation(double mutationProbability, 
                                double perturbation) {
  int i         ;
  int mutations ; 
  
  mutations = 0 ;
  for (i = 0; i < chromosome_->length_; i++) {
    mutations += chromosome_->gene_[i]->uniformMutation(mutationProbability, 
                                                       perturbation) ;
  } // for
  
  return mutations ;
} // Individual::uniformMutation

int Individual::randomMutation(double mutationProbability) {
  int i         ;
  int mutations ; 
  
  mutations = 0 ;
  for (i = 0; i < chromosome_->length_; i++) {
    mutations += chromosome_->gene_[i]->randomMutation(mutationProbability) ;
  } // for
  
  return mutations ;
} // Individual::randomMutation


/**
 * @brief Applies a polynomial mutation with certain probability
 * @param individual The individual to mutate
 * @param mutationProbability The probability of a bit mutation
 * @return The number of mutations
 *
 * The polynomial mutation is defined in [Deb 2002], p 124.
 */
int Individual::polynomialMutation(double mutationProbability, 
                                   double distributionIndex) {
  int i         ;
  int mutations ; 
   
  mutations = 0 ;
  for (i = 0; i < chromosome_->length_; i++) {
    mutations += chromosome_->gene_[i]->polynomialMutation(mutationProbability,
                                                          distributionIndex) ;
  } // for
  
  return mutations ;                                   
} // Individual::polynomialMutation

bool Individual::identicalFitness(Individual * individual) {
  int i ;

  for (i = 0; i < problem_->numberOfFunctions_; i++)
    if (fitness_[i] != individual->fitness_[i])
       return false ;

  return true ;  
} // Individual::identicalFitness


/**
 * @brief Constraint comparison test between two individuals
 * @param individual The individual against the test if performed
 * @return 1 if this individual violates less constraints than the 
 *         the individual passed as parameter, -1 if this individual violates 
 *         less constraints than the current individual, and 0 otherwise
 *
 * It is assumed that the individual has been previously decoded to a real
 * representation
 */

int Individual::constraintComparison(Individual * individual) {
  int constraintsFirstIndividual  ;
  int constraintsSecondIndividual ;        
  
  int result ;
  
  result = 0 ;
  constraintsFirstIndividual  = problem_->numberOfNonSatisfiedConstraints(
                                this) ;
  constraintsSecondIndividual = problem_->numberOfNonSatisfiedConstraints(
                                individual) ;
  if (constraintsFirstIndividual < constraintsSecondIndividual)
    result = 1 ;   // Current dominates 
  else if (constraintsFirstIndividual > constraintsSecondIndividual)
    result = -1 ;  // Current is dominated
  return result ;                                     
} // Individual::constraintComparison                                  

/**
 * @brief. Dominance test
 * @param individual The individual against the test is performed
 * @return 1 if the individual passed as argument is dominated, -1 if this
 *         individual dominates the current individual, and 0 if the two
 *         individuals are non-dominated
 */
int Individual::dominanceTest(Individual * individual) {
  int i       ;                        
  int best    ;
  int last    ;                        
  int current ; 
  int result  ; 
  
  bool finished ;

  finished = false ;
 
  if (problem_->numberOfConstraints_ > 0) {
    result = this->constraintComparison(individual) ;
    if (result != 0)
      finished = true ;
  } // if
 
  last = 0 ;
  i    = 0 ; 
   
  while (!finished) {
    if (this->fitness_[i] < individual->fitness_[i])
      current = 1 ;
    else if (this->fitness_[i] > individual->fitness_[i])
      current = -1 ;
    else
      current = 0 ;
    
    if ((current != 0) && (current == -last)) {
      finished = true ;
      result   = 0    ;
    } // if
    //if ((current == 0) || (current == last)){
    else {
      last = current ;
      
      i ++ ;
      if (i == this->problem_->numberOfFunctions_) {
        finished = true ;    
        result   = last ;
      } // if
    } // else
  } // while 
  
  return result ;  
} // Individual::dominanceTest


Individual & Individual::operator=(Individual &individual) {
  int i ;
  
  problem_     = individual.problem_ ;
  *chromosome_ = *(individual.chromosome_) ;
  
  for (i = 0; i <problem_->numberOfFunctions_; i++)
    fitness_[i] = individual.fitness_[i] ;  
} // Individual::operator=


ostream& operator<< (ostream& outputStream, Individual& individual) {
  int i ;
  outputStream << *(individual.chromosome_) ;
  outputStream << "Fitness: " ;
  for (i = 0; i < individual.problem_->numberOfFunctions_; i++)
    outputStream << individual.fitness_[i] << " " ;
  outputStream << endl ;
} // operator<< 

void Individual::printFitness() {
  int i ;
  cout << "Fitness: " ;
  for (i = 0; i < problem_->numberOfFunctions_; i++)
    cout << fitness_[i] << " " ;
  cout << endl ;
} // Individual::printFitness

#ifdef __MPI__
void Individual::send(int address) {
  MPI_Request request ;
  MPI_Isend(fitness_, 
           problem_->numberOfFunctions_,
           MPI_DOUBLE,
           address,
           1,
           MPI_COMM_WORLD,
           &request) ;
  chromosome_->send(address) ;             
} // send
  
void Individual::receive(int address) {
  MPI_Status status ;
   
  MPI_Recv(fitness_, 
           problem_->numberOfFunctions_,
           MPI_DOUBLE,
           address,
           1,
           MPI_COMM_WORLD,
           &status) ;    
  chromosome_->receive(address) ;
}
  
void Individual::calculateSize() {
  int size ;
  
  MPI_Pack_size(problem_->numberOfFunctions_, MPI_DOUBLE, MPI_COMM_WORLD, &size) ;
  dataSize_ = size ;
    
  chromosome_->calculateSize() ;
  dataSize_ += chromosome_->getSize() ;
  
  messageBuffer_ = new char[dataSize_] ;
  bufferOffset_  = 0 ;
}
  
int Individual::getSize() {
  return dataSize_ ;
} // 

void Individual::send2(int address) {
  MPI_Request request ;
  bufferOffset_ = 0 ;
  chromosome_->packData(messageBuffer_, &bufferOffset_, dataSize_) ;
  MPI_Pack(fitness_, 
           problem_->numberOfFunctions_, 
           MPI_DOUBLE, 
           messageBuffer_, 
           dataSize_, 
           &bufferOffset_, 
           MPI_COMM_WORLD) ;

  MPI_Isend(messageBuffer_, 
           bufferOffset_,
           MPI_PACKED,
           address,
           1,
           MPI_COMM_WORLD,
           &request) ;         
} // send
  
void Individual::receive2(int address) {
  MPI_Status status ;
   
  MPI_Recv(messageBuffer_, 
           dataSize_,
           MPI_PACKED,
           address,
           1,
           MPI_COMM_WORLD,
           &status) ;
               
  bufferOffset_ = 0 ;
  chromosome_->unpackData(messageBuffer_, &bufferOffset_, dataSize_) ;
  MPI_Unpack(messageBuffer_, 
             dataSize_, 
             &bufferOffset_, 
             fitness_, 
             problem_->numberOfFunctions_, 
             MPI_DOUBLE, 
             MPI_COMM_WORLD) ;
}
#endif    
