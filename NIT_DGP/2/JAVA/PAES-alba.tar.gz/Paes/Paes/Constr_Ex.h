/**
 * @file        Constr_Ex.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        28 January 2004
 * @brief       Header file of Constr_Ex.cpp
 */ 
 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __CONSTR_EX__
#define __CONSTR_EX__

/**
 * @class Constr_Ex
 * @brief Class representing the problem ZDT1
 */
class Constr_Ex : public MultiobjectiveProblem {
public:
  // Constructor
  Constr_Ex(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
  bool constraintsAreSafisfied(Individual * individual) ;
  int  numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Constr_Ex

#endif
