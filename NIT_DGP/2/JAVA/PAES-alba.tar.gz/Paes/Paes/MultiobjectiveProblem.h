#include <Configuration.h>
#include <Gene.h>

#ifndef __MULTIOBJECTIVE_PROBLEM__
#define __MULTIOBJECTIVE_PROBLEM__

class Individual ;

class MultiobjectiveProblem {
public:
  int numberOfVariables_   ;
  int numberOfFunctions_   ;
  int numberOfConstraints_ ;
  
  string problemName_ ;
  
  VariableType * variable_ ; //!< Types of the decision variables
  
  double * upperLimit_  ; //!< To be used with continuous variables
  double * lowerLimit_  ; //!< To be used with continuous variables
  int    * partitions_  ; //!< To be used by enumerative search algorithms
  
  int    * precision_       ; //!< To be used by binary variables
  int      numberOfBits_    ; //!< To be used by binary variables
  int    * bitsPerVariable_ ; //!< To be used by binary variables
  
  MultiobjectiveProblem() ;
    
  virtual void evaluate(Individual * individual) = 0 ;
  virtual bool constraintsAreSatisfied(Individual * individual) ;
  virtual int  numberOfNonSatisfiedConstraints(Individual * individual) ;
  
  // Methods for binary variables
  void adjustPrecision(int variable) ;

  // Methods for real variables
  void initializeRealVariableType(VariableType variableType) ;
  
  void print() ;
} ; // MultiobjectiveProblem



#endif
