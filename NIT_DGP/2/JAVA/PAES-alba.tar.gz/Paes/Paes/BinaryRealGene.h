/*
 * @file    BinaryRealGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of BinaryRealGene.cpp
 */

#include <Configuration.h>
#include <Gene.h>

#ifndef __BINARY_REAL_GENE__
#define __BINARY_REAL_GENE__

/**
 * @class Gene
 * @brief Class representing a binary-coded real gene
 */
class BinaryRealGene : public Gene {
private:
  double decodeToReal() ;
public:
  char * binaryAllele_ ; //!< Binary string
  int    numberOfBits_ ; //!< Number of bits of the bit string
  double realAllele_   ; //!< Real value of the allele
  double lowerBound_   ; //!< Lower bound of the allele
  double upperBound_   ; //!< Upper bound of the allele
  
  // Constructors
  BinaryRealGene(int      numberOfBits, 
                 double   lowerBound, 
                 double   upperBound,
                 Random * random) ;
  BinaryRealGene(BinaryRealGene & binaryRealGene) ;
  BinaryRealGene(BinaryRealGene * binaryRealGene) ;

  // Destructor
  virtual ~BinaryRealGene() ;
  
  // Methods
  int    bitFlipMutation(double mutationProbability) ;
  double getRealAllele() ;
  void   writeGenotype(ofstream &outputFile) ;

  // Operators
  BinaryRealGene & operator=(const BinaryRealGene& gene) ;
  friend ostream& operator<< (ostream& outputStream, BinaryRealGene& gene) ;
  
} ; // BinaryRealGene

#endif

