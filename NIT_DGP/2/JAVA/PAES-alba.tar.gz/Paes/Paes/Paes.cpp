/**
 * @file        Paes.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        19 Januery 2004
 * @brief       This class implements a PAES algorithm
 */ 

#include <Paes.h>

/**
 * @brief Constructor
 */

Paes::Paes(MultiobjectiveProblem * problemToSolve,
           MutationOperator        mutationOperator)  {
  problem_          = problemToSolve   ;
  mutationOperator_ = mutationOperator ;

  // default values
  depth_                         = 4        ; 
  maximumArchiveLength_          = 150       ;
  numberOfIterations_            = 100000    ;
  mutationProbability_           = 0.8      ; 
  seed_                          = 1        ; 
  printFrequency_                = 100000    ;
  distributionIndexForMutation_  = 20.0     ; // for polynomial mutation
  perturbationForMutation_       = 10.0     ; // for uniform mutation
    
  readConfigurationData() ;
   
  numberOfFitnessEvaluations_ = 0   ;  

  random_.initrandom(seed_) ;
  random_.Rseed = random_.randreal2() ;
  random_.randomize() ;

  archiveOfSolutions_ = new Population(0, // 0 elements 
                                       maximumArchiveLength_ ,
                                       &random_,
                                       problem_) ;
                                        
  adaptiveGrid_ = new AdaptiveGrid(depth_, problem_->numberOfFunctions_) ;
  if (!adaptiveGrid_) {
    cerr << "Paes::Paes-> Not enough memory for the adaptiveGrid object" 
         << endl ;
    exit(-1) ;
  } // if
}  // Paes::Paes


/**
 * @brief 
 * @return 
 */
void Paes::start()  {
  int  result         ;
  int  mutations      ;
  bool mutantArchived ;
  long iterations     ;

  startTime_ = time(NULL) ;
  
  currentSolution_ = new Individual(problem_, &random_) ;
  problem_->evaluate(currentSolution_) ;
  numberOfFitnessEvaluations_ ++ ;
  addToArchive(new Individual(currentSolution_)) ;
  iterations = 0 ;
  while (iterations < numberOfIterations_) {
    iterations++ ;
    if ((iterations % printFrequency_) == 0) {
      cout << "ITERATION " << iterations << endl ;
      cout << "Archive: " << archiveOfSolutions_->getPopulationSize() << endl ; 
      //cout << "Current: " << *currentSolution_ << endl ;
      currentSolution_->printFitness() ;
      cout << endl ;
    } // if
    // STEP 1. Copy the current solution
    mutantSolution_ = new Individual(currentSolution_) ;
    if (mutantSolution_ == NULL) {
      cerr << "Paes::start->Error allocating memory for mutantSolution_" 
           << endl ;
      exit(-2) ;
    } // if
    // STEP 2. Apply mutation
    switch(mutationOperator_){
    case BIT_FLIP:
      mutations = mutantSolution_->bitFlipMutation(mutationProbability_) ;
      break ;
    case RANDOM:
      mutations = mutantSolution_->randomMutation(mutationProbability_) ;
      break ;
    case POLYNOMIAL:  
      mutations = mutantSolution_->polynomialMutation(mutationProbability_,
                                                distributionIndexForMutation_) ;
      break ;
    case UNIFORM:
      mutations = mutantSolution_->uniformMutation(mutationProbability_,
                                                   perturbationForMutation_) ;
      break ;
    default:
      cerr << "Paes::start-> mutant operator " << mutationOperator_    
           << " undefined" << endl ;
      exit(-1) ;          
    } // switch

    if (mutations > 0) {
      problem_->evaluate(mutantSolution_) ;
      numberOfFitnessEvaluations_ ++ ;
        result = currentSolution_->dominanceTest(mutantSolution_) ;
      if (result == -1) {
        *currentSolution_ = *mutantSolution_ ;
        adaptiveGrid_->updateGridLocations(archiveOfSolutions_ ,
                                           mutantSolution_) ;
        archiveSolution(mutantSolution_) ;
      } // if 
      else if (result == 0 ) {
        //cout << ">> Mutant and Current are non-dominated" << endl ;
        result = compareToArchive(mutantSolution_) ;
        if (result != -1) { // Mutant is not dominated by the archive
          adaptiveGrid_->updateGridLocations(archiveOfSolutions_ ,
                                             mutantSolution_) ;         
          mutantArchived = archiveSolution(mutantSolution_) ;
          if (mutantArchived && (result == 0)) {
            int location1 = adaptiveGrid_->findLocation(currentSolution_) ;
            int location2 = adaptiveGrid_->findLocation(mutantSolution_) ;
            if (adaptiveGrid_->hypercube_[location2] <= 
                adaptiveGrid_->hypercube_[location1])
              *currentSolution_ = *mutantSolution_ ;
          } // if
        } // if
        else
          delete mutantSolution_ ;
      } // else if 
      else { // (result == 1)
        delete mutantSolution_ ; 
        //cout << ">> Current dominates mutant" << endl ;
      } // else
    } // if
    else
      delete mutantSolution_ ;
  } // for  
  
  endTime_ = time(NULL) ;
}  // Paes::start


/**
 * @brief 
 */
void Paes::addToArchive(Individual *solution) {
  archiveOfSolutions_->addIndividual(solution) ;
} // Paes::addToArchive

/**
 * @brief Checks if the solution is dominated by any member of the archive
 * @return 0 if the solution is non-dominated, -1 if it is dominated, 1 if it
 *           dominates all the members of the archive
 */
int Paes::compareToArchive(Individual *solution) {
  int counter ;
  int result  ;
  
  counter = 0 ;
  result  = 0 ;
  
  while ((counter < archiveOfSolutions_->getPopulationSize()) && 
         (result != -1)) {
      result = solution->dominanceTest(archiveOfSolutions_->getIth(counter)) ;
    
    counter ++ ;
  } // while
  
  return result ;
} // Paes::compareToArchive

/**
 * @brief 
 * @return 
 */
bool Paes::archiveSolution(Individual *solution) {
  int result            ;
  bool finish           ;
  int  counter          ;
  bool storeNewSolution ;
  
  finish           = false ;
  storeNewSolution = true  ;
  counter          = 0     ;
  // CASE 1. The archive is empty
  //         Action: add solution to the archive
  if (archiveOfSolutions_->getPopulationSize() == 0) {
    addToArchive(solution) ;
    finish = true ;
  } // if
  
  while ((counter < archiveOfSolutions_->getPopulationSize()) && !finish) {
    if (solution->identicalFitness(archiveOfSolutions_->getIth(counter))) {
      // There is a solution with the same fitness vector
      finish           = true  ;
      storeNewSolution = false ;
    } // if
    else {
      result = solution->dominanceTest(archiveOfSolutions_->getIth(counter)) ;
      if (result == -1) {
        //cout << " The new solution is dominated " << endl ;
        //auxiliarArchive_.push(archiveOfSolutions_.pop()) ;
        finish           = true  ; 
        storeNewSolution = false ;
        // The solution is not added to the archive
      } // if
      else if (result == 1) {
        //cout << " The new solution dominates the current solution in the archive" << endl ;
        //delete archiveOfSolutions_.pop() ;
        archiveOfSolutions_->deleteIth(counter) ;
      } // else if
      else  {
        //cout << " The two solutions are non-dominated " << endl ;
        ; // auxiliarArchive_.push(archiveOfSolutions_.pop()) ;
      } // else
    } // else
    counter ++ ;
  } // while

  if (storeNewSolution) {
    // If the archive is not full, add the solution
    if (archiveOfSolutions_->getPopulationSize() < maximumArchiveLength_) 
      archiveOfSolutions_->addIndividual(solution) ;
    else {
      // The archive is full
      int i             ;
      int location      ;
      // If the solution is not in the most crowded region, add it
      location = solution->gridLocation_ ;
      if (location == adaptiveGrid_->mostCrowdedHypercube_) {
        // archiveOfSolutions_->addIndividual(solution) ;
        delete solution ;
        storeNewSolution = false ;
      } // if
      else { // Find and replace an individual of the most crowded region 
        bool finish ;
        finish = false ;
        i      = 0     ;
        while (!finish) {
          location = (archiveOfSolutions_->getIth(i))->gridLocation_ ;
          if (location == adaptiveGrid_->mostCrowdedHypercube_) {    
            archiveOfSolutions_->deleteIth(i) ;      
            archiveOfSolutions_->addIndividual(solution) ;
            finish = true ;
          } // if
          i ++ ;
          if (i == archiveOfSolutions_->getPopulationSize())
            finish = true ;
        } // while
      } // else
    } // else
  } // if
  else {
    //cout << "     - mutant discarded" << endl ;
    delete solution ;
  } // else
  
  return storeNewSolution ;
} // Paes::archiveSolution

/**
 * @brief Prints the values of the variables and the objective functions 
 *
 * Prints the values of the variables and the objective functions to the files 
 *        passed as parameters
 * @param variableFileName The name of the file to store the decision variables
 * @param functionFileName The name of the file to store the values of the 
 *                         objective functions
 */
void Paes::printToFiles(char * genotypeFileName,
                        char * fitnessFileName) {
  archiveOfSolutions_->printGenotype(genotypeFileName) ;
  archiveOfSolutions_->printFitness(fitnessFileName) ;
} // Paes::printToFiles

/**
 * @brief Reads parameters from a file named "paes.cfg"
 */
void Paes::readConfigurationData() {
  ifstream configurationFile ;
  
  configurationFile.open("paes.cfg", ios::in) ;
  if (configurationFile.fail()) {
    cerr << "Paes::readConfigurationFile-> the file 'paes.cfg' does not exist" ;
    cerr << endl ;
    exit(-1) ;
  } // if
  else
    cout << "Processing configuration file (paes.cfg) ..." << endl ;

  string key ;
  string tmp ;
  string value ;
  
  configurationFile >> key ;

  while (!configurationFile.eof()) {
    configurationFile >> tmp ; // " the symbol = "

    if (key.compare("DEPTH") == 0) {
      configurationFile >> depth_ ;
      cout << key << "\t\t\t" << depth_ << endl ;
    }
    else if (key.compare("MAXIMUM_ARCHIVE_LENGTH") == 0) {
      configurationFile >> maximumArchiveLength_ ;
      cout << key << "\t" << maximumArchiveLength_ << endl ;
    } 
    else if (key.compare("NUMBER_OF_ITERATIONS") == 0) {
      configurationFile >> numberOfIterations_ ;
      cout << key << "\t" << numberOfIterations_ << endl ;
    }    
    else if (key.compare("SEED") == 0) {
      configurationFile >> seed_ ;
      cout << key << "\t\t\t" << seed_ << endl ;
    } 
    else if (key.compare("MUTATION_PROBABILITY") == 0) {
      configurationFile >> mutationProbability_ ;
      cout << key << "\t" << mutationProbability_ << endl ;
    } 
    else if (key.compare("PRINT_FREQUENCY") == 0) {
      configurationFile >> printFrequency_ ;
      cout << key << "\t" << printFrequency_ << endl ;
    } 
    configurationFile >> key ;
  } // while

  cout << endl ;
  
  configurationFile.close() ;
} // Paes::readConfigurationData

/**
 * @brief Print execution statistics
 */
void Paes::printStatistics() {
  cout << "   RESULTS" << endl ;
  cout << "-------------" << endl ;
  cout << "Time:        " << endTime_ - startTime_ << " seconds" << endl ;
  cout << "Evaluations: " << numberOfFitnessEvaluations_ << endl ;
} // Paes::printStatistics

