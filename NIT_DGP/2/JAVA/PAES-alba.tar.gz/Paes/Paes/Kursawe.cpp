/**
 * @file        Kursawe.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        26 January 2004
 * @brief       Especificacion of Kursawe's problem. This problem is renamed
 *              MOP4 in Coello et al.
 */

#include <Kursawe.h>

/**
 * @brief Constructor
 */
Kursawe::Kursawe(VariableType variableType) {

  problemName_ = "KURSAWE" ;

  numberOfVariables_   = 3 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;
  
  const double upperLimit[] = {5.0, 5.0, 5.0} ;
  const double lowerLimit[] = {-5.0, -5.0, -5.0} ;
  const int partitions[]    = {100, 100, 100} ;
  const int precision[]     = {5, 5, 5} ;
  
  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]     ;
  
// int bitsPerBinaryVariable[] = {10, 10, 10} ;

  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;
//  memcpy(bitsPerVariable_, bitsPerVariable, numberOfVariables_ * sizeof(int)) ;
    
  variable_ = new VariableType[numberOfVariables_] ;
  int i ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Constructor

  
void Kursawe::evaluate(Individual *individual) {
  double result ;
  double xi     ;
  double xj     ;
  int i ;

  // First function
  result = 0.0 ;
  for (i = 0; i < numberOfVariables_ - 1 ; i++) {
    xi = (individual->chromosome_->gene_[i])->getRealAllele()   ;
    xj = (individual->chromosome_->gene_[i+1])->getRealAllele() ;
    result += -10.0 * exp((-0.2)*sqrt(pow(xi,2)+pow(xj,2)))     ;
  } //for
  individual->fitness_[0] = result ;    
    
  // Second function
  const double a = 0.8 ; //!< Constant a  
  const double b = 3   ; //!< Constant b
  result = 0.0 ;  
  for (i = 0; i < numberOfVariables_ ; i++) {
    xi = (individual->chromosome_->gene_[i])->getRealAllele() ;
    result += pow(fabs(xi), a) + 5 * sin(pow(xi, b)) ;
  } //for
  individual->fitness_[1] = result ;
} // Fonseca::evaluateIndividual


