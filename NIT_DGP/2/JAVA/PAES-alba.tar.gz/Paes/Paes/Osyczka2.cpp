/**
 * @file        Osyczka2.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Osyczka's problem.
 *              This problem is renamed MOP-C2 in Coello et al.
 */

#include <Osyczka2.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Osyczka2::Osyczka2(VariableType variableType) {
  problemName_ = "OSYCZKA2-MOP-C2" ;

  numberOfVariables_   = 6 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 6 ;

  const double upperLimit[] = {10.0, 10.0, 5.0, 6.0, 5.0, 10.0} ;
  const double lowerLimit[] = {0.0, 0.0, 1.0, 0.0, 1.0, 0.0} ;
  const int partitions[]    = {30, 30, 30, 30, 30, 30} ;
  const int precision[]     = {5, 5, 5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;

// int bitsPerBinaryVariable[] = {10, 10, 10} ;

  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;
//  memcpy(bitsPerVariable_, bitsPerVariable, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;
  int i ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Osyczka2::Osyczka2

void Osyczka2::evaluate(Individual *individual) {
  // First function
  double result ;
  double x[6]   ;
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;

  result =  -(25 * (x[0] - 2) * (x[0] - 2) +
                   (x[1] - 2) * (x[1] - 2) +
                   (x[2] - 1) * (x[2] - 1) +
                   (x[3] - 4) * (x[3] - 4) +
                   (x[4] - 1) * (x[4] - 1)) ;

  individual->fitness_[0] = result ;

  // Second function
  result = x[0]*x[0] +
           x[1]*x[1] +
           x[2]*x[2] +
           x[3]*x[3] +
           x[4]*x[4] +
           x[5]*x[5] ; 

  individual->fitness_[1] = result ;
} // Osyczka2::evaluateIndividual


bool Osyczka2::constraintsAreSatisfied(Individual * individual) {
  double x[6] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;
  
  if ((0 <= (x[0]+x[1] - 2))     &&
      (0 <= (6 - x[0] - x[1]))   &&
      (0 <= (2 + x[0] + x[1]))   &&
      (0 <= (2 - x[0] + 3*x[1])) &&
      (0 <= (4 - (x[2]-3)*(x[2]-3)- x[3])) &&
      (0 <= ((x[4]-3)*(x[4]-3)+x[5]-4)))
        return true ;
  else
    return false ;
} // Osyczka2::constraintsAreSafisfied

int Osyczka2::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter ;
  double x[6]    ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;
  
  counter = 0 ;  

  if (0 > (x[0]+x[1] - 2))
    counter ++ ;
  if (0 > (6 - x[0] - x[1]))
    counter ++ ;
  if (0 > (2 + x[0] + x[1]))
    counter ++ ;
  if (0 > (2 - x[0] + 3*x[1]))
    counter ++ ;
  if (0 > (4 - (x[2]-3)*(x[2]-3)- x[3]))
    counter ++ ;
  if (0 > ((x[4]-3)*(x[4]-3)+x[5]-4))
    counter ++ ;
    
  return counter ;  
} // Osyczka2::numberOfNonSatisfiedConstraints
