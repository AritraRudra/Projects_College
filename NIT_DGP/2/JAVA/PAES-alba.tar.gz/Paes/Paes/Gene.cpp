/*
 * @file    Gene.cpp
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Abstract class representing a generic gene
 */
 
#include <Gene.h>

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
Gene::Gene(VariableType geneType, Random * random) {
  random_   = random   ;
  geneType_ = geneType ;
} // Gene::Gene(

/**
 * @brief Copy constructor
 * @param gene The gene to copy
 *
 * Constructor of the class
 */
Gene::Gene(Gene & gene) {
  random_   = gene.random_ ;
  geneType_ = gene.geneType_ ;
} // Gene::Gene

/**
 * @brief Copy constructor
 * @param gene The gene to copy
 *
 * Constructor of the class
 */
Gene::Gene(Gene * gene) {
  random_   = gene->random_ ;
  geneType_ = gene->geneType_ ;
} // Gene::Gene

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
Gene::~Gene() {
} // Gene::~Gene



int Gene::bitFlipMutation(double mutationProbability) {
  cerr << "Bit-flip mutation cannot be applied to a gene of type "  
       << geneType_ << endl ; 
  exit(-1) ;
} // Gene::bitFlipMutation

int Gene::randomMutation(double mutationProbability) {
  cerr << "Random mutation cannot be applied to a gene of type "  
       << geneType_ << endl ; 
  exit(-1) ;
} // Gene::randomMutation

int Gene::polynomialMutation(double mutationProbability, 
                             double distributionIndex) {
  cerr << "Polynomial mutation cannot be applied to a gene of type "  
       << geneType_ << endl ; 
  // exit(-1) ;
} // Gene::polynomialMutationint 

int Gene::uniformMutation(double mutationProbability, 
                      double perturbation) {
  cerr << "Uniform mutation cannot be applied to a gene of type "  
       << geneType_ << endl ; 
  // exit(-1) ;
} // Gene::uniformMutation

double Gene::getRealAllele() {
  cerr << "getRealAllele() cannot be applied to a gene of type "  
       << geneType_ << endl ; 
  exit(-1) ;
} // Gene::getRealAllele

/**
 * @brief Copy operator
 */  
Gene & Gene::operator=(const Gene& gene) {
  random_   = gene.random_ ;
  geneType_ = gene.geneType_ ;
  
  return *this ;  
} // Gene::operator=

/**
 * @brief << operator
 */  
ostream& operator<< (ostream& outputStream, Gene& gene) {
  outputStream << "Gene type: " << gene.geneType_ ;
} // operator<< 

