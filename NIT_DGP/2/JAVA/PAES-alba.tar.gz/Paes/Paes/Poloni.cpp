/**
 * @file        Poloni.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Specificacion of Poloni's problem.
 *              This problem is renamed MOP3 in Coello et al.
 */
 
#include <Poloni.h>


/**
 * @brief Constructor
 */
Poloni::Poloni(VariableType variableType) {

  problemName_ = "Poloni-MOP3" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;
  
  const double upperLimit[] = {3.1416, 3.1416} ;
  const double lowerLimit[] = {-3.1416, -3.1416} ;
  const int    partitions[] = {700, 700} ;
  const int precision[]     = {5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Poloni::Poloni


static const double A1 = 0.5 * sin(1.0) - 2 * cos(1.0) + 
                         sin(2.0) - 1.5 * cos(2.0) ; //!< Constant A1
static const double A2 = 1.5 * sin(1.0) - cos(1.0) + 
                         2 * sin(2.0) - 0.5 * cos(2.0) ; //!< Constant A2

void Poloni::evaluate(Individual * individual) {
  // First function
  double result ;
  double x[2]   ;
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  double B1 = 0.5 * sin(x[0]) - 2 * cos(x[0]) + sin(x[1]) - 1.5 * cos(x[1]) ;
  double B2 = 1.5 * sin(x[0]) - cos(x[0]) + 2 * sin(x[1]) - 0.5 * cos(x[1]) ;
  result = -(1 + pow(A1 - B1, 2) + pow(A2 - B2, 2)) ;

  individual->fitness_[0] = - result ;  

  // Second function
  result = -(pow(x[0]+3,2) + pow(x[1]+1,2)) ;

  individual->fitness_[1] = - result ;
} // Poloni::evaluate

