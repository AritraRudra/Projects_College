/**
 * @file        Golinski.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Golinski's problem, also
 *              known as Speed Reducer
 */

#include <Golinski.h>

/**
 * @brief Constructor
 */
Golinski::Golinski(VariableType variableType) {
  problemName_ = "Golinski" ;

  numberOfVariables_   = 7 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 11 ;

  const double upperLimit[] = {3.6, 0.8, 28.0, 8.3, 8.3, 3.9, 5.5} ;
  const double lowerLimit[] = {2.6, 0.7, 17.0, 7.3, 7.3, 2.9, 5.0} ;
  const int partitions[]    = {30, 30, 30, 30, 30, 30, 30} ;
  const int precision[]     = {5, 5, 5, 5, 5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Golinski::Golinski


void Golinski::evaluate(Individual * individual) {
  double x[7] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;
  x[6] = (individual->chromosome_->gene_[6])->getRealAllele() ;
  
  // First function
  individual->fitness_[0] = 0.7854 * x[0]*x[1]*x[1]*(10*x[2]*x[2]/3 + 
                                     14.933*x[2]-43.0934) -
                                     1.508*x[0]*(x[5]*x[5]+x[6]*x[6]) +
                                     7.477*(x[5]*x[5]*x[5] + x[6]*x[6]*x[6]) +
                                     0.7854*(x[3]*x[5]*x[5] + x[4]*x[6]*x[6]) ;

  // Second function
  double aux = 745.0 * x[3] / (x[1] * x[2]) ; 
  individual->fitness_[1] = sqrt((aux*aux + 1.69e7)) / (0.1*x[5]*x[5]*x[5]) ;
} // Golinski::evaluate


bool Golinski::constraintsAreSatisfied(Individual * individual) {
  double x[7]      ;
  bool   result    ;
  double aux       ;
  double function2 ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;
  x[6] = (individual->chromosome_->gene_[6])->getRealAllele() ;

  aux = 745.0 * x[3] / (x[1] * x[2]) ; 
  function2 = sqrt((aux*aux + 1.69e7)) / (0.1*x[5]*x[5]*x[5]) ;

  result = false ;
  if (0 >= ((1.0/(x[0]*x[1]*x[1]*x[2])) - 1.0/27.0))       // g1
  if (0 >= ((1.0/(x[0]*x[1]*x[1]*x[2]*x[2])) - 1.0/397.5)) // g2
  if (0 >= (x[3]*x[3]*x[3]/(x[1]*x[2]*x[5]*x[5]*x[5]*x[5]) - 1.0/1.93))  // g3
  if (0 >= (x[4]*x[4]*x[4]/(x[1]*x[2]*x[6]*x[6]*x[6]*x[6]) - 1.0/1.93))  // g4
  if (0 >= (x[1]*x[2] - 40.0))                              // g5
  if (0 >= (x[0]/x[1] - 12.0))                              // g6
  if (0 >= (5.0 - x[0]/x[1]))                               // g7
  if (0 >= (1.9 - x[3] + 1.5*x[5]))                         // g8
  if (0 >= (1.9 - x[4] + 1.1*x[6]))                         // g9
  if (1300 >= function2)                                       // g10
  if (1100 >= (sqrt((745*x[4]/(x[1]*x[2]))*(745*x[4]/(x[1]*x[2]))+1.575e8)/
               (.1*x[6]*x[6]*x[6])))                       // g11
    result = true  ;
    
  return result ;
} // Golinski::constraintsAreSafisfied

int Golinski::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter   ;
  double x[7]      ;
  double aux       ;
  double function2 ;
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  x[2] = (individual->chromosome_->gene_[2])->getRealAllele() ;
  x[3] = (individual->chromosome_->gene_[3])->getRealAllele() ;
  x[4] = (individual->chromosome_->gene_[4])->getRealAllele() ;
  x[5] = (individual->chromosome_->gene_[5])->getRealAllele() ;
  x[6] = (individual->chromosome_->gene_[6])->getRealAllele() ; 

  aux = 745.0 * x[3] / (x[1] * x[2]) ; 
  function2 = sqrt((aux*aux + 1.69e7)) / (0.1*x[5]*x[5]*x[5]) ;

  counter = 0 ;  
  if (0 < ((1.0/(x[0]*x[1]*x[1]*x[2])) - 1.0/27.0))       // g1
    counter ++ ;
  if (0 < ((1.0/(x[0]*x[1]*x[1]*x[2]*x[2])) - 1.0/397.5)) // g2
    counter ++ ;
  if (0 < (x[3]*x[3]*x[3]/(x[1]*x[2]*x[5]*x[5]*x[5]*x[5]) - 1.0/1.93))  // g3
    counter ++ ;
  if (0 < (x[4]*x[4]*x[4]/(x[1]*x[2]*x[6]*x[6]*x[6]*x[6]) - 1.0/1.93))  // g4
    counter ++ ;
  if (0 < (x[1]*x[2] - 40.0))                              // g5
    counter ++ ;
  if (0 < (x[0]/x[1] - 12.0))                              // g6
    counter ++ ;
  if (0 < (5.0 - x[0]/x[1]))                               // g7
    counter ++ ;
  if (0 < (1.9 - x[3] + 1.5*x[5]))                         // g8
    counter ++ ;
  if (0 < (1.9 - x[4] + 1.1*x[6]))                         // g9
    counter ++ ;
  if (1300 < function2)                                       // g10
    counter ++ ;
  if (1100 < (sqrt((745*x[4]/(x[1]*x[2]))*(745*x[4]/(x[1]*x[2]))+1.575e8)/
               (.1*x[6]*x[6]*x[6])))                       // g11
    counter ++ ;

  return counter ;  
} // Golinski::numberOfNonSatisfiedConstraints


