/**
 * @file        Viennet4.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Viennet(4)'s problem. This problem is renamed 
 *              MOP-C3 in Coello et al.
 */ 

#include <Viennet4.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Viennet4::Viennet4(VariableType variableType) {

  problemName_ = "Viennet4-MOP-C3" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 3 ;
  numberOfConstraints_ = 3 ;

  const double upperLimit[] = {4.0, 4.0} ;
  const double lowerLimit[] = {-4.0, -4.0} ;
  const int    partitions[] = {200, 200} ;
  const int    precision[]     = {5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Viennet4::Viennet4



void Viennet4::evaluate(Individual * individual) {
  double x[2] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  // First function
  individual->fitness_[0] = (x[0]-2)*(x[0]-2)/2.0 + 
                            (x[1]+1)*(x[1]+1)/13.0 + 3.0 ;

  // Second function

  individual->fitness_[1] = (x[0]+x[1]-3)*(x[0]+x[1]-3)/175.0 +
                            (2*x[1]-x[0])*(2*x[1]-x[0])/17.0 - 13.0 ;

  // Third function
  individual->fitness_[2] = (3*x[0]-2*x[1]+4)*(3*x[0]-2*x[1]+4)/8.0 +
                            (x[0]-x[1]+1)*(x[0]-x[1]+1)/27.0 + 15 ;
} // Viennet4::evaluate


bool Viennet4::constraintsAreSatisfied(Individual * individual) {
  double x[2];
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  
   if ((x[1] < (-4*x[0] +4)) &&
      (x[0] > -1)           &&
      (x[1] > (x[0]-2)))
    return true ;
  else
    return false ;
} // Viennet4::constraintsAreSafisfied

int Viennet4::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter ;
  double x[2]    ;

  counter = 0 ;
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
 
  if (x[1] < (-4*x[0] +4)) 
    counter ++ ;
  if (x[0] > -1)          
    counter ++ ;
  if (x[1] > (x[0]-2))
    counter ++ ;

  return counter ;
} // Viennet4::numberOfNonSatisfiedConstraints
