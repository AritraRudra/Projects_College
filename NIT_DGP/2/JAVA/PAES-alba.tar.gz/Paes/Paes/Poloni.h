/**
 * @file        Poloni.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Header file of Poloni.cpp
 */  

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __POLONI__
#define __POLONI__

/**
 * @class Poloni
 * @brief Class representing Poloni's problem
 */
class Poloni : public MultiobjectiveProblem {
public:
  // Constructor
  Poloni(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
} ; // class Poloni

#endif
