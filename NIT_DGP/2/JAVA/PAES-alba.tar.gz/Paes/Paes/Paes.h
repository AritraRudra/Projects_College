/**
 * @file        Paes.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        22 January 2004
 * @brief       Header file of Paes.cpp.
 */


#ifndef __PAES__
#define __PAES__

#include <Configuration.h>

#include <time.h>

#include <MultiobjectiveProblem.h>
#include <Random.h>
#include <Population.h>
#include <AdaptiveGrid.h>

/**
 * @class Paes
 * @brief 
 */
class Paes {
private:
  int    depth_                        ; 
  int    numberOfGenes_                ;
  int    maximumArchiveLength_         ;
  int    numberOfIterations_           ;
  double mutationProbability_          ;
  int    numberOfFitnessEvaluations_   ;

  double distributionIndexForMutation_ ;
  double perturbationForMutation_      ;
  
  MutationOperator mutationOperator_   ;
  
#ifdef __MPI__  
  int    migrationRate_ ;
  int    processIdentifier_ ;
  int    numberOfProcesses_ ;
#endif 
  
  Random random_ ;
  int    seed_   ;
  
  MultiobjectiveProblem * problem_ ; //!< Problem to be solved
  
  time_t startTime_ ;
  time_t endTime_   ;

/*
  int      numberOfVariables_    ;
  int      numberOfFunctions_    ;
  double * precisionOfVariables_ ;
  int    * numberOfBitsPerGene_  ;
  int      chromosomeLength_     ;
*/  

  Individual *  currentSolution_    ;
  Individual *  mutantSolution_     ;
  Population *  archiveOfSolutions_ ;
  
  AdaptiveGrid  * adaptiveGrid_          ; 
  int             numberOfGridDivisions_ ;

  int printFrequency_ ;

  //double decodeGene(int gene, BinaryChromosome * chromosome) ;

public:
  // Constructors
  Paes(MultiobjectiveProblem * problemToSolve,
       MutationOperator        mutationOperator) ;

  // Methods
  void start()                                        ;
  void addToArchive(Individual *solution)       ;
  bool archiveSolution(Individual *solution)    ;
  int  compareToArchive(Individual *solution)   ;

  void readConfigurationData() ;
  
  void printStatistics()                                      ;
  void printToFiles(char * variableFile, char * functionFile) ;
} ; // Paes


#endif

