/**
 * @file        Deb.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Deb's problem.
 *              This problem is renamed MOP6 in Coello et al.
 */ 
 
#include <Deb.h>

/**
 * @brief Constructor
 */
Deb::Deb(VariableType variableType) {

  problemName_ = "Deb-MOP61" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {1.0, 1.0} ;
  const double lowerLimit[] = {0.0, 0.0} ;
  const int    partitions[] = {800, 800} ;
  const int precision[]     = {5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Deb::Deb


static const double alpha = 2.0 ; //!< Constant alpha
static const double q     = 4.0 ; //!< Constant q

void Deb::evaluate(Individual * individual) {
  double x[2] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  // First function
  individual->fitness_[0] = x[0] ;

  // Second function

  individual->fitness_[1] = (1 + 10 * x[1]) * 
                            (1 - pow(x[0]/(1+10*x[1]), alpha) -
                            (x[0] / (1+10*x[1])* sin(2*3.1416*q*x[0]))) ;

} // Deb::evaluate

