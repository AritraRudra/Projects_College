/**
 * @file        Configuration.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        26 November 2003
 * @brief       This file contains configuration data to adapt the programs to
 *              new and old C++ styles
 */ 
 
#ifndef __CONFIGURATION_H__
#define __CONFIGURATION_H__

#include <math.h>

#ifdef __OLD_CPP__

#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <limits.h>
#include <float.h>
typedef int bool ;
const bool true  = 1 ;
const bool false = 0 ;

#else
#include <string>
#include <iostream>
#include <fstream>
#include <climits>
#include <cfloat>

using namespace std ;

const long MAX_INT = LONG_MAX ;
const long MIN_INT = LONG_MIN ;

const double MAX_REAL = HUGE_VAL  ;
const double MIN_REAL = -MAX_REAL ;

#endif

#include <stdlib.h>

enum MutationOperator {BIT_FLIP, RANDOM, POLYNOMIAL, UNIFORM} ; 
enum VariableType {BINARY, BINARY_REAL, BINARY_GRAY_REAL, REAL, 
                   TREE, INTEGER, PERMUTATION} ;

#endif
