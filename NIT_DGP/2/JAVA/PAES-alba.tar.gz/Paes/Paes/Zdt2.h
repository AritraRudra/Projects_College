/**
 * @file        Zdt2.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Header file of ZDT2.cpp
 */ 
 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __ZDT2__
#define __ZDT2__

/**
 * @class Zdt2
 * @brief Class representing the problem Zdt1
 */
class Zdt2 : public MultiobjectiveProblem {
public:
  // Constructor
  Zdt2(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
} ; // class Zdt2

#endif
