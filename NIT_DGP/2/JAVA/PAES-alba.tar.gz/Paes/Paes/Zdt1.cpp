/**
 * @file        Zdt1.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        14 October 2003
 * @brief       Specificacion of the problem ZDT1. This problem is renamed
 *              MOP-G1 in Coello et al. (2002). The problem is defined in 
 *              Zitzler et at. (2000)
 */ 
 
#include <Zdt1.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Zdt1::Zdt1(VariableType variableType) {

  problemName_ = "ZDT1-MOP-G1" ;

  numberOfVariables_   = 30 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                               1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                               1, 1, 1, 1, 1, 1, 1, 1, 1, 1} ;
  const double lowerLimit[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                               0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                               0, 0, 0, 0, 0, 0, 0, 0, 0, 0} ;
  const int    partitions[] = {5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                               5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                               5, 5, 5, 5, 5, 5, 5, 5, 5, 5} ;
  const int    precision[] = {5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                               5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                               5, 5, 5, 5, 5, 5, 5, 5, 5, 5} ;


  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Zdt1::Zdt1


static double g(MultiobjectiveProblem * problem, Individual * individual) {
  int i ;
  double sum ;
  
  sum = 0;
  for (i = 1; i < problem->numberOfVariables_; i++)
    sum += (individual->chromosome_->gene_[i])->getRealAllele() ;
  
  return 1 + 9/(problem->numberOfVariables_ - 1)* sum ;
} ;


void Zdt1::evaluate(Individual * individual) {
  int    i ;
  double x ;

  x = (individual->chromosome_->gene_[0])->getRealAllele() ;
  // First function
  individual->fitness_[0] = x;

  // Second function

  individual->fitness_[1] = 1 - sqrt(x/g(this, individual)) ;
} // Zdt1::evaluate


