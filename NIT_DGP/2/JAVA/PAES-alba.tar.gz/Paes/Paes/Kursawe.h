/**
 * @file        Kursawe.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        26 January 2004
 * @brief       Header file of Kursawe.cpp
 */  

#include <Configuration.h>

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __KURSAWE__
#define __KURSAWE__

/**
 * @class Kursawe
 * @brief Class representing Kursawe's problem
 */
class Kursawe : public MultiobjectiveProblem {
public:
  // Constructor
  Kursawe(VariableType type) ;
  
  void evaluate(Individual *individual) ;
} ; // class Kursawe

#endif
