/**
 * @file        Binh2.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Binh2.cpp
 */

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __BINH2__
#define __BINH2__

/**
 * @class Binh2
 * @brief Class representing Bihn(2)'s problem

  Minimize \f$ F = (f_1(x,y), f_2(x,y))\f$

 \f$ f_1(x,y) = 4x^2 + 4y^2 \f$

 \f$ f_2(x,y) = (x - 5)^2 + (y - 5)^2 \f$

 \f$ 0 \geq (x - 5)^2 + (y - 5)^2 - 25 \f$

 \f$ 0 \geq -(x - 8)^2 - (y + 3)^2 + 7.7\f$

 \f$ 0 \leq x \leq 5\f$ ; \f$ 0 \leq y \leq 3\f$
 */
class Binh2 : public MultiobjectiveProblem {
public:
  // Constructor
  Binh2(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;

  bool constraintsAreSatisfied(Individual * individual) ;
  int  numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Binh2

#endif

