/**
 * @file        Osyczka2.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Osyczka2.cpp
 */ 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __OSYZCKA2__
#define __OSYZCKA2__

/**
 * @class Osyczka2
 * @brief Class representing Osyczka's problem
 */
class Osyczka2 : public MultiobjectiveProblem {
public:
  // Constructor
  Osyczka2(VariableType variableType) ;

  // Methods

  void evaluate(Individual *individual) ;

  bool constraintsAreSatisfied(Individual * individual) ;
  int  numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Osyczka2

#endif

