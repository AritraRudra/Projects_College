/**
 * @file        Zdt1.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Header file of ZDT1.cpp
 */ 
 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __ZDT1__
#define __ZDT1__

/**
 * @class Zdt1
 * @brief Class representing the problem Zdt1
 */
class Zdt1 : public MultiobjectiveProblem {
public:
  // Constructor
  Zdt1(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
  
} ; // class Zdt1

#endif
