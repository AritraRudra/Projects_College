/*
 * @file    BinaryGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of BinaryGene.cpp
 */
 
#include <Configuration.h>
#include <Gene.h>

#ifndef __BINARY_GENE__
#define __BINARY_GENE__

/**
 * @class BinaryGene
 * @brief Abstract class that represents a binary gene
 */
class BinaryGene : public Gene {
public:
  char * allele_       ; //!< Bit string
  int    numberOfBits_ ; //!< Number of bits of the bit string
  
  // Constructors  
  BinaryGene(int bits, Random * random) ;
  BinaryGene(BinaryGene & binaryGene) ;
  BinaryGene(BinaryGene * binaryGene) ;

  // Destructors
  ~BinaryGene() ; 
  
  // Methods
  int bitFlipMutation(double mutationProbability) ;

  void writeGenotype(ofstream &outputFile) ;
  
  // Operators
  BinaryGene & operator=(const BinaryGene& binaryGene) ;
  friend ostream& operator<< (ostream& outputStream, BinaryGene& gene) ;  
    
} ; // Binary

#endif

