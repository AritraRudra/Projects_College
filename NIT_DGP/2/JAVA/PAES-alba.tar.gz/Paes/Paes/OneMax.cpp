#include <OneMax.h>

OneMax::OneMax(int numberOfBits) {
  problemName_ = "OneMax" ;
  numberOfVariables_   = 1 ;
  numberOfFunctions_   = 1 ;
  numberOfConstraints_ = 0 ;
    
  numberOfBits_ = numberOfBits ;
  
  variable_ = new VariableType[numberOfVariables_] ;
  variable_[0] = BINARY ;
  
  cout << "Created a " << problemName_ << " problem. Number of bits: " 
       << numberOfBits << endl ;
} // OneMax::OneMax
  
void OneMax::evaluate(Individual *individual) {
  int counter ;
  int i ;
     
  counter = 0 ;
  for (i = 0; 
       i < ((BinaryGene*)(individual->chromosome_->gene_[0]))->numberOfBits_; 
       i++)
    if (((BinaryGene*)(individual->chromosome_->gene_[0]))->allele_[i] == '1')
      counter ++ ;
         
  individual->fitness_[0] = - counter ;
} // OneMax::evaluateIndividual
