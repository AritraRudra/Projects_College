/**
 * @file        Viennet4.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Viennet4.cpp
 */
 
#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __VIENNET4__
#define __VIENNET4__

/**
 * @class Viennet4
 * @brief Class representing Viennet(4)'s problem
 */
class Viennet4 : public MultiobjectiveProblem {
public:
  // Constructor
  Viennet4(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;

  bool constraintsAreSatisfied(Individual * individual) ;
  int  numberOfNonSatisfiedConstraints(Individual * individual) ;
} ; // class Viennet4

#endif

