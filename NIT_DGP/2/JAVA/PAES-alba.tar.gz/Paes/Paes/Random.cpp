/**
 * @file        MicroGA.cpp
 * @author      Carlos A. Coello Coello
 * @author      Francisco Luna Valero
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        26 November 2003
 * @brief       This file includes some random functions
 *
 */

#include <Random.h>

using namespace std;

#define NRAND_SAMPLES 5
#define Uniform randreal2

#define Gmaximo 5000

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Random::Random() {
  Seed   = 0 ;
  isinit = 0 ;
} //Constructor

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
Random::~Random() {
} //Destructor

/**
 * @brief Flip a biased coin - true if heads 
 * @param prob The biased probability
 */
int Random::flip(float prob)
{
  //float randomperc();
    if(randomperc() <= prob)
	return(1);
    else
	return(0);
}


/**
 * @brief advance_random
 */
void Random::advance_random()
{
	int j1;
	double new_random;

	for(j1 = 0; j1 < 24; j1++)
	{
	new_random = oldrand[j1] - oldrand[j1+31];
	if(new_random < 0.0) new_random = new_random + 1.0;
	oldrand[j1] = new_random;
	}

	for(j1 = 24; j1 < 55; j1++)
	{
	new_random = oldrand [j1] - oldrand [j1-24];
	if(new_random < 0.0) new_random = new_random + 1.0;
	oldrand[j1] = new_random;
  }
}


/**
 * Initialization routine for randomnormaldeviate 
 */
void Random::initrandomnormaldeviate()
{
    rndcalcflag = 1;
}

/** 
 * @brief Normal noise with specified mean & std dev: mu & sigma 
 * @param mu The mean of the distribution
 * @param sigma The standard deviation of the distribution
 */
double Random::noise(double mu,double sigma)
{
    //double randomnormaldeviate();
    return((randomnormaldeviate()*sigma) + mu);
}

/**
 * @brief Initialize random numbers batch 
 */
void Random::randomize()

{
	int j1;

    for(j1=0; j1<=54; j1++)
      oldrand[j1] = 0.0;

	jrand=0;

	 warmup_random(Rseed);
}

/**
 * @brief Random normal deviate after ACM algorithm 267 / Box-Muller Method 
 */
double Random::randomnormaldeviate()

{
//    double sqrt(), log(), sin(), cos();
    //float randomperc();
	double t, rndx1;

    if(rndcalcflag)
    {
	rndx1 = sqrt(- 2.0*log((double) randomperc()));
	t = 6.2831853072 * (double) randomperc();
	rndx2 = sin(t);
	rndcalcflag = 0;
	return(rndx1 * cos(t));
    }

    else

    {
	rndcalcflag = 1;
	return(rndx2);
	}

}

/**
 * @brief Fetch a single random number between 0.0 and 1.0
 *
 * Fetch a single random number between 0.0 and 1.0 - Subtractive Method 
 * See Knuth, D. (1969), v. 2 for details 
 * name changed from random() to avoid library conflicts on some machines
 */
float Random::randomperc()
{
//cout << "randomperc. 0; " << endl; 
    jrand++;
//cout << "randomperc. 1" << endl;

    if(jrand >= 55)
	{
	jrand = 1;
	advance_random();
    }

    return((float) oldrand[jrand]); 
//    return 0.0;
}

/**
 * @brief Pick a random integer between low and high 
 */
int Random::rnd(int low, int high)

{
    int i;
	//float randomperc();
//cout << "Generating a random number..." << endl;
    if(low >= high)
	     i = low;
    else
    {
//cout << "Generating a random number 1 ..." << endl;
	     i =(int) (randomperc() * (high - low + 1)) + low;
//cout << "Generating a random number 2 ..." << endl;
    	if(i > high) 
        i = high;
    }

	return(i);
}

/** 
 * @brief Real random number between specified limits 
 */
float Random::rndreal(float lo ,float hi)

{
	return((randomperc() * (hi - lo)) + lo);
}

/**
 * @brief Get random off and running 
 */
void Random::warmup_random(float random_seed)

{
	int j1, ii;
	double new_random, prev_random;

	oldrand[54] = random_seed;
	new_random = 0.000000001;
	prev_random = random_seed;

	for(j1 = 1 ; j1 <= 54; j1++)

	{
	ii = (21*j1)%54;
	oldrand[ii] = new_random;
	new_random = prev_random-new_random;
	if(new_random<0.0) new_random = new_random + 1.0;
	prev_random = oldrand[ii];
	}

	advance_random();
	advance_random();
	advance_random();

	jrand = 0;
}

/********************* RandEvolutiva ******************************************/
/**
 * @brief randreal2
 */
double Random::randreal2(void)
{
	double result;

	if (!isinit) {
		srand(Seed);
		isinit = 1;
	}
	result = ((double) rand());
	result /= RAND_MAX;

	return (result);
}

/**
 * @brief Gauss distribution
 * @param sigma The standard deviation
 * @return A Gauss distribution value
 */
double Random::Gauss(double sigma)
{
	/* System generated locals */
	double ret_val;

	/* Local variables */
	static double u, x, y, u0, u1, u2;


	/*	SIGMA	--> standard deviation */

	/* L1: */
	u = Uniform();
	u0 = Uniform();
	if (u >= .919544406) {
		goto L2;
	}
	x = (u0 + u * .825339283) * 2.40375766 - 2.11402808;
		goto L10;
	L2:
		if (u < .965487131) {
			goto L4;
		}
	L3:
		u1 = Uniform();
		y = sqrt(4.46911474 - log(u1) * 2.);
		u2 = Uniform();
		if (y * u2 > 2.11402808) {
			goto L3;
		}
		goto L9;
	L4:
		if (u < .949990709) {
			goto L6;
		}
	L5:
		u1 = Uniform();
		y = u1 * .273629336 + 1.84039875;
		u2 = Uniform();
		if (exp(y * -.5 * y) * .39894228 - .443299126 + y * .209694057 < u2 *
			.0427025816) {
			goto L5;
		}
		goto L9;
	L6:
		if (u < .925852334) {
			goto L8;
		}
	L7:
		u1 = Uniform();
		y = u1 * 1.55066917 + .289729574;
		u2 = Uniform();
		if (exp(y * -.5 * y) * .39894228 - .443299126 + y * .209694057 < u2 *
			.0159745227) {
			goto L7;
		}
		goto L9;
	L8:
		u1 = Uniform();
		y = u1 * .289729574;
		u2 = Uniform();
		if (exp(y * -.5 * y) * .39894228 - .382544556 < u2 * .0163977244) {
			goto L8;
		}
	L9:
		x = y;
		if (u0 >= .5) {
			x = -y;
		}
	L10:
		ret_val = sigma * x;
		return ret_val;
} /* Gauss() */

/**
 * @brief N
 */
double Random::N(double m, double sigma)
{
	return m + Gauss(sigma);
}

/**
 * @brief Initialize the random seed
 * @param seed The random seed
 */
void Random::initrandom(int seed)
{
	Seed = seed;
}


int Random::randint(int lo, int hi)
{
	return (lo + (int) randreal2() * (hi - lo + 1));
}

