/**
 * @file     Population.h
 * @author   Antonio Jesus Nebro Urbaneja
 * @version  2.0
 * @date     22 January 2004
 * @brief
 */
 
#include <Population.h>

/**
 * @brief Constructor
 * @param populationSize The size of the population
 * @param chromosomeLength The length of the individual chromosomes
 * @param numberOfFunctions The number of objective functions
 *
 * Constructor of the class
 */
Population::Population(int populationSize       , 
                       int maximumPopulationSize,
                       Random * random          ,   
                       MultiobjectiveProblem * problem) {   
  problem_               = problem               ;
  populationSize_        = populationSize        ;
  maximumPopulationSize_ = maximumPopulationSize ;
  random_                = random                ;
  
  population_ = new Individual * [maximumPopulationSize] ;
  if (!population_) {
    cerr << "Population::Population-> error when asking for memory " << endl ;
    exit(-1) ;
  } // if
  
  int i ;
  for (i = 0; i < populationSize_; i++) 
    population_[i] = new Individual(problem_, random) ;
} // Population::Population

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
Population::~Population(void) {
} // Population::~Population

/**
 * @brief Gets the size of the population
 * @return The size of the population
 */
int Population::getPopulationSize() const {
  return populationSize_;
} // getPopulationSize
  
 
/**
 * @brief Gets the maximum size of the population
 * @return The maximum size of the population
 */
int Population::getMaximumPopulationSize() const {
  return maximumPopulationSize_ ;
} // getMaximumPopulationSize
  
/**
 * @brief Gets the i-th individual of the population
 * @param index The index of the individual
 * @return The i-th individual
 */
Individual * Population::getIth(int index) const {
  if ((index < populationSize_) && (index >= 0))
    return population_[index];
  else {
    cerr << "Population::getIth - Index out of range when getting a copy of "
         << "an individual" ;
    cerr << endl ;
    exit(-1) ;
  } // else
} // getIth

/**
 * @brief Sets the i-th individual of the population
 * @param index The index of the individual
 * @param individual The individual to assign
 */
void Population::setIth(int index, Individual * individual) {
  if ((index < populationSize_) && (index >= 0))
    population_[index] = individual ;
  else {
    cerr << "Population::setIth - Index out of range when inserting an "
         << "individual" ;
    cerr << endl ;
    exit(-1) ;
  } // else  
} // setIth

/**
 * @brief Sets the fitness of the i-th individual
 * @param index The position of the individual
 * @param fitness The individual fitness 
 */
void Population::setFitness(int index, double * fitness) {
  population_[index]->setFitness(fitness);
} // setFitness


/**
 * @brief Sets the fitness of the i-th individual
 * @param index The position of the individual
 * @param fitness The individual fitness 
 */
void Population::addIndividual(Individual * individual) {
  if (populationSize_ < maximumPopulationSize_) {
    population_[populationSize_] = individual ;
    populationSize_ += 1 ;
  } // if
  else {
    cerr << "Population::addIndividual->The population size has reach to its "
         << "maximum size" << endl ;
    exit(-1) ;
  } // else
} // Population::addIndividual

  
/**
 * @brief Gets the i-th individual of the population
 * @param index The index of the individual
 * @return The i-th individual
 */
void Population::deleteIth(int index) {
  if ((index < populationSize_) && (index >= 0)) {
    delete population_[index] ;
    int i ;
    for (i = index; i < (populationSize_ - 1); i++)
      population_[i] = population_[i + 1] ;
    populationSize_ -- ;
  } // if
  else {
    cerr << "Population::deleteIth - Index " << index << " out of range " ;
    cerr << endl ;
    exit(-1) ;
  } // else
} // Population::deleteIth

/**
 * @brief Prints the fitness of the individuals in the population
 * @param fileName The name of the ouput file
 */
void Population::printFitness(char *fileName) {
  ofstream outputFile ;
  int      i          ;
  int      j          ;

  outputFile.open(fileName, ios::out) ;
  outputFile.precision(10) ;
  
  for (j = 0 ; j < getPopulationSize(); j++) {
    for (i = 0; i < problem_->numberOfFunctions_ ; i++)
      outputFile << getIth(j)->getFitness()[i] << "\t" ;
    outputFile << endl ;
  } // for

  outputFile.close() ;      
} // Population::printFitness

/**
 * @brief Prints the genotype of the individuals in the population
 * @param fileName The name of the ouput file
 */
void Population::printGenotype(char *fileName) {
  ofstream outputFile ;
  int      i          ;
  int      j          ;

  outputFile.open(fileName, ios::out) ;
  outputFile.precision(15) ;
  
  for (j = 0 ; j < getPopulationSize(); j++) {
    for (i = 0; i < problem_->numberOfVariables_ ; i++) {
      getIth(j)->chromosome_->gene_[i]->writeGenotype(outputFile) ;
      outputFile << "\t" ;
    } // for
    outputFile << endl ;
  } // for 
  
  outputFile.close() ;      
} // Population::printGenotype
