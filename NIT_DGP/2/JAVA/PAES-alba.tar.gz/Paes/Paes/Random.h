/**
 * @file        Random.h
 * @author      Carlos A. Coello Coello
 * @author      Gregorio Toscano Pulido
 * @author      Francisco Luna Valero
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     1.0
 * @date        26 November 2003
 * @brief       Header file of Random.cpp
 */

#ifndef __RANDOM_H__
#define __RANDOM_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

class Random {

public:
  int Seed   ;
  int isinit ;

  float  Rseed       ; //!< Random numbers seed
  double oldrand[55] ; //!< Array of 55 random numbers
  int    jrand       ; //!< Current random number
  double rndx2       ; //!< Variable used with random normal deviate
  int    rndcalcflag ; //!< Variable used with random normal deviate

  Random();
  ~Random();

//functions from DrC.h and DrC.cpp
  void warmup_random(float);
  float rndreal(float,float);
  int rnd(int,int);
  float randomperc();
  double randomnormaldeviate();
  void randomize();
  double noise(double,double);
  void initrandomnormaldeviate();
  int flip(float);
  void advance_random();
//functions from RandEvolutiva.h and RandEvolutiva.cpp
  double randreal2(void);
  double Gauss(double sigma);
  double N(double m, double sigma);
  void initrandom(int seed);
  int randint(int lo, int hi);

}; //Random

#endif
