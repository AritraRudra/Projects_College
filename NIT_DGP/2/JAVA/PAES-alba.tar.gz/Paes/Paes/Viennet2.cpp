/**
 * @file        Viennet2.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Viennet(2)'s problem. This problem is renamed
 *              MOP7 in Coello et al.
 */ 
 
#include <Viennet2.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Viennet2::Viennet2(VariableType variableType) {

  problemName_ = "Viennet2-MOP7" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 3 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {4.0, 4.0} ;
  const double lowerLimit[] = {-4.0, -4.0} ;
  const int    partitions[] = {500, 500, 500} ;
  const int    precision[]     = {5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Viennet2::Viennet2


void Viennet2::evaluate(Individual * individual) {
  double x[2] ;

  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;

  // First function
  individual->fitness_[0] = (x[0]-2)*(x[0]-2)/2.0 + 
                            (x[1]+1)*(x[1]+1)/13.0 + 3.0 ;

  // Second function

  individual->fitness_[1] = (x[0]+x[1]-3)*(x[0]+x[1]-3)/36.0 + 
                            (-x[0]+x[1]+2)*(-x[0]+x[1]+2)/8.0 - 17 ;

  // Third function
  individual->fitness_[2] = (x[0]+2*x[1]-1)*(x[0]+2*x[1]-1)/175.0 +
                            (2*x[1]-x[0])*(2*x[1]-x[0])/17.0 - 13 ;
} // Viennet2::evaluate
