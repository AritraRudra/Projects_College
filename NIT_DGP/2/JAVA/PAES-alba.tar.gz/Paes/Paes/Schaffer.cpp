/**
 * @file        Schaffer.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Specificacion of Schaffer's problem
 */ 
 
#include <Schaffer.h>

/**
 * @brief Constructor
 */
Schaffer::Schaffer(VariableType variableType) {

  problemName_ = "Schaffer-MOP1" ;

  numberOfVariables_   = 1 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {10^5} ;
  const double lowerLimit[] = {-10^5} ;
  const int partitions[]    = {10, 10, 10} ;
  const int precision[]     = {5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;

} // Schaffer::Schaffer


void Schaffer::evaluate(Individual * individual) {
  // First function
  double result ;

  result =  (individual->chromosome_->gene_[0])->getRealAllele() *
            (individual->chromosome_->gene_[0])->getRealAllele() ;
  individual->fitness_[0] = result ;

  // Second function
  result =  ((individual->chromosome_->gene_[0])->getRealAllele() - 2) *
            ((individual->chromosome_->gene_[0])->getRealAllele() - 2) ;

  individual->fitness_[1] = result ;
} // Schaffer::evaluate

