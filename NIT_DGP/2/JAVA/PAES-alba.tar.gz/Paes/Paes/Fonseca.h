#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __FONSECA__
#define __FONSECA__

class Fonseca : public MultiobjectiveProblem {
public:
  Fonseca(VariableType type) ;
  
  void evaluate(Individual *individual) ;
} ; // Fonseca

#endif
