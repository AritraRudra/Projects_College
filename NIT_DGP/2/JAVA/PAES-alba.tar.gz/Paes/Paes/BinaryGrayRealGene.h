#include <Configuration.h>
#include <Gene.h>

#ifndef __BINARY_GRAY_REAL_GENE__
#define __BINARY_GRAY_REAL_GENE__

class BinaryGrayRealGene : public Gene {
private:
  void decodeGene(double lowerLimit, double upperLimit) ;
public:
  char * binaryAllele_ ;
  int    numberOfBits_ ;
  double realAllele_   ;
  double lowerBound_   ;
  double upperBound_   ;
  
  BinaryGrayRealGene(int      numberOfBits, 
                     double   lowerBound, 
                     double   upperBound,
                     Random * random) ;
  BinaryGrayRealGene(BinaryGrayRealGene & binaryGrayRealGene) ;
  BinaryGrayRealGene(BinaryGrayRealGene * binaryGrayRealGene) ;

  int    bitFlipMutation(double mutationProbability) ;
  double getRealAllele() ;

  void   writeGenotype(ofstream &outputFile) ;


  BinaryGrayRealGene & operator=(const BinaryGrayRealGene& gene) ;
  friend ostream& operator<< (ostream& outputStream, BinaryGrayRealGene& gene) ;
  
} ; // BinaryGrayReal

#endif

