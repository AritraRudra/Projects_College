/**
 * @file        Binh2.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Specificacion of Binh(2)'s problem.
 *              This problem is renamed MOP-C1 in Coello et al.
 */

#include <Binh2.h>


/**
 * @brief Constructor
 */
Binh2::Binh2(VariableType variableType) {

  problemName_ = "Binh2-MOP-C1" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 2 ;

  const double upperLimit[] = {30.0, 30.0} ;
  const double lowerLimit[] = {-15.0, -15.0} ;
  const int partitions[]    = {100, 100, 100} ;
  const int precision[]     = {5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;
  
  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Binh2::Binh2


void Binh2::evaluate(Individual * individual) {
  // First function
  double result ;

  result =  4 * (individual->chromosome_->gene_[0])->getRealAllele() *
                (individual->chromosome_->gene_[0])->getRealAllele() +
            4 * (individual->chromosome_->gene_[1])->getRealAllele() *
                (individual->chromosome_->gene_[1])->getRealAllele() ;
  individual->fitness_[0] = result ;

  // Second function
  result =  ((individual->chromosome_->gene_[0])->getRealAllele() - 5) *
            ((individual->chromosome_->gene_[0])->getRealAllele() - 5) +
            ((individual->chromosome_->gene_[1])->getRealAllele() - 5) *
            ((individual->chromosome_->gene_[1])->getRealAllele() - 5) ;

  individual->fitness_[1] = result ;
} // Bihn2::evaluate


bool Binh2::constraintsAreSatisfied(Individual * individual) {
  double x[2]   ;
  bool   result ; 
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
    
  result = false ;

  if (0 >= ((x[0]-5)*(x[0]-5) + x[1]*x[1] - 25))
    if (0 >= (-((x[0]-8)*(x[0]-8)) - (x[1]+3)*(x[1]+3)+7.7))
      result = true ;

  return result ;    
} // Binh2::constraintsAreSafisfied

int Binh2::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter ;
  double x[2]    ;
 
  counter = 0 ;
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  
  if (0 < ((x[0]-5)*(x[0]-5) + x[1]*x[1] - 25))
    counter ++ ;
  if (0 < (-((x[0]-8)*(x[0]-8)) - (x[1]+3)*(x[1]+3)+7.7))
    counter ++ ;

  return counter ;  
} // Binh2::numberOfNonSatisfiedConstraints
