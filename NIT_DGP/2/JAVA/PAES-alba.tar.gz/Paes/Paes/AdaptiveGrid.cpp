/**
 * @file    AdaptiveGrid.cpp
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    12 Deeember 2003
 * @brief   Implementation of class AdaptiveGrid
 */
 
#include <AdaptiveGrid.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
AdaptiveGrid::AdaptiveGrid() {
} // AdaptiveGrid::AdaptiveGrid

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
AdaptiveGrid::AdaptiveGrid(int depth, 
                           int numberOfFunctions) {
                           
  numberOfFunctions_  = numberOfFunctions ;
  depth_              = depth             ;
  
  currentGridSize_ = (long) floor(pow(2.0, 
                                      (double) depth_ *
                                      (double) numberOfFunctions_
                                      ));
  hypercube_    = new int[currentGridSize_];
  divisionSize_ = new double[numberOfFunctions_];
  gridLimits_   = new double[numberOfFunctions_];
  
  upperBestFitness_ = new double[numberOfFunctions_];
  lowerBestFitness_ = new double[numberOfFunctions_];  
  
  tmpDivisionSize_ = new double[numberOfFunctions_] ;
  increment_       = new int[numberOfFunctions_]    ;
  
  if (!currentGridSize_ || !hypercube_ || !divisionSize_ || !gridLimits_  ||
      !upperBestFitness_ || !lowerBestFitness_ ||
      !tmpDivisionSize_ || !increment_) {
    cerr << "AdaptiveGrid::AdaptiveGrid-> Error when asking for memory"
         << endl ;
    exit(-1) ;
  } // if
} // AdaptiveGrid::AdaptiveGrid

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
AdaptiveGrid::~AdaptiveGrid() {
} // AdaptiveGrid::~AdaptiveGrid

/**
 * @brief Update the grid locations
 *
 */
void AdaptiveGrid::updateGridLocations(Population * population,
                                       Individual * individual) {
  int i ;
  int j ;
  
  for (i = 0; i < numberOfFunctions_; ++i) {
    upperBestFitness_[i] = MIN_INT ;
    lowerBestFitness_[i] = MAX_INT ;
  } //for
  
  for (i = 0; i < numberOfFunctions_; i++) {
    if (individual->getFitness()[i] < lowerBestFitness_[i])
      lowerBestFitness_[i] = individual->getFitness()[i] ;
    if (individual->getFitness()[i] > upperBestFitness_[i])
      upperBestFitness_[i] = individual->getFitness()[i] ;

    for (j = 0; j < population->getPopulationSize(); j ++) {
      if (population->getIth(j)->getFitness()[i] < lowerBestFitness_[i]) 
        lowerBestFitness_[i] = population->getIth(j)->getFitness()[i] ;
      if (population->getIth(j)->getFitness()[i] > upperBestFitness_[i]) 
        upperBestFitness_[i] = population->getIth(j)->getFitness()[i] ;      
    } // for
    
    divisionSize_[i] = (upperBestFitness_[i] - lowerBestFitness_[i]) ;
    // gridLimits_[i]   = lowerBestFitness[i] - (divisionSize_[i] / 2.0) ;
  } // for
  
  for (i = 0; i < (int)pow(2.0, numberOfFunctions_ * depth_); i++) ;
    hypercube_[i] = 0 ;
    
  int location ;  
  mostCrowdedHypercube_ = 0 ;
  location = findLocation(individual) ;
  individual->gridLocation_ = location ;
  hypercube_[location] ++ ;
  for (i = 0 ; i < population->getPopulationSize(); i++) {
    location = findLocation(population->getIth(i)) ;
    (population->getIth(i))->gridLocation_ = location ;
    hypercube_[location] ++ ;
    if (hypercube_[location] > hypercube_[mostCrowdedHypercube_])
      mostCrowdedHypercube_ = location ;
  } // for
} // AdaptiveGrid::updateGridLocations

/**
 * @brief Find the location of the individual in the adaptive grid
 *
 */
int AdaptiveGrid::findLocation(Individual * individual) {
  int i        ;
  int j        ;
  int location ;
  int counter  ;
  
  location = 0 ;
  counter  = 1 ;
  for (i = 0; i < numberOfFunctions_; i++) {
    increment_[i] = counter ;
    counter *= 2 ;
    tmpDivisionSize_[i] = divisionSize_[i] ;
  } // for
  
  for (i = 1; i <= depth_; i++) {
    for (j = 0; j < numberOfFunctions_; j++) 
      if (individual->getFitness()[j] < 
          (tmpDivisionSize_[j]/2 + lowerBestFitness_[j]))
        location = increment_[j] ;
      else
        lowerBestFitness_[j] += tmpDivisionSize_[j] / 2.0 ;
    for (j = 0; j < numberOfFunctions_; j++) {
      increment_[j] *= numberOfFunctions_ * 2 ;
      tmpDivisionSize_[j] /= 2.0 ;
    } // for
  } // for
  
  return location ;
} // AdaptiveGrid::findLocation
        
