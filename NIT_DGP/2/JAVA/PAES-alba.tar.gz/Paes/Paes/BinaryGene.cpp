/*
 * @file    BinaryGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Class representing a binary gene
 */
 
#include <BinaryGene.h>

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryGene::BinaryGene(int numberOfBits, Random * random) : 
            Gene(BINARY, random) {
  int i ;
  
  numberOfBits_ = numberOfBits           ;
  allele_       = new char[numberOfBits] ;
  
  if (allele_ == NULL) {
    cerr << "BinaryGene::BinaryGene-> Error when asking for memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits; i++)
    if (random_->rnd(0,1) == 1)
      allele_[i] = '1' ;
    else
      allele_[i] = '0' ;

} // BinaryGene::BinaryGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryGene::BinaryGene(BinaryGene & binaryGene) : Gene(binaryGene) {
  int i ;
  
  numberOfBits_= binaryGene.numberOfBits_ ;
  allele_      = new char[numberOfBits_] ;

  if (allele_ == NULL) {
    cerr << "BinaryGene::BinaryGene-> Error when asking for memory" << endl ;
    exit(-1) ;
  } // if

  for (i = 0; i < numberOfBits_; i++)
    allele_[i] = binaryGene.allele_[i] ;  

} // BinaryGene::BinaryGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryGene::BinaryGene(BinaryGene * binaryGene) : Gene(binaryGene) {
  int i ;
  
  numberOfBits_= binaryGene->numberOfBits_ ;
  allele_      = new char[numberOfBits_] ;

  if (allele_ == NULL) {
    cerr << "BinaryGene::BinaryGene-> Error when asking for memory" << endl ;
    exit(-1) ;
  } // if

  for (i = 0; i < numberOfBits_; i++)
    allele_[i] = binaryGene->allele_[i] ;  
} // BinaryGene::BinaryGene

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
BinaryGene::~BinaryGene() {
  delete [] allele_ ;
} // BinaryGene::~BinaryGene


int BinaryGene::bitFlipMutation(double mutationProbability) {
  int mutations ;
  int i         ;
  
  mutations = 0 ;

  for (int i = 0; i < numberOfBits_ ; i++)
    if (random_->flip(mutationProbability) == 1) {
      mutations ++ ;
      if (allele_[i] == '1')
        allele_[i] = '0' ;
      else
        allele_[i] = '1' ;
    } //if
    
  return mutations ;
} // BinaryGene::bitFlipMutation

void BinaryGene::writeGenotype(ofstream& outputFile) {
  int i ;
//  cout << "number of bits: " << numberOfBits_ << endl ;
  for (i = 0 ; i < numberOfBits_; i++)
    if (allele_[i] == '1')
      outputFile << "1" ;
    else
      outputFile << "0" ;
} // BinaryGene::writeGenotype

BinaryGene & BinaryGene::operator=(const BinaryGene& binaryGene) {
  int i ;
  numberOfBits_= binaryGene.numberOfBits_ ;
  for (i = 0; i < numberOfBits_; i++)
    allele_[i] = binaryGene.allele_[i] ;  
  
  return *this ;
} // BinaryGene::operator=


ostream& operator<< (ostream& outputStream, BinaryGene& gene) {
  int i ;
  
  outputStream << (Gene&)gene << " Bits: " << gene.numberOfBits_ << " allele: " ;
  for (i = 0 ; i < gene.numberOfBits_; i++)
    if (gene.allele_[i] == '1')
      outputStream << "1" ;
    else
      outputStream << "0" ;
} // operator<< 

