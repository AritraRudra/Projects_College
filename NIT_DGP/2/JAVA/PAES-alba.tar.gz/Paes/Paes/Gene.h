/*
 * @file    Gene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of Gene.cpp
 */
 
#include <Configuration.h>
#include <Random.h>

#ifndef __GENE__
#define __GENE__

/**
 * @class Gene
 * @brief Abstract class that represents a gene
 */
class Gene {
public:
  Random *     random_   ; //!< Random number generator
  VariableType geneType_ ; //!< Type of the gene
  
  // Constructors
  Gene(VariableType geneType_, Random * random) ;
  Gene(Gene & gene) ;
  Gene(Gene * gene) ;
  
  // Destructor
  virtual ~Gene() ;
  
  // Methods
  virtual int bitFlipMutation(double mutationProbability) ; 
  
  virtual int randomMutation(double mutationProbability) ;
  virtual int polynomialMutation(double mutationProbability, 
                                 double distributionIndex) ; 
  virtual int uniformMutation(double mutationProbability, 
                              double perturbation) ; 

  virtual double getRealAllele() ;
  virtual void   writeGenotype(ofstream &outputFile) = 0 ;
  
  // Operators 
  Gene & operator=(const Gene& gene) ;
  friend ostream& operator<< (ostream& outputStream, Gene& gene) ;

} ; // Gene

#endif


