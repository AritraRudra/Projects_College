/*
 * @file    Chromosome.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of Chromosome.cpp
 */

#include <Configuration.h>

#include <Random.h>

#include <BinaryGene.h>
#include <RealGene.h>
#include <BinaryGrayRealGene.h>
#include <BinaryRealGene.h>

#include <MultiobjectiveProblem.h>

#ifndef __CHROMOSOME__
#define __CHROMOSOME__

/**
 * @class Chromosome
 * @brief Class representing a chromosome
 */
class Chromosome {
public:
  int                     length_  ; //!< Chromosome lenght
  MultiobjectiveProblem * problem_ ; //!< Problem to solve 
  Gene                 ** gene_    ; //!< Genes of the chromosome
  
  
  // Constructors
  Chromosome(MultiobjectiveProblem * problem, Random * random) ;
  Chromosome(Chromosome & chromosome) ;
  Chromosome(Chromosome * chromosome) ;
  
  // Destructor
  ~Chromosome() ;
  
  // Operators
  Chromosome & operator=(Chromosome & chromosome) ;
  friend ostream& operator<< (ostream& outputStream, Chromosome& chromosome) ;
} ; // Chromosome

#endif
