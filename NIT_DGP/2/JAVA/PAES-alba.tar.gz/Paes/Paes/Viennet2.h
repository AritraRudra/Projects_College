/**
 * @file        Viennet2.h
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 January 2004
 * @brief       Header file of Viennet2.cpp
 */ 
 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __VIENNET2__
#define __VIENNET2__

/**
 * @class Viennet2
 * @brief Class representing Viennet(2)'s problem
 */
class Viennet2 : public MultiobjectiveProblem {
public:
  // Constructor
  Viennet2(VariableType variableType) ;

  // Methods
  void evaluate(Individual * individual) ;
} ; // class Viennet2

#endif
