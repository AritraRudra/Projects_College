#include <MultiobjectiveProblem.h>

MultiobjectiveProblem::MultiobjectiveProblem()  {
  problemName_ = "NULL" ;
  variable_    = NULL ;
  } // MultiobjectiveProblem::MultiobjectiveProblem

void MultiobjectiveProblem::adjustPrecision(int variable) {
  int representationBase = 2 ;
  bitsPerVariable_[variable] = (int) ceil(log((upperLimit_[variable] - 
                                               lowerLimit_[variable]) *
                                          pow(10.0, precision_[variable]) *
                                          1.000001)
                                     /
                                     log((double)representationBase)
                                     ) ; 
} // MultiobjectiveProblem::adjustPrecision


bool MultiobjectiveProblem::constraintsAreSatisfied(Individual * individual) {
  return true ;
} // MultiobjectiveProblem::constraintsAreSatisfied

int MultiobjectiveProblem::numberOfNonSatisfiedConstraints(Individual * ind) {
  return 0 ; 
} //  MultiobjectiveProblem::numberOfNonSatisfiedContraints

void MultiobjectiveProblem::initializeRealVariableType(
                                                  VariableType variableType) {
  int i ;
  for (i = 0; i < numberOfVariables_; i++)
    if (variableType == REAL) 
      variable_[i] = REAL ;
    else if (variableType == BINARY_GRAY_REAL) {
      variable_[i] = BINARY_GRAY_REAL ;
      adjustPrecision(i) ;
      cout << " bits variable " << i << ": " << bitsPerVariable_[i] << endl ;
    } // else if      
    else if (variableType == BINARY_REAL) {
      variable_[i] = BINARY_REAL ;
      adjustPrecision(i) ;
      cout << " bits variable " << i << ": " << bitsPerVariable_[i] << endl ;
    } // else if      
    else {
      cerr << "MultiobjectiveProblem::initializeVariableType-> "
           << "the type of the variable must be Real, BinaryReal or "
           << "BinaryGrayReal. Type received: " << variableType << endl ;
      exit(-1) ;
    } // else
} // MultiobjectiveProblem::initializeVariableType


/**
 * @brief Prints the information associated to a multiobjective problem
 * @return Nothing
 */
void MultiobjectiveProblem::print() {
  cout << "Problem Name      : " << problemName_ << endl  ;
  cout << "Variables         : " << numberOfVariables_ << endl ;
  cout << "Functions         : " << numberOfFunctions_ << endl ;
  cout << "Partitions        : " ;
  int i ;
  for (i = 0; i < numberOfVariables_; i++) {
    cout << partitions_[i] << ", " ;
  } // for
  cout << endl ;
  cout << "Limits            : " ;
  for (i = 0; i < numberOfVariables_; i++) {
    cout << "(" << lowerLimit_[i] << ", " << upperLimit_[i] << "), " ;
  } // for
  cout << endl ;
  cout << "====" << endl ;

} // MultiobjectiveProblem::print
