#include <Fonseca.h>

Fonseca::Fonseca(VariableType variableType) {
  problemName_ = "FONSECA" ;

  numberOfVariables_   = 3 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 0 ;

  const double upperLimit[] = {4.0, 4.0, 4.0} ;
  const double lowerLimit[] = {-4.0, -4.0, -4.0} ;
  const int partitions[]    = {80, 80, 80} ;
  const int precision[]     = {5, 5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;

  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Fonseca::Fonseca

void Fonseca::evaluate(Individual *individual) {
  // First function
  double result = 0.0 ;
  int i ;

  for (i = 0; i < numberOfVariables_; i++) {
//cout << "Allele: " << (individual->chromosome_->gene_[i])->getRealAllele() << endl ;
      result += pow((individual->chromosome_->gene_[i])->getRealAllele() -
                   (1 /sqrt((double)numberOfVariables_)), 2) ;
  } //for

  result = 1 - exp(-result) ;
  individual->fitness_[0] = result ;

  // Second function
  result = 0.0 ;  
  for (i = 0; i < numberOfVariables_ ; i++) {
//cout << "Allele: " << (individual->chromosome_->gene_[i])->getRealAllele() << endl ;
      result += pow((individual->chromosome_->gene_[i])->getRealAllele()+ 
                    (1 / sqrt((double)numberOfVariables_)), 2) ;
  } //for

  result = 1 - exp(-result) ;
  individual->fitness_[1] = result ;
} // Fonseca::evaluateIndividual
