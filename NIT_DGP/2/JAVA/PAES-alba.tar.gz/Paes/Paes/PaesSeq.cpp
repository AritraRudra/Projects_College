/**
 * @file        PaesSeq.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     0.1
 * @date        16 October 2003
 * @brief       This program obtains the pareto front of a multiobjective 
 *              problem using the PAES strategy
 *
 */

#include <Configuration.h>

#include <Random.h>

#include <ProblemHeaders.h>

#include <Individual.h>
#include <Paes.h>

/**
 * @brief    Entry point to the program
 * @param    argc Number of arguments in the command line
 * @param    argv Array containing the arguments
 * @return   0 after successfull execution, -1 otherwise
 */

int main(int argc, char *argv[]) {
  MultiobjectiveProblem * problemToSolve ;

  cout << "START" << endl ; 
  
  //problemToSolve = new OneMax(512) ;
  //Paes * paes = new Paes(problemToSolve, BIT_FLIP) ;
  //problemToSolve = new Golinski(REAL) ; 
  //Paes * paes = new Paes(problemToSolve, RANDOM) ;
  problemToSolve = new Kursawe(BINARY_REAL) ; 
  Paes * paes = new Paes(problemToSolve, BIT_FLIP) ;
  paes->start() ;
  paes->printStatistics() ;
  paes->printToFiles("VAR", "FUN") ;
  
  cout << "END" << endl ;

  return 0 ;
} // main

