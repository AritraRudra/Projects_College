#include <Configuration.h>
#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __ONE_MAX__
#define __ONE_MAX__

class OneMax : public MultiobjectiveProblem {
public:
  OneMax(int numberOfBits) ;
  
  void evaluate(Individual *individual) ;
} ; // OneMax

#endif
