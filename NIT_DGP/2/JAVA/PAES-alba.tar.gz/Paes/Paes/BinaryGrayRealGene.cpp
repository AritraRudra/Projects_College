#include <BinaryGrayRealGene.h>

BinaryGrayRealGene::BinaryGrayRealGene(int      numberOfBits,
                                       double   lowerBound  , 
                                       double   upperBound,
                                       Random * random) : 
                    Gene(BINARY_GRAY_REAL, random) {
  int i ;                    
                    
  upperBound_   = upperBound   ;
  lowerBound_   = lowerBound   ;                    
  numberOfBits_ = numberOfBits ;
  
  binaryAllele_ = new char[numberOfBits] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryGrayRealGene::BinaryGrayRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits; i++)
    if (random_->rnd(0,1) == 1)
      binaryAllele_[i] = '1' ;
    else
      binaryAllele_[i] = '0' ;

  realAllele_ = random_->rndreal(lowerBound, upperBound) ;      
} // RealGene::RealGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
BinaryGrayRealGene::BinaryGrayRealGene(BinaryGrayRealGene & gene) : 
                    Gene(gene) {
  int i ;                    

  upperBound_   = gene.upperBound_        ;
  lowerBound_   = gene.lowerBound_        ;                                        
  numberOfBits_ = gene.numberOfBits_      ;
  binaryAllele_ = new char[numberOfBits_] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryGrayRealGene::BinaryGrayRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene.binaryAllele_[i] ;
    
  realAllele_ = gene.realAllele_ ;
} // BinaryGrayRealGene::BinaryGrayRealGene


/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */

BinaryGrayRealGene::BinaryGrayRealGene(BinaryGrayRealGene * gene) : 
                    Gene(gene) {
  int i ;                    
                    
  upperBound_   = gene->upperBound_       ;
  lowerBound_   = gene->lowerBound_       ;                                        
  numberOfBits_ = gene->numberOfBits_     ;
  binaryAllele_ = new char[numberOfBits_] ;
  
  if (binaryAllele_ == NULL) {
    cerr << "BinaryGrayRealGene::BinaryGrayRealGene-> Error when asking for " 
         << "memory" << endl ;
    exit(-1) ;
  } // if
  
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene->binaryAllele_[i] ;
    
  realAllele_ = gene->realAllele_ ;
} // BinaryGrayRealGene::BinaryGrayRealGene


BinaryGrayRealGene & BinaryGrayRealGene::operator=(const BinaryGrayRealGene& 
                                                   gene) {
  int i ;                    

  upperBound_   = gene.upperBound_   ;
  lowerBound_   = gene.lowerBound_   ;                                                            
  numberOfBits_ = gene.numberOfBits_ ;
  for (i = 0; i < numberOfBits_; i++)
    binaryAllele_[i] = gene.binaryAllele_[i] ;
  realAllele_ = gene.realAllele_ ;        
  
  return *this ;                                             
} // BinaryGrayRealGene::operator=                                                    

int BinaryGrayRealGene::bitFlipMutation(double mutationProbability) {
  int mutations ;
  int i         ;
cout << "To be implemented" << endl ;  
return 0 ;  
  mutations = 0 ;

  for (int i = 0; i < numberOfBits_ ; i++)
    if (random_->flip(mutationProbability) == 1) {
      mutations ++ ;
      if (binaryAllele_[i] == '1')
        binaryAllele_[i] == '0' ;
      else
        binaryAllele_[i] == '1' ;
    } //if
    
  realAllele_ = random_->rndreal(lowerBound_, upperBound_) ;      
cout << "To be implemented" << endl ;  
  return mutations ;
} // BinaryGrayRealGene::bitFlipMutation

void BinaryGrayRealGene::writeGenotype(ofstream &outputFile) {
cout << "To be implemented" << endl ;  
} // BinaryGrayRealGene::writeGenotype

ostream& operator<< (ostream& outputStream, BinaryGrayRealGene& gene) {
  int i ;

  outputStream << (Gene&)gene << " Real allele: " << gene.realAllele_ ;
  
  outputStream << " Bits: " << gene.numberOfBits_ << " Binary allele: " ;
  for (i = 0 ; i < gene.numberOfBits_; i++)
    if (gene.binaryAllele_[i] == '1')
      outputStream << "1" ;
    else
      outputStream << "0" ;
  outputStream << endl ;
} // operator<< 

double BinaryGrayRealGene::getRealAllele() {
  return realAllele_ ;
} // Gene::getRealAllele


void BinaryGrayRealGene::decodeGene(double lowerBound, double upperBound) {
} // BinaryGrayRealGene::decodeGene
