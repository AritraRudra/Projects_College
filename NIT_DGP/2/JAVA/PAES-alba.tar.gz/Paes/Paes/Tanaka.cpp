/**
 * @file        Tanaka.cpp
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        27 Janary 2004
 * @brief       Specificacion of Tanakas's problem.
 *              This problem is renamed MOP-C4 in Coello et al.
 */
 
#include <Tanaka.h>

/**
 * @brief Constructor
 *
 * Constructor of the class
 */
Tanaka::Tanaka(VariableType variableType) {
  problemName_ = "Tanaka-MOP-C4" ;

  numberOfVariables_   = 2 ;
  numberOfFunctions_   = 2 ;
  numberOfConstraints_ = 2 ;

  const double upperLimit[] = {3.1416, 3.1416} ;
  const double lowerLimit[] = {10e-5, 10e-5} ;
  const int partitions[]    = {100, 100} ;
  const int precision[]     = {5, 5} ;

  upperLimit_      = new double[numberOfVariables_] ;
  lowerLimit_      = new double[numberOfVariables_] ;
  partitions_      = new int[numberOfVariables_]    ;
  precision_       = new int[numberOfVariables_]    ;
  bitsPerVariable_ = new int[numberOfVariables_]    ;

  memcpy(upperLimit_, upperLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(lowerLimit_, lowerLimit, numberOfVariables_ * sizeof(double)) ;
  memcpy(partitions_, partitions_, numberOfVariables_ * sizeof(int)) ;
  memcpy(precision_, precision, numberOfVariables_ * sizeof(int)) ;

  variable_ = new VariableType[numberOfVariables_] ;
  int i ;

  initializeRealVariableType(variableType) ;
  cout << "Created a " << problemName_ << " problem" << endl ;
} // Constructor

void Tanaka::evaluate(Individual * individual) {
  // First function
  individual->fitness_[0] =(individual->chromosome_->gene_[0])->getRealAllele();

  // Second function
  individual->fitness_[1] =(individual->chromosome_->gene_[1])->getRealAllele();

} // Tanaka::evaluate


const double a = 0.1  ; //!< Constant a
const double b = 16.0 ; //!< Constant b

bool Tanaka::constraintsAreSatisfied(Individual * individual) {
  double x[2];
  
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
  
  if ( ((x[0]*x[0]) + (x[1]*x[1])) >= (1.0 + a * cos(b * atan(x[1]/x[0])))) {
    if (0.5 >= ((x[0] - 0.5)*(x[0] - 0.5) + (x[1] - 0.5)*(x[1] - 0.5)))
      return true ;
    else
      return false ;
  }
  else
    return false ;
} // Tanaka::constraintsAreSafisfied

int Tanaka::numberOfNonSatisfiedConstraints(Individual * individual) {
  int    counter ;
  double x[2]    ;

  counter = 0 ;
  x[0] = (individual->chromosome_->gene_[0])->getRealAllele() ;
  x[1] = (individual->chromosome_->gene_[1])->getRealAllele() ;
 
  if (((x[0]*x[0]) + (x[1]*x[1])) < (1.0 + a * cos(b * atan(x[1]/x[0]))))
    counter ++ ;
  if (0.5 < ((x[0] - 0.5)*(x[0] - 0.5) + (x[1] - 0.5)*(x[1] - 0.5)))
    counter ++ ;

  return counter ;
} // Tanaka::numberOfNonSatisfiedConstraints
