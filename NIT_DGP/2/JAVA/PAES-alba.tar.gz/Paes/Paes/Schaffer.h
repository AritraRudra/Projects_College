/**
 * @file        Schaffer.h 
 * @author      Antonio Jesus Nebro Urbaneja
 * @version     2.0
 * @date        28 January 2004
 * @brief       Header file of Schaffer.cpp
 */ 

#include <MultiobjectiveProblem.h>
#include <Individual.h>

#ifndef __SCHAFFER__
#define __SCHAFFER__

/**
 * @class Schaffer
 * @brief Class representing Schaffer's problem
 */
class Schaffer : public MultiobjectiveProblem {
public:
  // Constructor
  Schaffer(VariableType variableType ) ;

  // Methods
  void evaluate(Individual * individual) ;
} ; // class Schaffer

#endif

