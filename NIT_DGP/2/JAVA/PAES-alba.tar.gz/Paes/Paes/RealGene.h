/*
 * @file    RealGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Header file of RealGene.cpp
 */
 
#include <Configuration.h>
#include <Gene.h>

#ifndef __REAL_GENE__
#define __REAL_GENE__

/**
 * @class Gene
 * @brief Class representing a real gene
 */
class RealGene : public Gene {
public:
  double allele_     ; //!< Allele
  double lowerBound_ ; //!< Lower bound of the allele
  double upperBound_ ; //!< Upper bound of the allele

  // Constructors
  RealGene(Random * random) ;
  RealGene(double lowerBound, double upperBound, Random * random) ;
  RealGene(RealGene & realgene) ;
  RealGene(RealGene * realGene) ;

  // Destructor
  ~RealGene() ;
  
  // Methods
  int randomMutation(double mutationProbability) ; 
  int polynomialMutation(double mutationProbability, 
                         double distributionIndex) ; 
  int uniformMutation(double mutationProbability, double perturbation) ; 

  double getRealAllele() ;
  void   writeGenotype(ofstream &outputFile) ;

  // Operators
  RealGene & operator=(const RealGene& realGene) ;
  friend ostream& operator<< (ostream& outputStream, RealGene& gene) ;

#ifdef __MPI__
  void send(int address) ;
  void receive(int address) ;
  
  int getSize()        ;
  void calculateSize() ;
  
  void packData(char * buffer, int * bufferOffset, int bufferSize) ;
  void unpackData(char * buffer, int * bufferOffset, int bufferSize) ;

#endif    

} ; // RealGene

#endif
