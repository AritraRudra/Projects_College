/*
 * @file    RealGene.h
 * @author  Antonio Jesus Nebro Urbaneja
 * @version 1.0
 * @date    29 January 2004
 * @brief   Class representing a real gene
 */
 

#include <RealGene.h>

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
RealGene::RealGene(Random * random) : Gene(REAL, random) {
  lowerBound_ = MIN_REAL ;
  upperBound_ = MAX_REAL ;
  allele_ = random_->rndreal(lowerBound_, upperBound_) ;

#ifdef __MPI__
this->calculateSize() ;
#endif  
} // RealGene::RealGene

/**
 * @brief Constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
RealGene::RealGene(double lowerBound, double upperBound, Random * random) : 
          Gene(REAL, random) {
  lowerBound_ = lowerBound ;
  upperBound_ = upperBound ;
  allele_ = random_->rndreal(lowerBound, upperBound) ;

#ifdef __MPI__
this->calculateSize() ;
#endif    
} // RealGene::RealGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
RealGene::RealGene(RealGene & realGene) : Gene(realGene) {
  allele_     = realGene.allele_     ;
  lowerBound_ = realGene.lowerBound_ ;
  upperBound_ = realGene.upperBound_ ;
  
#ifdef __MPI__
this->calculateSize() ;
#endif  
} // RealGene::RealGene

/**
 * @brief Copy constructor
 * @param individual The individual to copy
 *
 * Constructor of the class
 */
RealGene::RealGene(RealGene * realGene) : Gene(realGene) {
  allele_     = realGene->allele_     ;
  lowerBound_ = realGene->lowerBound_ ;
  upperBound_ = realGene->upperBound_ ;
  
#ifdef __MPI__
this->calculateSize() ;
#endif  
} // RealGene::RealGene

/**
 * @brief Destructor
 *
 * Destructor of the class
 */
RealGene::~RealGene() {
} // RealGene::~RealGene

int RealGene::randomMutation(double mutationProbability) {
  int    i         ;
  int    mutations ;
  double rnd       ;
  
  mutations = 0 ;
  
  rnd = random_->rndreal(0.0, 1.0) ;
  if (rnd <= mutationProbability) {
    allele_ = lowerBound_ + rnd *(upperBound_ - lowerBound_) ;

    mutations ++ ;
  } // if    
  
  return mutations ;
} // RealGene::uniformMutation

int RealGene::polynomialMutation(double mutationProbability, 
                                 double distributionIndex) {                                   
  int    i          ;
  double temp       ;
  int    mutations  ;
  double rnd        ;

  double delta      ;
  double deltaq     ;
  double mu         ;
  
  mutations = 0 ;

  rnd = random_->rndreal(0.0, 1.0) ;
  if (rnd <= mutationProbability) {
    if (allele_ > lowerBound_) { // calculate delta
      if ((allele_ - lowerBound_) < (upperBound_ - allele_))
        delta = (allele_ - lowerBound_) / (upperBound_ - allele_) ;
      else
        delta = (upperBound_ - allele_) / (upperBound_ - lowerBound_) ;
      rnd = random_->rndreal(0.0, 1.0) ;
      mu  = 1.0/(distributionIndex + 1.0);
      if(rnd <= 0.5) {
        double xy = 1.0-delta;
        temp = 2*rnd+(1-2*rnd)*(pow(xy,(distributionIndex + 1)));
        deltaq =  pow(temp, mu) - 1.0;
      } // if
      else {
        double xy = 1.0-delta;
        temp = 2.0*(1.0-rnd)+2.0*(rnd-0.5)*(pow(xy,(distributionIndex + 1)));
        deltaq = 1.0 - (pow(temp,mu));
      } // else

      /*Change the value of the allele */
      allele_ += deltaq * (upperBound_ - lowerBound_);
      if (allele_ < lowerBound_)
        allele_ = lowerBound_ ;
      if (allele_ > upperBound_)
        allele_ = upperBound_ ;
    } // if
    else {
      rnd = random_->rndreal(0.0, 1.0) ;
      allele_ = rnd * (upperBound_ - lowerBound_) + lowerBound_ ;
    } // else
    mutations ++ ;
  } // if

  return mutations ;
} // Individual::PolynomialMutationn

int RealGene::uniformMutation(double mutationProbability, double perturbation) {
  int    i         ;
  int    mutations ;
  double rnd       ;
  
  mutations = 0 ;
  
  rnd = random_->rndreal(0.0, 1.0) ;
  if (rnd <= mutationProbability) {
//cout << "allele_ " << allele_ ;
    double tmp = (rnd + 0.5)*perturbation ;
//cout << "\tVar: " << tmp ;
//    allele_ = allele_ + (rnd - 0.5)*perturbation ;
    allele_ = allele_ + tmp ;
    if (allele_ < lowerBound_)
      allele_ = lowerBound_ ;
    if (allele_ > upperBound_)
      allele_ = upperBound_ ;
//cout << "\tMallele_ " << allele_ << endl ;    

    mutations ++ ;
  } // if    
  
  return mutations ;
} // RealGene::uniformMutation


double RealGene::getRealAllele() {
  return allele_ ;
} // Gene::getRealAllele

void RealGene::writeGenotype(ofstream& outputFile) {
  outputFile << allele_ ;
} // RealGene::writeGenotype

RealGene & RealGene::operator=(const RealGene& realGene) {
  allele_ = realGene.allele_ ;

  return *this ;  
} // RealGene::operator=

ostream& operator<< (ostream& outputStream, RealGene& gene) {
  outputStream << (Gene&)gene << " allele: " << gene.allele_ << " ";
} // operator<< 

#ifdef __MPI__
void RealGene::send(int address) {
  MPI_Send(&allele_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD) ;
  MPI_Send(&lowerBound_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD) ;
  MPI_Send(&upperBound_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD) ;
} // RealGene::send
  
void RealGene::receive(int address) {
  MPI_Status status ;
    
  MPI_Recv(&allele_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD, &status) ;    
  MPI_Recv(&lowerBound_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD, &status) ;    
  MPI_Recv(&upperBound_, 1, MPI_DOUBLE, address, 1, MPI_COMM_WORLD, &status) ;    
} // RealGene::receive
  
void RealGene::calculateSize() {
  int size ;
    
  MPI_Pack_size(1, MPI_DOUBLE, MPI_COMM_WORLD, &size) ;
  dataSize_ = 3 * size ;
}

int RealGene::getSize() {
  return dataSize_ ;
}

void RealGene::packData(char * buffer, int * bufferOffset, int bufferSize) {
  MPI_Pack(&allele_,     1, MPI_DOUBLE, buffer, bufferSize, bufferOffset, MPI_COMM_WORLD) ;
  MPI_Pack(&lowerBound_, 1, MPI_DOUBLE, buffer, bufferSize, bufferOffset, MPI_COMM_WORLD) ;
  MPI_Pack(&upperBound_, 1, MPI_DOUBLE, buffer, bufferSize, bufferOffset, MPI_COMM_WORLD) ;
} 
  
void RealGene::unpackData(char * buffer, int * bufferOffset, int bufferSize) {
  MPI_Unpack(buffer, bufferSize, bufferOffset, &allele_, 1, MPI_DOUBLE, MPI_COMM_WORLD) ;
  MPI_Unpack(buffer, bufferSize, bufferOffset, &lowerBound_, 1, MPI_DOUBLE, MPI_COMM_WORLD) ;
  MPI_Unpack(buffer, bufferSize, bufferOffset, &upperBound_, 1, MPI_DOUBLE, MPI_COMM_WORLD) ;
} 

#endif    
