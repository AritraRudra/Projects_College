/**
  @mainpage C++ implementation of the PAES algorithm
  
\section info Project Information
\subsection author Author
<ul>
<li>Antonio J. Nebro (University of M&aacute;laga)
<li>Francisco Luna (University of M&aacute;laga)
<li>Enrique Alba (University of M&aacute;laga)
</ul> 

If you have any question, please send a message to: Antonio J. Nebro 
(antonio@lcc.uma.es)

\subsection version Version
0.1 (February 2004)
  
\subsection table Table of Contents
<ul>
<li> \ref intro
<li> \ref installation  
<li> \ref compiling
<li> \ref executing
<li> \ref adding 
<li> \ref todo
</ul>
  
<hr>
  
\section intro Introduction
This document describes briefly an implementation of the PAES algorithm in 
C++. Please, note that this is a preliminary version, so some files are not 
properly documented, and some functions must be still tested.

Some features of our implementation of PAES are the following:
<ul>
<li>We have added a constraint handling mechanism similar to the one employed
in the micro-GA algorithm.
<li>For continuous problems, we can choose two different representations for
the decision variables: REAL and BINARY_REAL (binary-coded real values). 
<li>Our implementation also supports binary variables (for example, see the
@c OneMax problem, a mono-objective problem used for testing purpose).
<li>Currently, there is a bit-flip mutation operator for binary individuals, and
three mutant operators for real-coded problems: random, polynomial, and uniform.
In our preliminary tests, we have used random mutation; the other two mutation
operators must be exhaustively tested.
</ul>

Currently, our program incorporates a number of both constrained and unconstrained 
problems. You can find the problem names in the file @c ProblemHeaders.h.

\subsection goals Goals
The goals of this work is to provide a implementation of the PAES algorithm 
described by Knowles and Corne in C++. The motivaton of this work is to 
simply the adding of new problems, and it must serve as the basis of future
sequential and parallel implementations.

\subsection components Components

The codes are written in C++, and they have been developed in Linux and 
Windows 2000 using Gnu's g++ compiler. 

\section installation Installation
There is not any installation process. 

\subsection compiling Compilation
To compile the program, just type "make" in the "Paes" directory. 

\section executing Executing the Program
There exists a configuration file named "paes.cfg" that is read by the program
when it starts. One you have modified that file according to your preferences 
(archive length, mutation probability, etc.), just type:

<code>
$ PaesSeq
</code>

Currently, the program produces two output files, name "VAR" y "FUN". The first
one contains the values of the decision variables, while the second one stores
the values of the functions. You can change easily the names of these files
(see line 40 in the file PaesSeq.cpp).

\section adding Adding new Problems
In this section we detail how to define a multi-objective problem to be 
solved by the applications of the project. The program has been designed to try
to simplify this task as possible. The key is to use the inheritance mechanism
to provide a base class, @c MultiobjectiveProblem, that must be inherited 
by all the classes representing problems. 

Let us suppose we want to add a new unconstrained multi-objective problem called
@c Example. The easiest way is to take an existing problem as a reference; 
for example, let us choose the problem @c Kursawe. This problem is defined in
a class so named, which is defined in the files @c Kursawe.h and @c Kursawe.cpp. 
The steps required to add the problem are the following: 
 
<ol>
<li>Create a header file for the class. In our example, it should be named @c Example.h.
<li>Create the implementation file @c Example.cpp. In this file you have to define 
the constructor of the class and the method @c evaluate. The constructor
contains sentences to specify,among other information, the number of objective functions, 
the number of state variables, the number of constraints, and the limits of the state variables.
<li>Include the header file @c Example.h in the file @c ProblemHeaders.h 
<li>Modify the program @c PaesSeq.cpp to create an instance of the new problem.
<li>Modify the makefiles to add the object file @c Example.o in the macro named @c OBJS.
</ol>

If your problem has constraints, then you should override the methods @c numberOfNonSatisfiedConstraints
in the file @c Example.cpp; see, for example, the implementation files of the problems 
@c Viennet4 or @c Tanaka. (You do not need to override
the method @c constraintsAreSafisfied; it is intended for future use.)

Now, you should be ready to re-compile the project: type @c make and (if there are not 
compilation errors) then you can execute the programs to solve your multi-objective problem.

If you are insterested in solving a binary problem, please take the @c OneMax problem
as an example.

\section todo Current and future work
We are currently working in the following:
<ul>
<li>Complete documentation of the header and source files.
<li>Exahustive testing of the program. In particular, attention should be paid
to the polynomial and uniform mutation operators and the adaptive grid 
mechanism. 
<li>We intend to use a more elaborated constraint handling mechanism.
<li>Study of possible parallel extensions.
</ul>

*/  
